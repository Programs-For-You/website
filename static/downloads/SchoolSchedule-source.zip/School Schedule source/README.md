# School Schedule for Mac

Your class, a live timer with what's left in class, your homework plan, and a "Got homework?" box,
right in the menu bar, plus an overlay bar like the Windows app.

- Original **School Schedule Manager** (Windows): © 2026 Owen Wang. https://github.com/un-undefined/school-schedule-manager
- **macOS version**: © 2026 Brady Krupa. This was ported to macOS using Claude AI.
- License: **GNU Affero General Public License v3** (see `LICENSE`).

## Build it

1. Install Apple's command line tools once: `xcode-select --install`
2. Run `./build-mac.sh`
3. The app is in `build/School Schedule.app`.

Download the ready-made app and instructions at https://programsforyou.com/school-schedule.html
