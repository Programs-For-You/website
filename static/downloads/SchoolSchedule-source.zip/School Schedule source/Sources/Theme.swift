// School Schedule for Mac. Copyright (c) 2026 Owen Wang (original School Schedule Manager) and Brady Krupa
// (macOS version, ported to macOS using Claude AI). Licensed under the GNU AGPL v3; see LICENSE.
import AppKit
import SwiftUI

struct Theme: Identifiable {
    let id: String
    let name: String
    let dark: Bool
    let bg: Color
    let card: Color
    let text: Color
    let muted: Color
    let line: Color
    var accent: Color
    var accent2: Color

    static let all: [Theme] = [
        Theme(id: "modernDark", name: "Modern Dark", dark: true, bg: Color(hex: "#18191E"), card: Color(hex: "#23252D"),
              text: Color(hex: "#EBECF0"), muted: Color(hex: "#8C909C"), line: Color(hex: "#2E3039"),
              accent: Color(hex: "#4C8BF5"), accent2: Color(hex: "#7C4DDB")),
        Theme(id: "midnight", name: "Midnight", dark: true, bg: Color(hex: "#0B1020"), card: Color(hex: "#141B33"),
              text: Color(hex: "#E6E9F5"), muted: Color(hex: "#7F88A8"), line: Color(hex: "#1E2642"),
              accent: Color(hex: "#6C8CFF"), accent2: Color(hex: "#9F6BFF")),
        Theme(id: "light", name: "Light", dark: false, bg: Color(hex: "#FFFFFF"), card: Color(hex: "#F3F4F7"),
              text: Color(hex: "#121318"), muted: Color(hex: "#6B6F7B"), line: Color(hex: "#E6E7EC"),
              accent: Color(hex: "#4F46E5"), accent2: Color(hex: "#7C3AED")),
        Theme(id: "neon", name: "Neon", dark: true, bg: Color(hex: "#0A0A0F"), card: Color(hex: "#15151F"),
              text: Color(hex: "#F5F5FF"), muted: Color(hex: "#8A8AA3"), line: Color(hex: "#22222F"),
              accent: Color(hex: "#00C2A8"), accent2: Color(hex: "#F15BB5")),
        Theme(id: "pastel", name: "Pastel", dark: false, bg: Color(hex: "#FFF8FB"), card: Color(hex: "#FBEDF4"),
              text: Color(hex: "#3A2E39"), muted: Color(hex: "#8C7A88"), line: Color(hex: "#F2DDE8"),
              accent: Color(hex: "#E98AB8"), accent2: Color(hex: "#8FB4F5")),
        Theme(id: "minimal", name: "Minimal", dark: false, bg: Color(hex: "#FAFAFA"), card: Color(hex: "#FFFFFF"),
              text: Color(hex: "#111111"), muted: Color(hex: "#777777"), line: Color(hex: "#E5E5E5"),
              accent: Color(hex: "#111111"), accent2: Color(hex: "#555555")),
    ]

    static func resolve(_ a: Appearance) -> Theme {
        if a.themeID == "custom" {
            let c = a.custom ?? CustomColors()
            let dark = Color(hex: c.bg).luminance < 0.5
            var t = Theme(id: "custom", name: "Custom", dark: dark, bg: Color(hex: c.bg), card: Color(hex: c.card),
                          text: Color(hex: c.text), muted: Color(hex: c.muted), line: Color(hex: c.card).opacity(0.8),
                          accent: Color(hex: c.accent), accent2: Color(hex: c.accent).opacity(0.75))
            if let hex = a.customAccent { t.accent = Color(hex: hex); t.accent2 = Color(hex: hex).opacity(0.75) }
            return t
        }
        var t = all.first { $0.id == a.themeID } ?? all[0]
        if let hex = a.customAccent {
            t.accent = Color(hex: hex)
            t.accent2 = Color(hex: hex).opacity(0.75)
        }
        return t
    }
}

extension Color {
    init(hex: String) {
        var s = hex.trimmingCharacters(in: .whitespaces)
        if s.hasPrefix("#") { s.removeFirst() }
        let v = UInt64(s, radix: 16) ?? 0x888888
        self.init(.sRGB, red: Double((v >> 16) & 0xFF) / 255, green: Double((v >> 8) & 0xFF) / 255, blue: Double(v & 0xFF) / 255)
    }

    var hexString: String {
        let c = NSColor(self).usingColorSpace(.sRGB) ?? .gray
        return String(format: "#%02X%02X%02X", Int(round(c.redComponent * 255)), Int(round(c.greenComponent * 255)), Int(round(c.blueComponent * 255)))
    }
}

extension Color {
    /// 0 (black) … 1 (white)
    var luminance: Double {
        let c = NSColor(self).usingColorSpace(.sRGB) ?? .gray
        return 0.2126 * c.redComponent + 0.7152 * c.greenComponent + 0.0722 * c.blueComponent
    }
}

/// Blends two colors the way the Windows School Schedule Manager does for its timeline:
/// mostly a straight RGB blend, with a little hue/saturation blending mixed in (85% / 15%).
enum ColorMix {
    static func lerp(_ a: Color, _ b: Color, _ t: Double) -> Color {
        let c1 = NSColor(a).usingColorSpace(.sRGB) ?? .gray, c2 = NSColor(b).usingColorSpace(.sRGB) ?? .gray
        func l(_ x: Double, _ y: Double) -> Double { x + (y - x) * t }
        let rgb = (l(c1.redComponent, c2.redComponent), l(c1.greenComponent, c2.greenComponent), l(c1.blueComponent, c2.blueComponent))
        var h1 = c1.hueComponent, h2 = c2.hueComponent
        let s1 = c1.saturationComponent, s2 = c2.saturationComponent, v1 = c1.brightnessComponent, v2 = c2.brightnessComponent
        if s1 == 0 || v1 == 0 { h1 = h2 }
        if s2 == 0 || v2 == 0 { h2 = h1 }
        if h2 - h1 > 0.5 { h1 += 1 } else if h2 - h1 < -0.5 { h2 += 1 }
        let hsv = NSColor(hue: l(h1, h2).truncatingRemainder(dividingBy: 1), saturation: l(s1, s2), brightness: l(v1, v2), alpha: 1)
            .usingColorSpace(.sRGB) ?? .gray
        func mix(_ x: Double, _ y: Double) -> Double { (1.7 * x + 0.3 * y) / 2 }
        return Color(.sRGB, red: mix(rgb.0, hsv.redComponent), green: mix(rgb.1, hsv.greenComponent), blue: mix(rgb.2, hsv.blueComponent))
    }

    /// A gradient from one class color to the next, with blended stops in between.
    static func gradient(_ a: Color, _ b: Color, on: Bool) -> LinearGradient {
        guard on else { return LinearGradient(colors: [a, a], startPoint: .top, endPoint: .bottom) }
        return LinearGradient(colors: stride(from: 0.0, through: 1.0, by: 0.25).map { lerp(a, b, $0) }, startPoint: .top, endPoint: .bottom)
    }
}
