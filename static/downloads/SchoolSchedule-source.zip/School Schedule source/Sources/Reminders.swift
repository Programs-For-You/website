// School Schedule for Mac. Copyright (c) 2026 Owen Wang (original School Schedule Manager) and Brady Krupa
// (macOS version, ported to macOS using Claude AI). Licensed under the GNU AGPL v3; see LICENSE.
import Foundation
import UserNotifications

/// Schedules Mac notifications for homework (night before / morning of),
/// and asks "Got homework?" when a class ends (you can type the answer right in the notification).
final class Reminders: NSObject, UNUserNotificationCenterDelegate {
    static let shared = Reminders()
    private let center = UNUserNotificationCenter.current()
    private var work: DispatchWorkItem?
    private weak var store: Store?
    private var openQuickAdd: (String?) -> Void = { _ in }

    func setUp(store: Store, openQuickAdd: @escaping (String?) -> Void) {
        self.store = store
        self.openQuickAdd = openQuickAdd
        center.delegate = self
        let add = UNTextInputNotificationAction(identifier: "HW_ADD", title: "Add Homework", options: [],
                                                textInputButtonTitle: "Add", textInputPlaceholder: "e.g. worksheet due Friday, quiz Tuesday")
        let none = UNNotificationAction(identifier: "HW_NONE", title: "No Homework", options: [])
        center.setNotificationCategories([UNNotificationCategory(identifier: "HW_ASK", actions: [add, none], intentIdentifiers: [], options: [])])
    }

    /// "Biology just ended. Got homework?"
    func askAboutHomework(className: String, classKey: String) {
        let c = UNMutableNotificationContent()
        c.title = "\(className) just ended"
        c.body = "Got homework? Click Add Homework and type it. I’ll put it in your plan."
        c.categoryIdentifier = "HW_ASK"
        c.userInfo = ["classKey": classKey]
        c.sound = .default
        center.add(UNNotificationRequest(identifier: "ask-\(UUID().uuidString)", content: c, trigger: nil))
    }

    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification,
                                withCompletionHandler done: @escaping (UNNotificationPresentationOptions) -> Void) {
        done([.banner, .list, .sound])
    }

    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse,
                                withCompletionHandler done: @escaping () -> Void) {
        let info = response.notification.request.content.userInfo
        let key = info["classKey"] as? String
        let isAsk = response.notification.request.content.categoryIdentifier == "HW_ASK"
        switch response.actionIdentifier {
        case "HW_ADD":
            let text = (response as? UNTextInputNotificationResponse)?.userText ?? ""
            DispatchQueue.main.async { [weak self] in
                guard let self, let store = self.store else { return }
                Task { @MainActor in
                    let added = await store.quickAdd(text, classKey: key)
                    self.confirm(added, store: store)
                }
            }
        case "HW_NONE", UNNotificationDismissActionIdentifier:
            break
        default:
            DispatchQueue.main.async { [weak self] in self?.openQuickAdd(isAsk ? key : nil) }
        }
        done()
    }

    private func confirm(_ added: [Homework], store: Store) {
        let c = UNMutableNotificationContent()
        if added.isEmpty {
            c.title = "Didn’t catch that"
            c.body = "Click the clock at the top of your screen and type your homework in the box."
        } else {
            c.title = "Added to your homework plan"
            c.body = added.map { "\($0.title) · \(store.className($0.classKey)) · \($0.kind == .test ? "test" : "due") \(T.nice($0.due))" }.joined(separator: "\n")
        }
        center.add(UNNotificationRequest(identifier: "added-\(UUID().uuidString)", content: c, trigger: nil))
    }

    func requestPermission(_ done: ((Bool) -> Void)? = nil) {
        center.requestAuthorization(options: [.alert, .sound]) { ok, _ in
            DispatchQueue.main.async { done?(ok) }
        }
    }

    /// Rebuilds all homework reminders (called whenever homework or settings change).
    func reschedule(_ data: AppData, store: Store) {
        work?.cancel()
        let w = DispatchWorkItem { [weak self] in self?.apply(data, store: store) }
        work = w
        DispatchQueue.main.asyncAfter(deadline: .now() + 1, execute: w)
    }

    private func apply(_ data: AppData, store: Store) {
        center.getPendingNotificationRequests { [center] pending in
            let old = pending.map(\.identifier).filter { $0.hasPrefix("hw-") }
            center.removePendingNotificationRequests(withIdentifiers: old)
            let r = data.reminders
            guard r.enabled else { return }
            let now = Date()
            for hw in data.homework where !hw.done {
                guard let due = T.date(hw.due) else { continue }
                let cls = data.classes.first { $0.key == hw.classKey }?.name ?? "Homework"
                var times: [(String, Date, String)] = []
                let evening = T.cal.date(bySettingHour: r.eveningHour, minute: 0, second: 0, of: T.addDays(due, -1))!
                let morning = T.cal.date(bySettingHour: r.morningHour, minute: 0, second: 0, of: due)!
                if r.smart {
                    if hw.when == .atNight { times.append(("eve", evening, "Due tomorrow")) }
                    else { times.append(("morn", morning, "Due today, in class")) }
                } else {
                    if r.eveningBefore { times.append(("eve", evening, "Due tomorrow")) }
                    if r.morningOf { times.append(("morn", morning, "Due today")) }
                }
                for (tag, date, lead) in times where date > now {
                    let content = UNMutableNotificationContent()
                    content.title = "\(cls): \(hw.title)"
                    content.body = "\(lead) · \(hw.when.label)"
                    content.sound = .default
                    let comps = T.cal.dateComponents([.year, .month, .day, .hour, .minute], from: date)
                    let req = UNNotificationRequest(identifier: "hw-\(hw.id.uuidString)-\(tag)", content: content,
                                                    trigger: UNCalendarNotificationTrigger(dateMatching: comps, repeats: false))
                    center.add(req)
                }
            }
        }
    }

    func sendTest() {
        requestPermission { [center] ok in
            guard ok else { return }
            let c = UNMutableNotificationContent()
            c.title = "School Schedule"
            c.body = "Reminders are working. You'll get homework reminders like this."
            c.sound = .default
            center.add(UNNotificationRequest(identifier: "test-\(UUID())", content: c,
                                             trigger: UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)))
        }
    }
}
