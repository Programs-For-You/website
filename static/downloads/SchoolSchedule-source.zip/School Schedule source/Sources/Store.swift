// School Schedule for Mac. Copyright (c) 2026 Owen Wang (original School Schedule Manager) and Brady Krupa
// (macOS version, ported to macOS using Claude AI). Licensed under the GNU AGPL v3; see LICENSE.
import AppKit
import SwiftUI

/// Holds all the app's data, saves it to disk, and tells the UI when it changes.
final class Store: ObservableObject {
    @Published var data: AppData { didSet { if data != oldValue { changed() } } }
    @Published var now = Date()
    @Published var quickClass: String?      // class picked in the quick bar (nil = automatic)
    @Published var focusQuickBar = 0        // bump to put the cursor in the quick bar
    var frozenNow = false                    // test snapshots use a fixed time
    var quickTyping = false                  // someone is typing in a homework box (keeps the overlay open)

    var openSettings: () -> Void = {}
    var openSetup: () -> Void = {}
    var togglePinned: () -> Void = {}
    var openLicense: () -> Void = {}
    var toggleCompact: () -> Void = {}
    var onChange: [() -> Void] = []

    private let fileURL: URL
    private var saveWork: DispatchWorkItem?

    init() {
        let dir = ProcessInfo.processInfo.environment["SS_DATA_DIR"].map { URL(fileURLWithPath: $0) }
            ?? FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
                .appendingPathComponent("School Schedule", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        fileURL = dir.appendingPathComponent("data.json")
        if let raw = try? Data(contentsOf: fileURL), let loaded = try? JSONDecoder().decode(AppData.self, from: raw) {
            data = loaded
        } else {
            data = AppData()
        }
        cleanUpOldHomework()
        fixWrongShortDays()
        T.use24h = data.appearance.use24h ?? false
    }

    /// The on/off buttons: make today a short day or an advisory day, or turn it back off. Only changes today.
    func toggleToday(_ type: DayType) {
        let key = T.dayString(now)
        let isOn = engine.dayType(now) == type
        var o = data.dayOverrides ?? [:]
        o[key] = isOn ? DayType.normal.rawValue : type.rawValue
        let cutoff = T.dayString(T.addDays(now, -7))
        data.dayOverrides = o.filter { $0.key >= cutoff }     // forget old days
    }

    /// Goes back to what the school calendar says for today.
    func resetToday() {
        data.dayOverrides?[T.dayString(now)] = nil
    }

    var todayChanged: Bool { data.dayOverrides?[T.dayString(now)] != nil }

    /// Version 1.3.1 fix: WHS was marked as having short days on Nov 19, 20, 23 and 24, 2026, but on the
    /// district calendar those early-release days are only for grades K-8. Saved schedules are fixed once.
    private func fixWrongShortDays() {
        let wrong: Set<String> = ["2026-11-19", "2026-11-20", "2026-11-23", "2026-11-24"]
        guard data.school.isWHS, data.fixedK8Days != true, data.school.shortDays.contains(where: { wrong.contains($0) }) else { return }
        data.school.shortDays.removeAll { wrong.contains($0) }
        data.fixedK8Days = true
        let enc = JSONEncoder()
        enc.outputFormatting = [.prettyPrinted, .sortedKeys]
        if let raw = try? enc.encode(data) { try? raw.write(to: fileURL, options: .atomic) }
    }

    var dataFileURL: URL { fileURL }

    /// Re-reads the settings file (after editing it by hand). Returns an error message if it can't be read.
    func reloadFromDisk() -> String? {
        do {
            let raw = try Data(contentsOf: fileURL)
            data = try JSONDecoder().decode(AppData.self, from: raw)
            return nil
        } catch {
            return "The settings file couldn’t be read, so nothing changed. It may have a typo.\n\n\(error)"
        }
    }

    var engine: Engine { Engine(data: data) }
    var theme: Theme { Theme.resolve(data.appearance) }

    private func changed() {
        T.use24h = data.appearance.use24h ?? false
        saveWork?.cancel()
        let snapshot = data
        let work = DispatchWorkItem { [fileURL] in
            let enc = JSONEncoder()
            enc.outputFormatting = [.prettyPrinted, .sortedKeys]
            if let raw = try? enc.encode(snapshot) { try? raw.write(to: fileURL, options: .atomic) }
        }
        saveWork = work
        DispatchQueue.global(qos: .utility).asyncAfter(deadline: .now() + 0.4, execute: work)
        onChange.forEach { $0() }
    }

    /// Finished homework disappears a week after you check it off.
    private func cleanUpOldHomework() {
        let cutoff = T.dayString(T.addDays(Date(), -7))
        let old = data.homework.filter { $0.done && ($0.doneAt ?? "9999") < cutoff }
        // Finished Schoology homework shouldn't come back the next time the calendar syncs.
        let ids = old.compactMap { $0.fromSchoology ? $0.externalID : nil }
        if !ids.isEmpty { data.schoologyHidden = (data.schoologyHidden ?? []) + ids }
        data.homework.removeAll { $0.done && ($0.doneAt ?? "9999") < cutoff }
    }

    // MARK: Classes

    func classInfo(_ key: String) -> ClassInfo? {
        let base = key.hasSuffix("x") || key.hasSuffix("y") ? String(key.dropLast()) : key
        return data.classes.first { $0.key == key } ?? data.classes.first { $0.key == base }
    }

    func className(_ key: String) -> String { classInfo(key)?.name ?? (key == Schoology.source ? "Schoology" : "Class") }

    /// Keeps the rotation plans the right size after periods or rotation length change.
    func normalizePlans() {
        var s = data.school
        let n = max(1, s.rotationLength)
        let slots = s.classPeriodCount
        let keys = data.classes.map(\.key)
        while s.plans.count < n { s.plans.append(DayPlan(slots: [])) }
        if s.plans.count > n { s.plans.removeLast(s.plans.count - n) }
        for d in 0..<n {
            var p = s.plans[d].slots
            while p.count < slots { p.append(keys.isEmpty ? "" : keys[(p.count + d) % keys.count]) }
            if p.count > slots { p.removeLast(p.count - slots) }
            s.plans[d].slots = p
        }
        if var lw = s.lunchWaves {
            while lw.wavePerDay.count < n { lw.wavePerDay.append(1) }
            if lw.wavePerDay.count > n { lw.wavePerDay.removeLast(lw.wavePerDay.count - n) }
            s.lunchWaves = lw
        }
        if s != data.school { data.school = s }
    }

    // MARK: Homework

    func toggle(_ hw: Homework) {
        guard let i = data.homework.firstIndex(where: { $0.id == hw.id }) else { return }
        data.homework[i].done.toggle()
        data.homework[i].doneAt = data.homework[i].done ? T.dayString(Date()) : nil
    }

    func delete(_ hw: Homework) {
        // Deleted Schoology homework stays deleted the next time the calendar syncs.
        if hw.fromSchoology, let id = hw.externalID { data.schoologyHidden = (data.schoologyHidden ?? []) + [id] }
        data.homework.removeAll { $0.id == hw.id }
    }

    func setClass(_ hw: Homework, _ key: String) {
        guard let i = data.homework.firstIndex(where: { $0.id == hw.id }) else { return }
        data.homework[i].classKey = key
    }

    /// The next school day this class meets (for "due next class").
    func nextClassDay(for key: String, after date: Date = Date()) -> Date? { engine.nextClassDay(for: key, after: date) }

    func baseKey(_ key: String) -> String { key.hasSuffix("x") || key.hasSuffix("y") ? String(key.dropLast()) : key }

    // MARK: Quick homework (type it, the app sorts it out)

    /// The class the quick bar uses when the note doesn't say: the one you picked, or the class you're in / just left.
    func defaultClassKey(_ date: Date = Date()) -> String? {
        if let q = quickClass { return q }
        return engine.recentClass(date)?.classKey.map(baseKey)
    }

    func quickContext(defaultKey: String?) -> HomeworkAI.Context {
        let e = engine
        return HomeworkAI.Context(classes: data.classes, defaultKey: defaultKey, now: Date(),
                                  nextClassDay: { e.nextClassDay(for: $0, after: Date()) },
                                  nextSchoolDay: { e.nextSchoolDay(after: Date()) })
    }

    /// Reads a quick note like "bio worksheet due fri, math test thursday" and adds the homework.
    @MainActor
    func quickAdd(_ text: String, classKey: String?) async -> [Homework] {
        let parsed = await HomeworkAI.parse(text, quickContext(defaultKey: classKey ?? defaultClassKey()))
        let added = parsed.map {
            Homework(classKey: $0.classKey, title: $0.title, due: T.dayString($0.due),
                     when: $0.kind == .test ? .inClass : .atNight, kind: $0.kind, minutes: $0.minutes)
        }
        data.homework += added
        return added
    }

    func remove(_ items: [Homework]) {
        let ids = Set(items.map(\.id))
        data.homework.removeAll { ids.contains($0.id) }
    }

    func setMinutes(_ hw: Homework, _ minutes: Int) {
        guard let i = data.homework.firstIndex(where: { $0.id == hw.id }) else { return }
        data.homework[i].minutes = minutes
    }

    /// Checks off (or un-checks) today's piece of the plan. Finishing the last piece marks the homework done.
    func toggleSession(_ hw: Homework, minutes: Int, on day: String = T.dayString(Date())) {
        guard let i = data.homework.firstIndex(where: { $0.id == hw.id }) else { return }
        var h = data.homework[i]
        var log = h.workLog ?? [:]
        if log[day] != nil {
            log[day] = nil
            h.workLog = log.isEmpty ? nil : log
            if h.done && h.remaining > 0 { h.done = false; h.doneAt = nil }
        } else {
            log[day] = minutes
            h.workLog = log
            if h.remaining == 0 { h.done = true; h.doneAt = day }
        }
        data.homework[i] = h
    }
}
