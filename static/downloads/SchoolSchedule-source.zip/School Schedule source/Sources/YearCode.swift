// School Schedule for Mac. Copyright (c) 2026 Owen Wang (original School Schedule Manager) and Brady Krupa
// (macOS version, ported to macOS using Claude AI). Licensed under the GNU AGPL v3; see LICENSE.
import Foundation

/// The "Yearly Info" import code from the Windows School Schedule Manager, e.g.
/// "Year:2026;Adv:3;Limit:CGGK;NoS:…;Short:…". It packs the school year's first and last day,
/// the advisory weekday, days off, and short days into a short code people can share.
enum YearCode {
    private static let digits = Array("0123456789ABCDEFGHIJ")

    struct Info: Equatable {
        var year: Int
        var advisoryWeekday: Int?      // Calendar weekday (1 = Sunday … 5 = Thursday)
        var start: String?
        var end: String?
        var daysOff: [String]
        var shortDays: [String]
    }

    /// "M,D" pairs ↔ two characters each.
    private static func decodeDates(_ s: String) -> [(Int, Int)]? {
        let chars = Array(s.uppercased())
        guard chars.count % 2 == 0 else { return nil }
        var out: [(Int, Int)] = []
        for i in stride(from: 0, to: chars.count, by: 2) {
            guard let a = digits.firstIndex(of: chars[i]), let b = digits.firstIndex(of: chars[i + 1]) else { return nil }
            let n = a * 20 + b + 30
            out.append((n / 31, n % 31 + 1))
        }
        return out
    }

    private static func encodeDates(_ dates: [(Int, Int)]) -> String {
        dates.map { m, d in
            let n = 31 * m + d - 31
            return String([digits[n / 20], digits[n % 20]])
        }.joined()
    }

    /// School-year dates: August–December are in `year`, January–July in the next year.
    private static func full(_ md: (Int, Int), _ year: Int) -> String {
        String(format: "%04d-%02d-%02d", md.0 >= 8 ? year : year + 1, md.0, md.1)
    }

    static func decode(_ code: String) -> Info? {
        var info = Info(year: 0, advisoryWeekday: nil, start: nil, end: nil, daysOff: [], shortDays: [])
        var pending: [(String, [(Int, Int)])] = []
        for part in code.trimmingCharacters(in: .whitespacesAndNewlines).split(separator: ";") {
            let kv = part.split(separator: ":", maxSplits: 1).map { $0.trimmingCharacters(in: .whitespaces) }
            guard kv.count == 2 else { continue }
            switch kv[0] {
            case "Year": guard let y = Int(kv[1]) else { return nil }; info.year = y
            case "Adv": if let py = Int(kv[1]), (0...6).contains(py) { info.advisoryWeekday = (py + 1) % 7 + 1 }   // Python Monday=0 → Calendar Monday=2
            case "Limit", "NoS", "Short": guard let d = decodeDates(kv[1]) else { return nil }; pending.append((kv[0], d))
            default: break
            }
        }
        guard info.year > 2000 else { return nil }
        for (key, dates) in pending {
            let days = dates.map { full($0, info.year) }
            switch key {
            case "Limit": info.start = days.first; info.end = days.count > 1 ? days[1] : nil
            case "NoS": info.daysOff = days
            default: info.shortDays = days
            }
        }
        return info
    }

    static func encode(_ s: School) -> String? {
        guard let ys = s.yearStart, let year = Int(ys.prefix(4)) else { return nil }
        func md(_ day: String) -> (Int, Int)? {
            let p = day.split(separator: "-").compactMap { Int($0) }
            return p.count == 3 ? (p[1], p[2]) : nil
        }
        let off = s.daysOff.flatMap { r -> [String] in
            guard let a = T.date(r.start), let b = T.date(r.end), a <= b else { return [r.start] }
            var out: [String] = [], d = a
            while d <= b { out.append(T.dayString(d)); d = T.addDays(d, 1) }
            return out
        }
        let adv = s.advisoryWeekday.map { ($0 + 5) % 7 } ?? 3        // Calendar weekday → Python weekday
        return "Year:\(year);Adv:\(adv);Limit:\(encodeDates([ys, s.yearEnd ?? ys].compactMap(md)));NoS:\(encodeDates(off.compactMap(md)));Short:\(encodeDates(s.shortDays.compactMap(md)))"
    }

    /// Puts the code's dates into the school.
    static func apply(_ info: Info, to s: inout School) {
        s.yearStart = info.start
        s.yearEnd = info.end
        s.daysOff = info.daysOff.map { DayRange(start: $0, end: $0) }
        s.shortDays = info.shortDays
        if let a = info.advisoryWeekday { s.advisoryWeekday = a }
        s.anchor = nil
    }
}
