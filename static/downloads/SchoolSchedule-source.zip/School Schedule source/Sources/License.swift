// School Schedule for Mac. Copyright (c) 2026 Owen Wang (original School Schedule Manager) and Brady Krupa
// (macOS version, ported to macOS using Claude AI). Licensed under the GNU AGPL v3; see LICENSE.
import AppKit
import SwiftUI

/// School Schedule is based on Owen Wang's School Schedule Manager (Windows), which is licensed under
/// the GNU Affero General Public License v3. The Mac version keeps that license and adds its own credit.
enum License {
    static let id = "AGPL-3.0"
    static let credits = """
    School Schedule for Mac
    Original School Schedule Manager (Windows): Copyright (c) 2026 Owen Wang (@un-undefined on GitHub)
    macOS version: Copyright (c) 2026 Brady Krupa. This was ported to macOS using Claude AI.
    Free software under the GNU Affero General Public License, version 3.
    """
    static let sourceURL = URL(string: "https://programsforyou.com/downloads/SchoolSchedule-source.zip")!
    static let originalURL = URL(string: "https://github.com/un-undefined/school-schedule-manager")!
    static let feedbackURL = URL(string: "mailto:bradykrupa@programsforyou.com?subject=School%20Schedule%20for%20Mac")!

    /// The full license text (shipped inside the app as LICENSE).
    static var text: String {
        let candidates = [Bundle.main.url(forResource: "LICENSE", withExtension: nil),
                          ProcessInfo.processInfo.environment["SS_LICENSE_PATH"].map { URL(fileURLWithPath: $0) }]
        for url in candidates.compactMap({ $0 }) {
            if let t = try? String(contentsOf: url, encoding: .utf8) { return t }
        }
        return credits + "\n\nThe full license text is at https://www.gnu.org/licenses/agpl-3.0.txt"
    }
}

struct LicenseView: View {
    let firstRun: Bool
    var accept: () -> Void = {}
    var quit: () -> Void = {}
    var close: () -> Void = {}

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 12) {
                Image(nsImage: NSApp.applicationIconImage).resizable().frame(width: 48, height: 48)
                VStack(alignment: .leading, spacing: 2) {
                    Text(firstRun ? "Before you start" : "License").font(.title2.weight(.bold))
                    Text("School Schedule is free software, made by Owen Wang and Brady Krupa.").foregroundStyle(.secondary)
                }
            }
            if firstRun {
                Text("It’s based on Owen Wang’s School Schedule Manager for Windows and shares its license, the GNU AGPL v3. You can use it for free, and you can get, change, and share its source code under that license. Please read it and click Accept to continue.")
                    .fixedSize(horizontal: false, vertical: true)
            }
            ScrollView {
                Text(License.text).font(.system(size: 11, design: .monospaced)).textSelection(.enabled)
                    .frame(maxWidth: .infinity, alignment: .leading).padding(10)
            }
            .background(Color(nsColor: .textBackgroundColor))
            .clipShape(RoundedRectangle(cornerRadius: 8))
            .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.secondary.opacity(0.25)))
            HStack {
                Link("Get the source code", destination: License.sourceURL)
                Text("·").foregroundStyle(.secondary)
                Link("Original app on GitHub", destination: License.originalURL)
                Spacer()
                if firstRun {
                    Button("Quit", action: quit)
                    Button("Accept", action: accept).keyboardShortcut(.defaultAction)
                } else {
                    Button("Close", action: close).keyboardShortcut(.defaultAction)
                }
            }
        }
        .padding(20)
        .frame(minWidth: 560, minHeight: 500)
    }
}
