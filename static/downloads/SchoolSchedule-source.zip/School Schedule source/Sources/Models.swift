// School Schedule for Mac. Copyright (c) 2026 Owen Wang (original School Schedule Manager) and Brady Krupa
// (macOS version, ported to macOS using Claude AI). Licensed under the GNU AGPL v3; see LICENSE.
import Foundation

// MARK: - Basic types

/// What kind of time a period is.
enum PeriodKind: String, Codable, CaseIterable, Identifiable {
    case classTime, lunch, advisory, other
    var id: String { rawValue }
    var label: String {
        switch self {
        case .classTime: return "Class"
        case .lunch: return "Lunch"
        case .advisory: return "Advisory"
        case .other: return "Other"
        }
    }
}

/// One period in a bell schedule. Times are minutes after midnight (8:20 AM = 500).
struct Period: Codable, Identifiable, Equatable {
    var id = UUID()
    var name: String
    var start: Int
    var end: Int
    var kind: PeriodKind = .classTime
}

/// Which class meets in each class period on one rotation day ("" = free period).
struct DayPlan: Codable, Equatable {
    var slots: [String]
}

/// Lunch that happens in the middle of a class period (WHS style: lunch waves inside 3rd block).
struct LunchWaves: Codable, Equatable {
    var classSlot: Int                    // which class period (0-based) lunch happens inside
    var waves: [String: [[Int]]]          // schedule key → list of [start, end]
    var wavePerDay: [Int]                 // rotation day → wave number (1-based)
}

/// A date range with no school (one day if start == end). Dates are "yyyy-MM-dd".
struct DayRange: Codable, Identifiable, Equatable {
    var id = UUID()
    var start: String
    var end: String
    var name: String = ""
}

/// "Today is Day N" — the rotation counts forward from here.
struct DayAnchor: Codable, Equatable {
    var date: String
    var day: Int
}

/// Everything about how a school's day works.
struct School: Codable, Equatable {
    var templateID: String?                 // "whs" for the built-in schedule
    var name: String
    var rotationLength: Int                 // 1 = same classes every day
    var schedules: [String: [Period]]       // "normal", optional "advisory" and "short"
    var plans: [DayPlan]                    // one per rotation day
    var lunchWaves: LunchWaves?
    var advisoryWeekday: Int?               // Calendar weekday (1 = Sunday … 5 = Thursday)
    var yearStart: String?
    var yearEnd: String?
    var daysOff: [DayRange] = []
    var shortDays: [String] = []
    var anchor: DayAnchor?

    var isWHS: Bool { templateID == "whs" }
    var classPeriodCount: Int { (schedules["normal"] ?? []).filter { $0.kind == .classTime }.count }
}

/// A mini class: one half of a class period on one rotation day.
struct MiniClass: Codable, Identifiable, Equatable {
    var id = UUID()
    var day: Int        // rotation day (1-based)
    var half: Int       // 0 = first half, 1 = second half
    var name: String
}

struct ClassInfo: Codable, Identifiable, Equatable {
    var id = UUID()
    var key: String     // "1" … "8" for WHS, or "P1" … for custom schools
    var name: String
    var colorHex: String
    var minis: [MiniClass] = []
    var icon: String? = nil            // SF Symbol name (nil = picked from the class name)

    var symbol: String { icon ?? Icons.guess(name) }
}

enum HomeworkWhen: String, Codable, CaseIterable, Identifiable {
    case inClass, atNight
    var id: String { rawValue }
    var label: String { self == .inClass ? "In class" : "At night" }
}

/// What sort of homework it is (decides how long it takes and how the plan spreads it out).
enum HomeworkKind: String, Codable, CaseIterable, Identifiable {
    case assignment, reading, test, project
    var id: String { rawValue }
    var label: String {
        switch self {
        case .assignment: return "Assignment"
        case .reading: return "Reading"
        case .test: return "Test or quiz"
        case .project: return "Project"
        }
    }
    var defaultMinutes: Int {
        switch self {
        case .assignment: return 25
        case .reading: return 25
        case .test: return 60
        case .project: return 120
        }
    }
}

struct Homework: Codable, Identifiable, Equatable {
    var id = UUID()
    var classKey: String
    var title: String
    var due: String          // "yyyy-MM-dd"
    var when: HomeworkWhen
    var done = false
    var doneAt: String?
    // Added in 1.1 (optional so older saved data still loads):
    var kind: HomeworkKind? = nil
    var minutes: Int? = nil              // how long it should take
    var workLog: [String: Int]? = nil    // day → minutes worked that day (from the plan)
    // Added in 1.3.7 (homework brought in from your Schoology calendar):
    var source: String? = nil            // "schoology", or nil if you typed it
    var externalID: String? = nil        // the calendar item's ID, so it's updated instead of added twice
    var link: String? = nil              // opens the assignment in Schoology

    var fromSchoology: Bool { source == "schoology" }

    var estimate: Int { minutes ?? (kind ?? .assignment).defaultMinutes }
    var minutesDone: Int { workLog?.values.reduce(0, +) ?? 0 }
    var remaining: Int { max(0, estimate - minutesDone) }
    /// Old "in class" items are classwork; everything else goes in the homework plan.
    var isPlanned: Bool { kind != nil || when == .atNight }
}

struct AfterSchoolEvent: Codable, Identifiable, Equatable {
    var id = UUID()
    var name: String
    var start: Int
    var end: Int
    var weekdays: [Int]      // Calendar weekdays (2 = Monday … 6 = Friday)
    var schoolDaysOnly = true
    var date: String? = nil  // set for a one-time event on this day ("yyyy-MM-dd"); weekdays are then ignored
}

struct ReminderSettings: Codable, Equatable {
    var enabled = true
    var smart = true            // at-night homework → evening before; in-class → morning of
    var eveningBefore = true
    var morningOf = true
    var eveningHour = 19
    var morningHour = 7
}

struct Appearance: Codable, Equatable {
    var themeID = "modernDark"
    var customAccent: String? = nil
    var showCountdownInMenuBar = true
    var showSeconds: Bool? = nil         // menu bar shows 23:41 instead of 23m
    // Added in 1.2 (from the Windows School Schedule Manager):
    var use24h: Bool? = nil              // 14:30 instead of 2:30 PM
    var classColorAccent: Bool? = nil    // highlight with the current class's color (default on)
    var timelineGradient: Bool? = nil    // blend class colors along the timeline (default on)
    var sharpCorners: Bool? = nil
    var monoFont: Bool? = nil
    var custom: CustomColors? = nil      // colors for the "Custom" theme

    var usesClassColor: Bool { classColorAccent ?? true }
    var gradientOn: Bool { timelineGradient ?? true }
    var radius: CGFloat { sharpCorners == true ? 3 : 12 }
}

/// Your own colors (Settings → Look → Custom), like "Edit Style" in the Windows app.
struct CustomColors: Codable, Equatable {
    var bg = "#282828"
    var card = "#373737"
    var text = "#FFFFFF"
    var muted = "#B4B4B4"
    var accent = "#4C8BF5"
}

/// All saved data.
struct AppData: Codable, Equatable {
    var version = 1
    var setupDone = false
    var school: School = Templates.whs()
    var classes: [ClassInfo] = Templates.whsClasses()
    var homework: [Homework] = []
    var events: [AfterSchoolEvent] = []
    var reminders = ReminderSettings()
    var appearance = Appearance()
    var advisoryEnabled = true
    // Added in 1.1 (optional so older saved data still loads):
    var askAfterClass: Bool? = nil       // nil = on
    var keepOnScreen: Bool? = nil        // floating window that stays on screen
    var compactOnScreen: Bool? = nil
    var nightlyMinutes: Int? = nil       // homework time on a school night (default 120)
    // Added in 1.2:
    var onScreenStyle: String? = nil     // "card" (floating card) or "bar" (overlay bar, like the Windows app)
    var overlayOpacity: Double? = nil    // 0.35…1
    var overlayScale: Double? = nil      // 0.8…1.5
    var overlayCorner: String? = nil     // "bottomLeft", "bottomRight", "topLeft", "topRight"
    var clickThrough: Bool? = nil        // the bar lets clicks pass through until you hover on it
    var licenseAccepted: String? = nil   // which license the person accepted on first launch
    var fixedK8Days: Bool? = nil         // 1.3.1: removed the K-8-only short days (Nov 19, 20, 23, 24) from WHS
    var dayOverrides: [String: String]? = nil   // the on/off buttons: "2026-11-19": "short", "advisory" or "normal"
    // Added in 1.3.7: your Schoology calendar (Settings → Schoology).
    var schoologyURL: String? = nil      // the private iCal link from Schoology → Calendar → Export
    var schoologyLastSync: String? = nil // when it last synced (ISO 8601)
    var schoologyError: String? = nil    // why the last sync didn't work
    var schoologyHidden: [String]? = nil // Schoology items you deleted, so they don't come back

    var asksAfterClass: Bool { askAfterClass ?? true }
    var nightlyCap: Int { nightlyMinutes ?? 120 }
    var barStyle: Bool { onScreenStyle == "bar" }
    var opacity: Double { overlayOpacity ?? 0.9 }
    var scale: Double { overlayScale ?? 1 }
    var corner: String { overlayCorner ?? "bottomLeft" }
    var passThrough: Bool { clickThrough ?? true }
}

// MARK: - Time helpers

enum T {
    static func m(_ h: Int, _ min: Int) -> Int { h * 60 + min }

    /// Set from Settings → Look ("14:30" instead of "2:30 PM").
    static var use24h = false

    /// 500 → "8:20 AM"
    static func clock(_ minutes: Int) -> String {
        let h = (minutes / 60) % 24, mm = minutes % 60
        if use24h { return String(format: "%d:%02d", h, mm) }
        let h12 = h % 12 == 0 ? 12 : h % 12
        return String(format: "%d:%02d %@", h12, mm, h < 12 ? "AM" : "PM")
    }

    /// 500 → "8:20"
    static func short(_ minutes: Int) -> String {
        let h = (minutes / 60) % 24, mm = minutes % 60
        if use24h { return String(format: "%d:%02d", h, mm) }
        let h12 = h % 12 == 0 ? 12 : h % 12
        return String(format: "%d:%02d", h12, mm)
    }

    /// 75 → "1h 15m", 12 → "12m", 0 → "<1m"
    static func duration(_ minutes: Int) -> String {
        if minutes <= 0 { return "<1m" }
        if minutes < 60 { return "\(minutes)m" }
        let h = minutes / 60, mm = minutes % 60
        return mm == 0 ? "\(h)h" : "\(h)h \(mm)m"
    }

    static let cal = Calendar.current

    static func dayString(_ date: Date) -> String {
        let c = cal.dateComponents([.year, .month, .day], from: date)
        return String(format: "%04d-%02d-%02d", c.year!, c.month!, c.day!)
    }

    static func date(_ s: String) -> Date? {
        let p = s.split(separator: "-").compactMap { Int($0) }
        guard p.count == 3 else { return nil }
        return cal.date(from: DateComponents(year: p[0], month: p[1], day: p[2]))
    }

    static func minutesNow(_ date: Date = Date()) -> Int {
        let c = cal.dateComponents([.hour, .minute], from: date)
        return (c.hour ?? 0) * 60 + (c.minute ?? 0)
    }

    static func addDays(_ date: Date, _ n: Int) -> Date { cal.date(byAdding: .day, value: n, to: date)! }

    static func secondsNow(_ date: Date = Date()) -> Int {
        let c = cal.dateComponents([.hour, .minute, .second], from: date)
        return (c.hour ?? 0) * 3600 + (c.minute ?? 0) * 60 + (c.second ?? 0)
    }

    /// 1421 → "23:41", 4000 → "1:06:40"
    static func timer(_ seconds: Int) -> String {
        let s = max(0, seconds)
        let h = s / 3600, m = s % 3600 / 60, sec = s % 60
        return h > 0 ? String(format: "%d:%02d:%02d", h, m, sec) : String(format: "%d:%02d", m, sec)
    }

    static func nice(_ dayString: String, relativeTo today: Date = Date()) -> String {
        guard let d = date(dayString) else { return dayString }
        let todayStart = cal.startOfDay(for: today)
        let diff = cal.dateComponents([.day], from: todayStart, to: d).day ?? 0
        switch diff {
        case 0: return "Today"
        case 1: return "Tomorrow"
        case -1: return "Yesterday"
        default:
            let f = DateFormatter()
            f.dateFormat = (2...6).contains(diff) ? "EEEE" : "EEE, MMM d"
            return f.string(from: d)
        }
    }
}

// MARK: - Built-in WHS schedule (2026–27)

enum Templates {
    static let palette = ["#4C8BF5", "#2EA84B", "#8C46E6", "#E64D80", "#D99B26", "#2CA5C4", "#E5603B", "#5B6B8C", "#B5482F", "#3AAE9B"]

    static func whs() -> School {
        func p(_ n: String, _ a: (Int, Int), _ b: (Int, Int), _ k: PeriodKind = .classTime) -> Period {
            Period(name: n, start: T.m(a.0, a.1), end: T.m(b.0, b.1), kind: k)
        }
        let normal = [
            p("1st Block", (8, 20), (9, 46)), p("2nd Block", (9, 53), (11, 19)),
            p("3rd Block", (11, 26), (13, 22)), p("4th Block", (13, 29), (14, 55)),
        ]
        let advisory = [
            p("1st Block", (8, 20), (9, 39)), p("2nd Block", (9, 46), (11, 5)),
            p("Advisory", (11, 12), (11, 37), .advisory),
            p("3rd Block", (11, 44), (13, 29)), p("4th Block", (13, 36), (14, 55)),
        ]
        let short = [
            p("1st Block", (8, 20), (9, 19)), p("2nd Block", (9, 26), (10, 24)),
            p("3rd Block", (10, 31), (11, 29)), p("4th Block", (11, 36), (12, 35)),
        ]
        func w(_ a: (Int, Int), _ b: (Int, Int)) -> [Int] { [T.m(a.0, a.1), T.m(b.0, b.1)] }
        let waves = LunchWaves(
            classSlot: 2,
            waves: [
                "normal": [w((11, 24), (11, 54)), w((11, 54), (12, 24)), w((12, 9), (12, 39)), w((12, 24), (12, 54)), w((12, 54), (13, 24))],
                "advisory": [w((11, 44), (12, 14)), w((12, 9), (12, 39)), w((12, 26), (12, 56)), w((12, 34), (13, 4)), w((12, 59), (13, 29))],
            ],
            wavePerDay: [1, 1, 1, 1]
        )
        // "M,D" dates from the school calendar → real dates in the 2026–27 year.
        func d(_ md: String) -> String {
            let p = md.split(separator: ",").compactMap { Int($0) }
            let year = p[0] >= 8 ? 2026 : 2027
            return String(format: "%04d-%02d-%02d", year, p[0], p[1])
        }
        let off = ["9,7", "9,21", "10,12", "10,13", "10,21", "11,3", "11,25", "11,26", "11,27", "12,24", "12,25", "12,28", "12,29", "12,30", "12,31", "1,1", "1,18", "2,15", "2,16", "2,17", "2,18", "2,19", "3,26", "4,12", "4,13", "4,14", "4,15", "4,16", "5,31"]
        // Nov 19, 20, 23 and 24 are NOT here: on the district calendar those are K-8 conference days only.
        let short_ = ["9,9", "11,2", "12,9", "12,23", "1,13", "1,19", "1,20", "3,10", "4,7", "6,9", "6,10", "6,11"]
        return School(
            templateID: "whs",
            name: "WHS",
            rotationLength: 4,
            schedules: ["normal": normal, "advisory": advisory, "short": short],
            plans: [DayPlan(slots: ["1", "3", "5", "7"]), DayPlan(slots: ["2", "4", "6", "8"]),
                    DayPlan(slots: ["3", "1", "7", "5"]), DayPlan(slots: ["4", "2", "8", "6"])],
            lunchWaves: waves,
            advisoryWeekday: 5, // Thursday
            yearStart: "2026-08-25",
            yearEnd: "2027-06-11",
            daysOff: off.map { DayRange(start: d($0), end: d($0)) },
            shortDays: short_.map(d)
        )
    }

    static func whsClasses() -> [ClassInfo] {
        (1...8).map { ClassInfo(key: "\($0)", name: "Period \($0)", colorHex: palette[($0 - 1) % palette.count]) }
    }

    /// A simple starting point for any other school: 7 periods, same classes every day.
    static func custom(name: String = "My School") -> School {
        var periods: [Period] = []
        var t = T.m(8, 0)
        for i in 1...7 {
            if i == 5 { periods.append(Period(name: "Lunch", start: t, end: t + 30, kind: .lunch)); t += 35 }
            periods.append(Period(name: "Period \(i)", start: t, end: t + 50))
            t += 55
        }
        return School(templateID: nil, name: name, rotationLength: 1, schedules: ["normal": periods],
                      plans: [DayPlan(slots: (1...7).map { "P\($0)" })], lunchWaves: nil, advisoryWeekday: nil,
                      yearStart: nil, yearEnd: nil, anchor: nil)
    }

    static func customClasses(count: Int = 7) -> [ClassInfo] {
        (1...count).map { ClassInfo(key: "P\($0)", name: "Period \($0)", colorHex: palette[($0 - 1) % palette.count]) }
    }
}
