// School Schedule for Mac. Copyright (c) 2026 Owen Wang (original School Schedule Manager) and Brady Krupa
// (macOS version, ported to macOS using Claude AI). Licensed under the GNU AGPL v3; see LICENSE.
import Foundation

enum DayType: String {
    case normal, advisory, short, noSchool
    var label: String? {
        switch self {
        case .advisory: return "Advisory day"
        case .short: return "Short day"
        default: return nil
        }
    }
}

enum ItemKind { case classTime, lunch, advisory, other, event }

struct Item: Identifiable, Equatable {
    var id: String { "\(start)-\(end)-\(title)" }
    var title: String
    var detail: String?
    var start: Int
    var end: Int
    var kind: ItemKind
    var colorHex: String?
    var classKey: String?
}

enum NowState: Equatable {
    case noSchool
    case before(next: Item, minutes: Int)
    case during(Item, left: Int, progress: Double, next: Item?)
    case passing(next: Item, minutes: Int)
    case freeTime(until: Item, minutes: Int)
    case event(Item, left: Int)
    case done
}

/// Works out the schedule for any day: which rotation day it is, the periods, and lunch.
struct Engine {
    let data: AppData
    var school: School { data.school }

    // MARK: Days

    func isSchoolDay(_ date: Date) -> Bool {
        let wd = T.cal.component(.weekday, from: date)
        if wd == 1 || wd == 7 { return false }
        let s = T.dayString(date)
        if let ys = school.yearStart, s < ys { return false }
        if let ye = school.yearEnd, s > ye { return false }
        return !school.daysOff.contains { $0.start <= s && s <= $0.end }
    }

    func dayType(_ date: Date) -> DayType {
        guard isSchoolDay(date) else { return .noSchool }
        let s = T.dayString(date)
        // The Short day / Advisory buttons win over the school calendar for that one day.
        if let o = data.dayOverrides?[s], let t = DayType(rawValue: o), t != .noSchool,
           t == .normal || school.schedules[t.rawValue] != nil { return t }
        if school.shortDays.contains(s), school.schedules["short"] != nil { return .short }
        if data.advisoryEnabled, let aw = school.advisoryWeekday, school.schedules["advisory"] != nil,
           T.cal.component(.weekday, from: date) == aw { return .advisory }
        return .normal
    }

    /// Day 1, 2, 3… of the rotation, or nil when there's no school.
    func rotationDay(_ date: Date) -> Int? {
        guard isSchoolDay(date) else { return nil }
        let n = max(1, school.rotationLength)
        if n == 1 { return 1 }
        let target = T.cal.startOfDay(for: date)
        if let a = school.anchor, let ad = T.date(a.date), ad <= target {
            var count = 0
            var d = T.addDays(ad, 1)
            while d <= target { if isSchoolDay(d) { count += 1 }; d = T.addDays(d, 1) }
            if !isSchoolDay(ad) { count -= 1 } // anchor set on a day off: next school day is that day
            return ((a.day - 1 + max(0, count)) % n + n) % n + 1
        }
        if let ys = school.yearStart, let sd = T.date(ys), sd <= target {
            var count = 0
            var d = sd
            while d <= target { if isSchoolDay(d) { count += 1 }; d = T.addDays(d, 1) }
            return (max(1, count) - 1) % n + 1
        }
        return 1
    }

    func nextSchoolDay(after date: Date) -> Date? {
        var d = T.addDays(T.cal.startOfDay(for: date), 1)
        for _ in 0..<120 {
            if isSchoolDay(d) { return d }
            d = T.addDays(d, 1)
        }
        return nil
    }

    // MARK: Periods for a day

    func items(for date: Date) -> [Item] {
        let type = dayType(date)
        guard type != .noSchool, let rot = rotationDay(date) else { return [] }
        let key = type.rawValue
        let periods = (school.schedules[key] ?? school.schedules["normal"] ?? []).sorted { $0.start < $1.start }
        let plan = school.plans.indices.contains(rot - 1) ? school.plans[rot - 1] : DayPlan(slots: [])
        var out: [Item] = []
        var classIndex = 0
        for p in periods {
            switch p.kind {
            case .classTime:
                let ckey = plan.slots.indices.contains(classIndex) ? plan.slots[classIndex] : ""
                var lunch: (Int, Int)?
                if let lw = school.lunchWaves, lw.classSlot == classIndex, let waves = lw.waves[key], !waves.isEmpty {
                    let wave = lw.wavePerDay.indices.contains(rot - 1) ? lw.wavePerDay[rot - 1] : 1
                    let w = waves[min(max(wave, 1), waves.count) - 1]
                    lunch = (w[0], w[1])
                }
                let ps = pieces(for: ckey, day: rot)
                if ps.count == 2, let l = lunch {
                    out += splitAroundLunch(ps, in: p, lunch: l)       // two minis in the lunch block (Owen's math)
                } else {
                    out += layout(ps, in: p, skipping: lunch)
                }
                if let l = lunch { out.append(Item(title: "Lunch", start: l.0, end: l.1, kind: .lunch)) }
                classIndex += 1
            case .lunch:
                out.append(Item(title: p.name.isEmpty ? "Lunch" : p.name, start: p.start, end: p.end, kind: .lunch))
            case .advisory:
                out.append(Item(title: p.name.isEmpty ? "Advisory" : p.name, start: p.start, end: p.end, kind: .advisory))
            case .other:
                out.append(Item(title: p.name, start: p.start, end: p.end, kind: .other))
            }
        }
        out.sort { ($0.start, $0.end) < ($1.start, $1.end) }
        // Join the two halves of a class back together when they're the same class.
        var merged: [Item] = []
        for item in out {
            if let last = merged.last, last.kind == .classTime, item.kind == .classTime,
               last.classKey == item.classKey, last.title == item.title, last.end == item.start {
                merged[merged.count - 1].end = item.end
            } else {
                merged.append(item)
            }
        }
        return merged
    }

    func events(for date: Date) -> [Item] {
        let wd = T.cal.component(.weekday, from: date)
        let school = isSchoolDay(date)
        let day = T.dayString(date)
        return data.events
            .filter { ev in
                if let d = ev.date { return d == day }          // one-time event
                return ev.weekdays.contains(wd) && (!ev.schoolDaysOnly || school)
            }
            .map { Item(title: $0.name, start: $0.start, end: $0.end, kind: .event, colorHex: nil) }
            .sorted { $0.start < $1.start }
    }

    private func pieces(for key: String, day: Int) -> [(title: String, key: String, color: String?)] {
        guard !key.isEmpty else { return [("Free", "", nil)] }
        let c = data.classes.first { $0.key == key }
        let name = c?.name ?? "Period \(key)"
        let minis = c?.minis.filter { $0.day == day } ?? []
        if minis.isEmpty { return [(name, key, c?.colorHex)] }
        let first = minis.first { $0.half == 0 }?.name ?? name
        let second = minis.first { $0.half == 1 }?.name ?? name
        return [(first.isEmpty ? name : first, key + "x", c?.colorHex), (second.isEmpty ? name : second, key + "y", c?.colorHex)]
    }

    /// Two mini classes in the block that has lunch, timed the same way as Owen Wang's original app:
    /// each mini gets half of (block length - lunch length). One change: when lunch falls near the middle
    /// of the block, the minis switch at lunch (first mini, lunch, second mini) instead of leaving a
    /// tiny piece of the second mini before lunch, which showed people in a class they weren't in yet.
    private func splitAroundLunch(_ ps: [(title: String, key: String, color: String?)], in p: Period, lunch l: (Int, Int)) -> [Item] {
        func item(_ i: Int, _ s: Int, _ e: Int) -> Item? {
            e > s ? Item(title: ps[i].title, detail: p.name, start: s, end: e, kind: .classTime, colorHex: ps[i].color, classKey: ps[i].key) : nil
        }
        let half = (p.end - p.start - (l.1 - l.0)) / 2
        let before = l.0 - p.start                      // class minutes before lunch starts
        var out: [Item?]
        if before <= 0 {                                // lunch first
            out = [item(0, l.1, l.1 + half), item(1, l.1 + half, p.end)]
        } else if before >= 2 * half {                  // lunch at the end
            out = [item(0, p.start, p.start + half), item(1, p.start + half, min(l.0, p.end))]
        } else if abs(before - half) <= 10 {            // lunch near the middle: switch minis at lunch
            out = [item(0, p.start, l.0), item(1, l.1, p.end)]
        } else if before < half {                       // first mini goes on after lunch for a bit
            let secondStart = max(p.end - half, l.1)    // Owen's start time for the second mini
            out = [item(0, p.start, l.0), item(0, l.1, secondStart), item(1, secondStart, p.end)]
        } else {                                        // second mini starts before lunch and goes on after it
            out = [item(0, p.start, p.start + half), item(1, p.start + half, l.0), item(1, l.1, p.end)]
        }
        return out.compactMap { $0 }
    }

    /// Lays class pieces across a period, leaving a gap for lunch if there is one.
    private func layout(_ pieces: [(title: String, key: String, color: String?)], in p: Period, skipping lunch: (Int, Int)?) -> [Item] {
        var intervals = [(p.start, p.end)]
        if let l = lunch {
            let ls = max(p.start, l.0), le = min(p.end, l.1)
            if ls < le { intervals = [(p.start, ls), (le, p.end)].filter { $0.1 > $0.0 } }
        }
        let total = intervals.reduce(0) { $0 + ($1.1 - $1.0) }
        guard total > 0, !pieces.isEmpty else { return [] }
        let per = total / pieces.count
        // Two mini classes with lunch near the middle of the block: switch minis at lunch
        // (no tiny 5-minute piece before lunch). Otherwise each mini gets half the class time.
        if pieces.count == 2, intervals.count == 2, abs((intervals[0].1 - intervals[0].0) - per) <= 10 {
            return pieces.indices.map { i in
                Item(title: pieces[i].title, detail: p.name, start: intervals[i].0, end: intervals[i].1,
                     kind: .classTime, colorHex: pieces[i].color, classKey: pieces[i].key)
            }
        }
        var items: [Item] = []
        var iv = 0
        var pos = intervals[0].0
        for (i, piece) in pieces.enumerated() {
            var need = i == pieces.count - 1 ? total - per * (pieces.count - 1) : per
            while need > 0, iv < intervals.count {
                let take = min(intervals[iv].1 - pos, need)
                if take > 0 {
                    items.append(Item(title: piece.title, detail: p.name, start: pos, end: pos + take,
                                      kind: .classTime, colorHex: piece.color, classKey: piece.key))
                }
                pos += take
                need -= take
                if pos >= intervals[iv].1 {
                    iv += 1
                    if iv < intervals.count { pos = intervals[iv].0 }
                }
            }
        }
        return items
    }

    // MARK: Right now

    func now(_ date: Date = Date()) -> NowState {
        let m = T.minutesNow(date)
        let items = items(for: date)
        let evts = events(for: date)
        if let first = items.first, let last = items.max(by: { $0.end < $1.end }) {
            if m < first.start { return .before(next: first, minutes: first.start - m) }
            if let cur = items.last(where: { $0.start <= m && m < $0.end }) {
                let next = items.first { $0.start >= cur.end && $0 != cur }
                let progress = Double(m - cur.start) / Double(max(1, cur.end - cur.start))
                return .during(cur, left: cur.end - m, progress: progress, next: next)
            }
            if m < last.end, let next = items.first(where: { $0.start > m }) {
                return .passing(next: next, minutes: next.start - m)
            }
        }
        if let e = evts.first(where: { $0.start <= m && m < $0.end }) { return .event(e, left: e.end - m) }
        if let e = evts.first(where: { $0.start > m }) {
            return items.isEmpty ? .noSchool : .freeTime(until: e, minutes: e.start - m)
        }
        return items.isEmpty ? .noSchool : .done
    }

    /// The short text next to the clock icon at the top of the screen.
    /// With `seconds`, the time left counts down like a timer (23:41).
    func menuTitle(_ date: Date = Date(), seconds: Bool = false) -> String? {
        func short(_ s: String) -> String { s.count > 14 ? String(s.prefix(13)) + "…" : s }
        let sec = T.secondsNow(date)
        func left(_ endMinute: Int, _ minutes: Int) -> String { seconds ? T.timer(endMinute * 60 - sec) : T.duration(minutes) }
        switch now(date) {
        case .noSchool, .done: return nil
        case let .before(next, minutes): return minutes > 120 ? nil : "\(short(next.title)) in \(left(next.start, minutes))"
        case let .during(item, l, _, _): return "\(short(item.title)) · \(left(item.end, l))"
        case let .passing(next, minutes): return "→ \(short(next.title)) \(left(next.start, minutes))"
        case let .freeTime(until, minutes): return "\(short(until.title)) in \(left(until.start, minutes))"
        case let .event(e, l): return "\(short(e.title)) · \(left(e.end, l))"
        }
    }

    /// The class happening now, or the one that ended most recently today (for "what homework did you get?").
    func recentClass(_ date: Date) -> Item? {
        let m = T.minutesNow(date)
        return items(for: date).filter { $0.kind == .classTime && !($0.classKey ?? "").isEmpty && $0.start <= m }.last
    }

    /// Classes that end at minute `m` today and don't pick up again later (a class split by lunch only counts once).
    func classesEnding(_ date: Date) -> [Item] {
        let all = items(for: date).filter { $0.kind == .classTime && !($0.classKey ?? "").isEmpty }
        return all.enumerated().filter { i, item in
            !all[(i + 1)...].contains { $0.classKey == item.classKey }
        }.map(\.element)
    }

    /// The next school day this class meets.
    func nextClassDay(for key: String, after date: Date) -> Date? {
        let base = key.hasSuffix("x") || key.hasSuffix("y") ? String(key.dropLast()) : key
        var d = T.addDays(T.cal.startOfDay(for: date), 1)
        for _ in 0..<40 {
            if items(for: d).contains(where: { $0.classKey == base || $0.classKey == base + "x" || $0.classKey == base + "y" }) { return d }
            d = T.addDays(d, 1)
        }
        return nextSchoolDay(after: date)
    }

    /// When school (and any after-school events) end on a day, in minutes. nil when there's no school and no events.
    func busyUntil(_ date: Date) -> Int? {
        let ends = (items(for: date) + events(for: date)).map(\.end)
        return ends.max()
    }

    /// "Day 2 · Advisory" (the small text on the overlay bar).
    func dayInfo(_ date: Date) -> String {
        var s = dayLabel(date)
        if let l = dayType(date).label { s += " · " + l.replacingOccurrences(of: " day", with: "") }
        return s
    }

    func dayLabel(_ date: Date) -> String {
        guard let rot = rotationDay(date) else { return "No school" }
        return school.rotationLength > 1 ? "Day \(rot)" : "School day"
    }
}
