// School Schedule for Mac. Copyright (c) 2026 Owen Wang (original School Schedule Manager) and Brady Krupa
// (macOS version, ported to macOS using Claude AI). Licensed under the GNU AGPL v3; see LICENSE.
import AppKit
import SwiftUI

/// What the overlay bar is doing right now.
final class OverlayState: ObservableObject {
    @Published var expanded = false
    @Published var hover: Double = 0      // 0…1 while you hover (it opens at 1)
    @Published var tab = 0
}

/// The overlay bar from the Windows School Schedule Manager, rebuilt in the modern style:
/// a small bar in a corner of the screen that shows the class, a progress bar, the time left, and
/// what's next. Hover over it for a second and it opens with today's timeline, your homework plan,
/// your homework list, and the "Got homework?" box. Clicks pass through it until it opens.
final class OverlayController: NSObject {
    private let store: Store
    private let state = OverlayState()
    private var panel: PinPanel?
    private var poll: Timer?
    private var hoverStart: Date?
    private var leaveStart: Date?
    private var hiddenUntil: Date?
    private(set) var isOn = false

    init(store: Store) { self.store = store }

    func apply(_ on: Bool) {
        isOn = on
        if on {
            if panel == nil { build() }
            refreshLook()
            if hiddenUntil == nil, panel?.isVisible != true { panel?.orderFrontRegardless() }
            startPolling()
        } else {
            panel?.orderOut(nil)
            poll?.invalidate(); poll = nil
            collapse()
        }
    }

    private func build() {
        let p = PinPanel(contentRect: NSRect(x: 0, y: 0, width: 360, height: 90),
                         styleMask: [.borderless, .nonactivatingPanel], backing: .buffered, defer: false)
        p.level = .floating
        p.isOpaque = false
        p.backgroundColor = .clear
        p.hasShadow = true
        p.hidesOnDeactivate = false
        p.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary]
        let host = NSHostingController(rootView: OverlayView(state: state, actions: OverlayActions(
            hide: { [weak self] in self?.hideForTen() },
            settings: { [weak self] in self?.store.openSettings() },
            off: { [weak self] in self?.store.data.keepOnScreen = false }
        )).environmentObject(store))
        host.sizingOptions = [.preferredContentSize]
        p.contentViewController = host
        NotificationCenter.default.addObserver(forName: NSWindow.didResizeNotification, object: p, queue: .main) { [weak self] _ in
            self?.place()
        }
        panel = p
    }

    /// Opacity, which corner, and whether clicks pass through.
    func refreshLook() {
        guard let p = panel else { return }
        p.alphaValue = state.expanded ? max(store.data.opacity, 0.97) : store.data.opacity
        p.ignoresMouseEvents = !state.expanded && store.data.passThrough
        p.appearance = NSAppearance(named: store.theme.dark ? .darkAqua : .aqua)
        place()
    }

    /// Keeps the bar in its corner, growing away from the edge when it opens.
    private func place() {
        guard let p = panel, let screen = NSScreen.main else { return }
        let vf = screen.visibleFrame, m: CGFloat = 8
        let c = store.data.corner
        let x = c.hasSuffix("Left") ? vf.minX + m : vf.maxX - p.frame.width - m
        let y = c.hasPrefix("bottom") ? vf.minY + m : vf.maxY - p.frame.height - m
        if p.frame.origin != NSPoint(x: x, y: y) { p.setFrameOrigin(NSPoint(x: x, y: y)) }
    }

    // MARK: Hover to open (the mouse is checked ~30 times a second, since clicks pass through the bar)

    private func startPolling() {
        guard poll == nil else { return }
        let t = Timer(timeInterval: 1.0 / 30, repeats: true) { [weak self] _ in self?.checkMouse() }
        RunLoop.main.add(t, forMode: .common)
        poll = t
    }

    private func checkMouse() {
        if let until = hiddenUntil {
            if Date() < until { return }
            hiddenUntil = nil
            if isOn { panel?.orderFrontRegardless() }
        }
        guard let p = panel, p.isVisible else { return }
        let inside = p.frame.insetBy(dx: -2, dy: -2).contains(NSEvent.mouseLocation)
        let now = Date()
        if inside {
            leaveStart = nil
            if !state.expanded {
                if hoverStart == nil { hoverStart = now.addingTimeInterval(-state.hover) }
                state.hover = min(1, now.timeIntervalSince(hoverStart!))
                if state.hover >= 1 { expand() }
            }
        } else {
            hoverStart = nil
            if state.expanded {
                if leaveStart == nil { leaveStart = now }
                // Stay open while someone is typing homework into it.
                if now.timeIntervalSince(leaveStart!) > 0.8, !store.quickTyping { collapse() }
            } else if state.hover > 0 {
                state.hover = max(0, state.hover - 1.0 / 15)
            }
        }
    }

    private func expand() {
        store.now = Date()
        state.expanded = true
        state.hover = 0
        refreshLook()
    }

    private func collapse() {
        guard state.expanded else { return }
        state.expanded = false
        hoverStart = nil
        leaveStart = nil
        if panel?.isKeyWindow == true { panel?.resignKey() }
        refreshLook()
    }

    /// "Hide (10s)": gets out of the way for ten seconds.
    private func hideForTen() {
        collapse()
        hiddenUntil = Date().addingTimeInterval(10)
        panel?.orderOut(nil)
    }
}

struct OverlayActions {
    var hide: () -> Void
    var settings: () -> Void
    var off: () -> Void
}

struct OverlayView: View {
    @EnvironmentObject var store: Store
    @ObservedObject var state: OverlayState
    let actions: OverlayActions

    var body: some View {
        let th = store.theme
        let a = store.data.appearance
        let s = CGFloat(store.data.scale)
        let top = store.data.corner.hasPrefix("top")
        let border = OverlayInfo(store: store, date: store.now).accent(th, a)
        VStack(spacing: 0) {
            if top { liveBar(th, s) }
            if state.expanded { expanded(th).transition(.opacity) }
            if !top { liveBar(th, s) }
        }
        .frame(width: max(340, 360 * s))
        .background(th.bg)
        .foregroundStyle(th.text)
        .clipShape(RoundedRectangle(cornerRadius: a.radius + 2))
        .overlay(RoundedRectangle(cornerRadius: a.radius + 2).stroke(border, lineWidth: 1.5))
        .fontDesign(a.monoFont == true ? .monospaced : .default)
        .environment(\.colorScheme, th.dark ? .dark : .light)
        .tint(th.accent)
    }

    /// The bar redraws every second (for the timer); the opened part doesn't need to.
    private func liveBar(_ th: Theme, _ s: CGFloat) -> some View {
        TimelineView(.periodic(from: .now, by: 1)) { ctx in
            bar(OverlayInfo(store: store, date: store.frozenNow ? store.now : ctx.date), th, s)
        }
    }

    // MARK: The bar (always showing)

    private func bar(_ info: OverlayInfo, _ th: Theme, _ s: CGFloat) -> some View {
        let accent = info.accent(th, store.data.appearance)
        return VStack(spacing: 0) {
            HStack(spacing: 12 * s) {
                Circle().fill(accent).frame(width: 46 * s, height: 46 * s)
                    .overlay(Image(systemName: info.icon).font(.system(size: 19 * s, weight: .semibold)).foregroundStyle(.white))
                VStack(alignment: .leading, spacing: 5 * s) {
                    HStack(spacing: 6) {
                        Text(info.title).font(.system(size: 13.5 * s, weight: .semibold)).lineLimit(1)
                        Spacer(minLength: 4)
                        Text(info.dayInfo).font(.system(size: 11 * s)).foregroundStyle(th.muted).lineLimit(1).fixedSize()
                    }
                    ZStack(alignment: .leading) {
                        GeometryReader { g in
                            ZStack(alignment: .leading) {
                                Capsule().fill(th.card)
                                Capsule().fill(accent).frame(width: max(0, g.size.width * info.progress))
                            }
                        }
                        HStack {
                            Text(info.percent)
                            Spacer()
                            Text(info.left)
                        }
                        .font(.system(size: 11.5 * s, weight: .semibold).monospacedDigit())
                        .foregroundStyle(.white)
                        .shadow(color: .black.opacity(0.35), radius: 1)
                        .padding(.horizontal, 8 * s)
                    }
                    .frame(height: 20 * s)
                    HStack(spacing: 0) {
                        Text(info.nextLabel).foregroundStyle(th.muted)
                        Text(info.next).foregroundStyle(info.nextColor ?? th.text).fontWeight(.semibold)
                    }
                    .font(.system(size: 11 * s)).lineLimit(1)
                }
            }
            .padding(.horizontal, 12 * s).padding(.vertical, 11 * s)
            // Fills up while you hover; the bar opens when it's full.
            GeometryReader { g in
                Rectangle().fill(accent).frame(width: g.size.width * state.hover)
            }
            .frame(height: 3 * s)
        }
        .contentShape(Rectangle())
    }

    // MARK: Opened

    private func expanded(_ th: Theme) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 8) {
                OverlayButton(icon: "eye.slash", title: "Hide (10s)", theme: th, action: actions.hide)
                Spacer()
                OverlayButton(icon: "pin.slash", title: nil, theme: th, action: actions.off).help("Take it off the screen")
                OverlayButton(icon: "gearshape", title: nil, theme: th, action: actions.settings).help("Settings")
            }
            TabSwitch(selection: $state.tab, labels: ["Today", "Plan", "Homework"], theme: th)
            Group {
                switch state.tab {
                case 0:
                    ScrollView {
                        let items = (store.engine.items(for: store.now) + store.engine.events(for: store.now)).sorted { $0.start < $1.start }
                        if items.isEmpty {
                            Text("No classes today.").font(.system(size: 12.5)).foregroundStyle(th.muted).frame(maxWidth: .infinity).padding(.vertical, 30)
                        } else {
                            TimelineList(items: items, minute: T.minutesNow(store.now), theme: th).padding(.horizontal, 4)
                        }
                    }
                case 1: PlanView()
                default: HomeworkView()
                }
            }
            .frame(height: 250)
            QuickAddBar(compact: true) { state.tab = 1 }
        }
        .padding(12)
        .background(th.bg)
    }
}

struct OverlayButton: View {
    let icon: String
    let title: String?
    let theme: Theme
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            HStack(spacing: 5) {
                Image(systemName: icon).font(.system(size: 11, weight: .semibold))
                if let title { Text(title).font(.system(size: 11.5, weight: .semibold)) }
            }
            .padding(.horizontal, 9).frame(height: 26)
            .background(theme.card).clipShape(Capsule())
            .contentShape(Capsule())
        }
        .buttonStyle(.plain).foregroundStyle(theme.text)
    }
}

/// Everything the bar shows, worked out for one moment.
struct OverlayInfo {
    var title = ""
    var icon = "clock"
    var color: Color?
    var dayInfo = ""
    var progress = 0.0
    var percent = ""
    var left = ""
    var nextLabel = "Next: "
    var next = ""
    var nextColor: Color?

    init(store: Store, date: Date) {
        let e = store.engine
        let th = store.theme
        let sec = T.secondsNow(date)
        dayInfo = e.dayInfo(date)
        func timer(_ minute: Int) -> String { T.timer(minute * 60 - sec) }
        func use(_ item: Item) { title = item.title; icon = store.icon(for: item); color = store.color(for: item, theme: th) }
        func upNext(_ item: Item?) {
            guard let item else { next = "Done for today"; return }
            next = item.title; nextColor = store.color(for: item, theme: th)
        }
        let items = e.items(for: date)
        switch e.now(date) {
        case let .during(item, _, _, nxt):
            use(item)
            let total = Double(max(1, (item.end - item.start) * 60))
            progress = min(max(Double(sec - item.start * 60) / total, 0), 1)
            percent = String(format: "%.2f%%", progress * 100)
            left = timer(item.end)
            upNext(nxt)
        case let .passing(nxt, _):
            title = "Passing time"; icon = "figure.walk"
            percent = "Starts \(T.clock(nxt.start))"; left = timer(nxt.start)
            upNext(nxt)
        case let .before(first, minutes):
            title = "Before school"; icon = "alarm"
            percent = "School starts \(T.clock(first.start))"; left = minutes <= 180 ? timer(first.start) : ""
            upNext(first)
        case let .freeTime(until, _):
            title = "Free time"; icon = "cup.and.saucer"
            percent = "Until \(T.clock(until.start))"; left = timer(until.start)
            upNext(until)
        case let .event(ev, _):
            use(ev)
            left = timer(ev.end); percent = "Ends \(T.clock(ev.end))"
            nextLabel = ""; next = ""
        case .done:
            title = "School’s out"; icon = "figure.walk.departure"
            percent = "Done for today"; nextLabel = ""
            next = Self.nextSchool(e, date)
        case .noSchool:
            title = "No school today"; icon = "party.popper"
            percent = "Enjoy your day"; nextLabel = ""
            next = items.isEmpty ? Self.nextSchool(e, date) : ""
        }
        icon = Icons.safe(icon)
    }

    private static func nextSchool(_ e: Engine, _ date: Date) -> String {
        guard let d = e.nextSchoolDay(after: date) else { return "" }
        let f = DateFormatter(); f.dateFormat = "EEEE"
        return "Next school day: \(f.string(from: d))"
    }

    func accent(_ th: Theme, _ a: Appearance) -> Color { a.usesClassColor ? (color ?? th.accent) : th.accent }
}
