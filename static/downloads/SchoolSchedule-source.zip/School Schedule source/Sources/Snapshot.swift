// School Schedule for Mac. Copyright (c) 2026 Owen Wang (original School Schedule Manager) and Brady Krupa
// (macOS version, ported to macOS using Claude AI). Licensed under the GNU AGPL v3; see LICENSE.
import AppKit
import SwiftUI

/// Test mode: renders the app's screens to PNG files (SS_SNAPSHOT_DIR) with sample data.
enum Snapshot {
    static func run(_ store: Store, dir: String) {
        let out = URL(fileURLWithPath: dir)
        try? FileManager.default.createDirectory(at: out, withIntermediateDirectories: true)
        let names = ["Humanities", "Humanities", "Spanish III", "Robotics", "Study Hall", "Biology III", "Public Speaking", "Math (3-in-2)"]
        for i in 0..<8 { store.data.classes[i].name = names[i] }
        store.data.classes[4].minis = [MiniClass(day: 1, half: 0, name: "Study Hall MINI"), MiniClass(day: 1, half: 1, name: "Biology III MINI")]
        store.data.school.lunchWaves?.wavePerDay = [3, 1, 1, 5]
        store.data.setupDone = true
        let fmt = DateFormatter()
        fmt.dateFormat = "yyyy-MM-dd HH:mm"
        let now = fmt.date(from: ProcessInfo.processInfo.environment["SS_FAKE_NOW"] ?? "") ?? Date()
        store.now = now
        store.frozenNow = true
        let today = T.dayString(now)
        store.data.homework = [
            Homework(classKey: "6", title: "Cell worksheet", due: T.dayString(T.addDays(now, 1)), when: .atNight),
            Homework(classKey: "3", title: "Vocab quiz study", due: today, when: .inClass),
            Homework(classKey: "8", title: "Problem set 4.2", due: T.dayString(T.addDays(now, -1)), when: .atNight),
            Homework(classKey: "7", title: "Speech outline", due: T.dayString(T.addDays(now, 4)), when: .atNight),
            Homework(classKey: "1", title: "Read chapter 5", due: today, when: .atNight, done: true, doneAt: today),
        ]
        store.data.events = [AfterSchoolEvent(name: "Soccer practice", start: T.m(15, 30), end: T.m(17, 0), weekdays: [2, 3, 4, 5, 6])]
        let e = store.engine
        for t in ["07:50", "10:00", "11:20", "12:20", "15:05", "15:45", "20:00"] {
            let d = fmt.date(from: "\(today) \(t)")!
            print("menu @\(t):", e.menuTitle(d) ?? "(icon only)", "|", e.menuTitle(d.addingTimeInterval(17), seconds: true) ?? "", "| recent:", e.recentClass(d)?.title ?? "-",
                  "| ending:", e.classesEnding(d).map { "\($0.title)@\(T.short($0.end))" }.joined(separator: ","))
        }
        // Year code: must match the Windows encoder and the built-in WHS year.
        let owenCode = "Year:2026;Adv:3;Limit:C286;NoS:CFD9EBECF0FDGFGGGHI5I6I9IAIBIC010I262728292A4855565758597F;Short:CHFCG9GAGDGEHAI40D0J103C50848586"
        if let info = YearCode.decode(owenCode) {
            var s = Templates.whs(); YearCode.apply(info, to: &s)
            let w = Templates.whs()
            print("yearcode decode:", info.start ?? "-", info.end ?? "-", "off:", info.daysOff.count, "short:", info.shortDays.count, "adv weekday:", info.advisoryWeekday ?? -1,
                  "| matches WHS:", s.daysOff.map(\.start) == w.daysOff.map(\.start) && s.shortDays == w.shortDays && s.yearStart == w.yearStart)
            print("yearcode round trip:", YearCode.encode(s) == owenCode ? "same" : "DIFFERENT: \(YearCode.encode(s) ?? "")")
        } else { print("yearcode decode FAILED") }
        let missing = Icons.choices.map(\.0).filter { !Icons.exists($0) }
        print("icons missing on this Mac:", missing)
        T.use24h = true; print("24h:", T.clock(T.m(14, 5))); T.use24h = false
        if let notes = ProcessInfo.processInfo.environment["SS_PARSE_TEST"] {
            let sem = DispatchSemaphore(value: 0)
            Task { @MainActor in
                print("engine:", HomeworkAI.engineName)
                for note in notes.components(separatedBy: "|") {
                    var ctx = store.quickContext(defaultKey: "6")
                    ctx.now = now
                    let items = await HomeworkAI.parse(note, ctx)
                    print("NOTE:", note)
                    for i in items { print("   →", i.title, "|", store.className(i.classKey), "|", i.kind.rawValue, "|", T.dayString(i.due), T.nice(T.dayString(i.due), relativeTo: now), "|", i.minutes, "min") }
                }
                sem.signal()
            }
            while sem.wait(timeout: .now()) == .timedOut { RunLoop.current.run(until: Date().addingTimeInterval(0.05)) }
        }

        func shot<V: View>(_ name: String, _ view: V, size: NSSize? = nil) {
            let host = NSHostingView(rootView: view.background(Color(nsColor: .windowBackgroundColor)).environmentObject(store))
            let fit = size ?? host.fittingSize
            let win = NSWindow(contentRect: NSRect(x: -6000, y: -6000, width: fit.width, height: fit.height),
                               styleMask: [.borderless], backing: .buffered, defer: false)
            win.contentView = host
            win.orderFront(nil)
            host.layoutSubtreeIfNeeded()
            RunLoop.current.run(until: Date().addingTimeInterval(0.4))
            let finalSize = size ?? host.fittingSize
            win.setContentSize(finalSize)
            host.layoutSubtreeIfNeeded()
            RunLoop.current.run(until: Date().addingTimeInterval(0.2))
            guard let rep = host.bitmapImageRepForCachingDisplay(in: host.bounds) else { return }
            host.cacheDisplay(in: host.bounds, to: rep)
            try? rep.representation(using: .png, properties: [:])?.write(to: out.appendingPathComponent("\(name).png"))
            win.orderOut(nil)
        }

        store.data.homework[0].kind = .assignment
        store.data.homework[3].kind = .project
        store.data.homework.append(Homework(classKey: "8", title: "Unit 3 test", due: T.dayString(T.addDays(now, 3)), when: .inClass, kind: .test, minutes: 60))
        shot("popover-today", PopoverView())
        shot("popover-plan", PopoverView(tab: 1))
        shot("popover-homework", PopoverView(tab: 2))
        shot("pinned-full", PopoverView(pinned: true))
        store.data.compactOnScreen = true
        shot("pinned-compact", PopoverView(pinned: true))
        store.data.compactOnScreen = nil
        // Overlay bar (from the Windows app), closed and opened
        let ov = OverlayState()
        let acts = OverlayActions(hide: {}, settings: {}, off: {})
        shot("overlay-bar", OverlayView(state: ov, actions: acts))
        ov.hover = 0.6
        shot("overlay-bar-hover", OverlayView(state: ov, actions: acts))
        ov.hover = 0; ov.expanded = true
        shot("overlay-open", OverlayView(state: ov, actions: acts))
        ov.tab = 1
        shot("overlay-open-plan", OverlayView(state: ov, actions: acts))
        ov.tab = 0
        store.data.appearance.themeID = "light"
        shot("overlay-open-light", OverlayView(state: ov, actions: acts))
        store.data.appearance.themeID = "modernDark"
        ov.expanded = false
        store.data.appearance.classColorAccent = false
        store.data.appearance.sharpCorners = true
        store.data.appearance.monoFont = true
        shot("overlay-bar-mono-sharp", OverlayView(state: ov, actions: acts))
        store.data.appearance.classColorAccent = nil; store.data.appearance.sharpCorners = nil; store.data.appearance.monoFont = nil
        shot("license", LicenseView(firstRun: true), size: NSSize(width: 620, height: 560))
        store.data.appearance.themeID = "light"
        shot("popover-today-light", PopoverView())
        store.data.appearance.themeID = "pastel"
        shot("popover-today-pastel", PopoverView())
        store.data.appearance.themeID = "modernDark"
        let big = NSSize(width: 760, height: 600)
        shot("settings-school", SchoolTab().padding(16), size: big)
        shot("settings-classes", ClassesTab().padding(16), size: big)
        shot("settings-reminders", RemindersTab().padding(16), size: big)
        shot("settings-events", EventsTab().padding(16), size: big)
        store.data.keepOnScreen = true; store.data.onScreenStyle = "bar"
        shot("settings-look", AppearanceTab().padding(16), size: NSSize(width: 760, height: 1100))
        store.data.keepOnScreen = nil
        shot("settings-general", GeneralTab().padding(16), size: big)
        shot("setup-welcome", SetupView(onDone: {}))
        shot("setup-whs-lunch", SetupView(onDone: {}, path: .whs, step: 2))
        store.data.school = Templates.custom()
        store.data.classes = Templates.customClasses()
        shot("setup-custom-bells", SetupView(onDone: {}, path: .custom, step: 1))
        shot("settings-school-custom", SchoolTab().padding(16), size: big)
    }
}
