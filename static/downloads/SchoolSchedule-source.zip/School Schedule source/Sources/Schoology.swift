// School Schedule for Mac. Copyright (c) 2026 Owen Wang (original School Schedule Manager) and Brady Krupa
// (macOS version, ported to macOS using Claude AI). Licensed under the GNU AGPL v3; see LICENSE.
import AppKit
import Foundation

/// Brings in homework from your Schoology calendar (its private iCal link from Calendar → Export).
/// The link is only used to download your calendar straight from Schoology. Nothing is sent to us.
final class Schoology {
    static let shared = Schoology()
    static let source = "schoology"

    private weak var store: Store?
    private var timer: Timer?
    private(set) var syncing = false

    /// Starts syncing: now, every 30 minutes, and when the Mac wakes up.
    func start(store: Store) {
        self.store = store
        sync()
        let t = Timer(timeInterval: 30 * 60, repeats: true) { [weak self] _ in self?.sync() }
        t.tolerance = 60
        RunLoop.main.add(t, forMode: .common)
        timer = t
        NSWorkspace.shared.notificationCenter.addObserver(forName: NSWorkspace.didWakeNotification, object: nil, queue: .main) { [weak self] _ in
            DispatchQueue.main.asyncAfter(deadline: .now() + 10) { self?.sync() }
        }
    }

    /// "webcal://…" → "https://…". Returns nil if it isn't a web link.
    static func feedURL(_ raw: String) -> URL? {
        var s = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !s.isEmpty else { return nil }
        if s.lowercased().hasPrefix("webcal://") { s = "https://" + s.dropFirst("webcal://".count) }
        if !s.lowercased().hasPrefix("http") { s = "https://" + s }
        guard let url = URL(string: s), let host = url.host, host.contains(".") else { return nil }
        return url
    }

    /// Downloads the calendar and updates the homework list. `done` gets an error message, or nil if it worked.
    func sync(_ done: ((String?) -> Void)? = nil) {
        guard let store, !syncing else { done?(nil); return }
        guard let link = store.data.schoologyURL, !link.isEmpty else { done?(nil); return }
        guard let url = Self.feedURL(link) else {
            finish("That doesn’t look like a link. Copy the whole iCal link from Schoology and paste it again.", done)
            return
        }
        syncing = true
        var req = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 30)
        req.setValue("text/calendar, */*", forHTTPHeaderField: "Accept")
        URLSession.shared.dataTask(with: req) { [weak self] body, response, error in
            let code = (response as? HTTPURLResponse)?.statusCode ?? 0
            let text = body.flatMap { String(data: $0, encoding: .utf8) ?? String(data: $0, encoding: .isoLatin1) } ?? ""
            DispatchQueue.main.async {
                guard let self else { return }
                self.syncing = false
                if error != nil {
                    self.finish("Couldn’t reach Schoology. Check your internet and try again.", done)
                } else if code >= 400 || !text.contains("BEGIN:VCALENDAR") {
                    self.finish("That link didn’t give a calendar. In Schoology, open Calendar → Export, copy the link again, and paste it here.", done)
                } else {
                    self.apply(ICal.events(text))
                    self.finish(nil, done)
                }
            }
        }.resume()
    }

    private func finish(_ error: String?, _ done: ((String?) -> Void)?) {
        if let store {
            if error == nil { store.data.schoologyLastSync = ISO8601DateFormatter().string(from: Date()) }
            if store.data.schoologyError != error { store.data.schoologyError = error }
        }
        done?(error)
    }

    /// Adds new assignments, updates ones that changed, and removes ones Schoology no longer has.
    /// Your check marks, how-long estimates, and class picks are kept.
    private func apply(_ events: [ICal.Event]) {
        guard let store else { return }
        var data = store.data
        let today = T.dayString(Date())
        let hidden = Set(data.schoologyHidden ?? [])
        let ctx = store.quickContext(defaultKey: nil)
        var seen = Set<String>()

        for ev in events {
            let title = ev.summary.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !title.isEmpty, !seen.contains(ev.uid) else { continue }
            seen.insert(ev.uid)
            let due = T.dayString(ev.due)
            if let i = data.homework.firstIndex(where: { $0.source == Self.source && $0.externalID == ev.uid }) {
                // Already have it: keep it up to date.
                if data.homework[i].title != title { data.homework[i].title = title }
                if data.homework[i].due != due { data.homework[i].due = due }
                if data.homework[i].link != ev.url { data.homework[i].link = ev.url }
                continue
            }
            // Only bring in things due today or later (the calendar keeps old assignments forever).
            guard due >= today, !hidden.contains(ev.uid) else { continue }
            let all = [title, ev.location, ev.categories, ev.description].joined(separator: " ").lowercased()
            let key = Rules.matchClass(in: title.lowercased(), ctx)?.key
                ?? Rules.matchClass(in: all, ctx, onlyIfOne: true)?.key
                ?? Self.source
            let kind = Rules.kind(title.lowercased())
            data.homework.append(Homework(classKey: key, title: title, due: due,
                                          when: kind == .test ? .inClass : .atNight, kind: kind,
                                          source: Self.source, externalID: ev.uid, link: ev.url))
        }
        // Gone from Schoology (deleted or moved off the calendar): remove it if you haven't finished it yet.
        data.homework.removeAll { $0.source == Self.source && !$0.done && $0.due >= today && !seen.contains($0.externalID ?? "") }
        // Forget hidden items that are long gone.
        if let h = data.schoologyHidden { data.schoologyHidden = h.filter { seen.contains($0) } }
        if data != store.data { store.data = data }
    }

    /// Unlinks Schoology and removes the homework it added that isn't done yet.
    func unlink() {
        guard let store else { return }
        store.data.schoologyURL = nil
        store.data.schoologyLastSync = nil
        store.data.schoologyError = nil
        store.data.schoologyHidden = nil
        store.data.homework.removeAll { $0.source == Self.source && !$0.done }
    }
}

// MARK: - A small iCal (.ics) reader

enum ICal {
    struct Event {
        var uid: String
        var summary: String
        var due: Date
        var description = ""
        var location = ""
        var categories = ""
        var url: String? = nil
    }

    static func events(_ text: String) -> [Event] {
        // Long lines are folded: a line starting with a space or tab continues the one before it.
        var lines: [String] = []
        for raw in text.replacingOccurrences(of: "\r\n", with: "\n").replacingOccurrences(of: "\r", with: "\n").split(separator: "\n", omittingEmptySubsequences: false) {
            if let first = raw.first, first == " " || first == "\t", !lines.isEmpty { lines[lines.count - 1] += raw.dropFirst() }
            else { lines.append(String(raw)) }
        }
        var out: [Event] = []
        var cur: [String: (params: String, value: String)]? = nil
        for line in lines {
            let line = line.trimmingCharacters(in: .whitespaces)
            if line == "BEGIN:VEVENT" { cur = [:]; continue }
            if line == "END:VEVENT" {
                if let c = cur, let ev = event(c) { out.append(ev) }
                cur = nil
                continue
            }
            guard cur != nil, let colon = line.firstIndex(of: ":") else { continue }
            let head = line[..<colon]
            let value = String(line[line.index(after: colon)...])
            let parts = head.split(separator: ";", maxSplits: 1)
            let name = parts.first.map { String($0).uppercased() } ?? ""
            let params = parts.count > 1 ? String(parts[1]) : ""
            if cur?[name] == nil { cur?[name] = (params, value) }
        }
        return out
    }

    private static func event(_ f: [String: (params: String, value: String)]) -> Event? {
        guard let start = f["DTSTART"] ?? f["DUE"], let date = parseDate(start.value, params: start.params) else { return nil }
        let summary = unescape(f["SUMMARY"]?.value ?? "")
        let uid = f["UID"]?.value ?? "\(summary)|\(T.dayString(date))"
        var url = f["URL"]?.value
        let description = unescape(f["DESCRIPTION"]?.value ?? "")
        if url == nil, let r = description.range(of: #"https?://\S+"#, options: .regularExpression) { url = String(description[r]) }
        return Event(uid: uid, summary: summary, due: date, description: description,
                     location: unescape(f["LOCATION"]?.value ?? ""), categories: unescape(f["CATEGORIES"]?.value ?? ""), url: url)
    }

    /// "20261120" (all day), "20261120T235900Z" (UTC), or "20261120T235900" (with TZID=… or local time).
    static func parseDate(_ value: String, params: String) -> Date? {
        let v = value.trimmingCharacters(in: .whitespaces)
        let digits = v.filter(\.isNumber)
        guard digits.count >= 8, let y = Int(digits.prefix(4)), let mo = Int(digits.dropFirst(4).prefix(2)), let d = Int(digits.dropFirst(6).prefix(2)) else { return nil }
        guard v.contains("T"), digits.count >= 12 else {
            return T.cal.date(from: DateComponents(year: y, month: mo, day: d))
        }
        let h = Int(digits.dropFirst(8).prefix(2)) ?? 0, mi = Int(digits.dropFirst(10).prefix(2)) ?? 0
        let s = Int(digits.dropFirst(12).prefix(2)) ?? 0
        var cal = Calendar(identifier: .gregorian)
        if v.hasSuffix("Z") { cal.timeZone = TimeZone(identifier: "UTC")! }
        else if let r = params.range(of: #"TZID=("?)[^;:"]+"#, options: .regularExpression) {
            let id = params[r].replacingOccurrences(of: "TZID=", with: "").replacingOccurrences(of: "\"", with: "")
            cal.timeZone = TimeZone(identifier: id) ?? .current
        } else { cal.timeZone = .current }
        return cal.date(from: DateComponents(year: y, month: mo, day: d, hour: h, minute: mi, second: s))
    }

    static func unescape(_ s: String) -> String {
        s.replacingOccurrences(of: "\\n", with: "\n").replacingOccurrences(of: "\\N", with: "\n")
            .replacingOccurrences(of: "\\,", with: ",").replacingOccurrences(of: "\\;", with: ";")
            .replacingOccurrences(of: "\\\\", with: "\\")
    }
}
