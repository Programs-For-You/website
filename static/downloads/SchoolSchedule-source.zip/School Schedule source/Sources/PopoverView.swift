// School Schedule for Mac. Copyright (c) 2026 Owen Wang (original School Schedule Manager) and Brady Krupa
// (macOS version, ported to macOS using Claude AI). Licensed under the GNU AGPL v3; see LICENSE.
import SwiftUI

/// The panel that drops down from the button at the top of the screen.
/// The same view is used for the floating window that stays on screen (`pinned`).
struct PopoverView: View {
    @EnvironmentObject var store: Store
    @State private var tab: Int
    let pinned: Bool
    init(tab: Int = 0, pinned: Bool = false) {
        _tab = State(initialValue: tab)
        self.pinned = pinned
    }

    var body: some View {
        let th = store.theme
        let compact = pinned && (store.data.compactOnScreen ?? false)
        VStack(alignment: .leading, spacing: compact ? 10 : 12) {
            header(th, compact: compact)
            if compact {
                NowCard(theme: th, compact: true)
                TonightButton(compact: true) { store.toggleCompact(); tab = 1 }
                QuickAddBar(compact: true) {}
            } else {
                TabSwitch(selection: $tab, labels: ["Today", "Plan", "Homework"], theme: th)
                switch tab {
                case 0: TodayView(openTab: { tab = $0 })
                case 1: PlanView()
                default: HomeworkView()
                }
                QuickAddBar { tab = 1 }
            }
        }
        .padding(compact ? 12 : 14)
        .frame(width: compact ? 280 : 320)
        .background(th.bg)
        .foregroundStyle(th.text)
        .clipShape(RoundedRectangle(cornerRadius: pinned ? store.data.appearance.radius + 2 : 0))
        .overlay { if pinned { RoundedRectangle(cornerRadius: store.data.appearance.radius + 2).stroke(th.line) } }
        .fontDesign(store.data.appearance.monoFont == true ? .monospaced : .default)
        .environment(\.colorScheme, th.dark ? .dark : .light)
        .tint(th.accent)
    }

    private func header(_ th: Theme, compact: Bool) -> some View {
        let e = store.engine
        let date = store.now
        return HStack(alignment: .center, spacing: 10) {
            VStack(alignment: .leading, spacing: 1) {
                Text(e.dayLabel(date)).font(.system(size: compact ? 13 : 15, weight: .bold))
                if !compact { Text(subtitle(e, date)).font(.system(size: 11)).foregroundStyle(th.muted) }
                if !compact && e.isSchoolDay(date) { DayButtons(theme: th) }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .contentShape(Rectangle())
            .background { if pinned { DragArea() } }
            .help(pinned ? "Drag to move" : "")
            if pinned {
                Button { store.toggleCompact() } label: {
                    Image(systemName: compact ? "arrow.up.left.and.arrow.down.right" : "arrow.down.right.and.arrow.up.left").font(.system(size: 12, weight: .semibold))
                }
                .buttonStyle(.plain).foregroundStyle(th.muted).help(compact ? "Show everything" : "Make it smaller")
            }
            Button { store.togglePinned() } label: {
                Image(systemName: pinned ? "pin.slash" : "pin").font(.system(size: 13))
            }
            .buttonStyle(.plain).foregroundStyle(pinned ? th.accent : th.muted)
            .help(pinned ? "Stop keeping it on screen" : "Keep on screen (floats above your other windows)")
            Button { store.openSettings() } label: {
                Image(systemName: "gearshape").font(.system(size: 14))
            }
            .buttonStyle(.plain).foregroundStyle(th.muted).help("Settings")
        }
    }

    private func subtitle(_ e: Engine, _ date: Date) -> String {
        let f = DateFormatter()
        f.dateFormat = "EEEE, MMM d"
        var s = f.string(from: date)
        if let label = e.dayType(date).label { s += " · " + label }
        return s
    }
}

/// "Short day" and "Advisory" on/off buttons for today, in case the school changes the schedule.
struct DayButtons: View {
    @EnvironmentObject var store: Store
    let theme: Theme

    var body: some View {
        let type = store.engine.dayType(store.now)
        HStack(spacing: 6) {
            if store.data.school.schedules["short"] != nil {
                chip("Short day", on: type == .short) { store.toggleToday(.short) }
            }
            if store.data.school.schedules["advisory"] != nil {
                chip("Advisory", on: type == .advisory) { store.toggleToday(.advisory) }
            }
            if store.todayChanged {
                Button("Reset") { store.resetToday() }
                    .buttonStyle(.plain).font(.system(size: 10.5, weight: .medium)).foregroundStyle(theme.muted)
                    .help("Go back to the school calendar for today")
            }
        }
        .padding(.top, 5)
    }

    private func chip(_ title: String, on: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 4) {
                Image(systemName: on ? "checkmark.circle.fill" : "circle").font(.system(size: 10))
                Text(title).font(.system(size: 10.5, weight: .semibold))
            }
            .padding(.horizontal, 8).padding(.vertical, 3)
            .background(Capsule().fill(on ? theme.accent.opacity(0.25) : theme.line.opacity(0.55)))
            .foregroundStyle(on ? theme.text : theme.muted)
            .contentShape(Capsule())
        }
        .buttonStyle(.plain)
        .help(on ? "Turn off \(title.lowercased()) for today" : "Make today a\(title == "Advisory" ? "n advisory day" : " short day")")
    }
}

/// Lets you drag the floating window around by its header.
struct DragArea: NSViewRepresentable {
    final class DragView: NSView {
        override func mouseDown(with event: NSEvent) { window?.performDrag(with: event) }
        override var mouseDownCanMoveWindow: Bool { true }
    }
    func makeNSView(context: Context) -> NSView { DragView() }
    func updateNSView(_ nsView: NSView, context: Context) {}
}

struct TabSwitch: View {
    @Binding var selection: Int
    let labels: [String]
    let theme: Theme

    var body: some View {
        HStack(spacing: 2) {
            ForEach(labels.indices, id: \.self) { i in
                Button { selection = i } label: {
                    Text(labels[i])
                        .font(.system(size: 12, weight: .semibold))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 5)
                        .background(selection == i ? theme.bg : .clear)
                        .clipShape(RoundedRectangle(cornerRadius: 7))
                        .foregroundStyle(selection == i ? theme.text : theme.muted)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
            }
        }
        .padding(3)
        .background(theme.card)
        .clipShape(RoundedRectangle(cornerRadius: 9))
    }
}

// MARK: - Today

struct TodayView: View {
    @EnvironmentObject var store: Store
    var openTab: (Int) -> Void

    var body: some View {
        let th = store.theme
        let e = store.engine
        let date = store.now
        let items = e.items(for: date)
        let events = e.events(for: date)
        let m = T.minutesNow(date)
        VStack(alignment: .leading, spacing: 10) {
            NowCard(theme: th)
            if !items.isEmpty || !events.isEmpty {
                TimelineList(items: (items + events).sorted { $0.start < $1.start }, minute: m, theme: th)
                    .padding(.horizontal, 10).padding(.vertical, 4)
                    .background(th.card)
                    .clipShape(RoundedRectangle(cornerRadius: min(10, store.data.appearance.radius)))
            }
            TonightButton { openTab(1) }
        }
    }
}

/// "Tonight: 3 things · 1h 10m" (opens the plan).
struct TonightButton: View {
    @EnvironmentObject var store: Store
    var compact = false
    var action: () -> Void

    var body: some View {
        let th = store.theme
        let today = T.dayString(store.now)
        let plan = Planner.plan(store.data, engine: store.engine, now: store.now, days: 1)
        let tonight = plan.first { $0.day == today } ?? plan.first
        if let d = tonight {
            let open = d.entries.filter { !$0.checked }
            let label = d.day == today ? (store.engine.isSchoolDay(d.date) ? "Tonight" : "Today") : T.nice(d.day, relativeTo: store.now)
            Button(action: action) {
                HStack(spacing: 8) {
                    Image(systemName: open.isEmpty ? "checkmark.circle.fill" : "list.bullet.clipboard")
                    if open.isEmpty {
                        Text("\(label)’s homework is done!")
                    } else {
                        Text("\(label): \(open.count) thing\(open.count == 1 ? "" : "s") · \(T.duration(d.left))")
                    }
                    Spacer()
                    Image(systemName: "chevron.right").font(.system(size: 10, weight: .semibold))
                }
                .font(.system(size: 12, weight: .medium))
                .padding(compact ? 8 : 10)
                .background(th.card)
                .clipShape(RoundedRectangle(cornerRadius: 10))
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
        }
    }
}

/// The big card at the top, with a live timer counting down what's left.
struct NowCard: View {
    @EnvironmentObject var store: Store
    let theme: Theme
    var compact = false

    var body: some View {
        TimelineView(.periodic(from: .now, by: 1)) { ctx in
            let date = store.frozenNow ? store.now : ctx.date
            card(content(store.engine.now(date), date))
        }
    }

    private func card(_ c: (label: String, big: String, sub: String, timer: String?, timerLabel: String, progress: Double?)) -> some View {
        let pct = c.progress.map { String(format: "%.2f%% done", min(max($0, 0), 1) * 100) }
        return VStack(alignment: .leading, spacing: 2) {
            HStack(alignment: .top, spacing: 8) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(c.label).font(.system(size: 11, weight: .medium)).opacity(0.85).lineLimit(1)
                    Text(c.big).font(.system(size: compact ? 18 : 21, weight: .bold)).lineLimit(1).minimumScaleFactor(0.6)
                }
                Spacer(minLength: 4)
                if let t = c.timer {
                    VStack(alignment: .trailing, spacing: 0) {
                        Text(t).font(.system(size: compact ? 22 : 26, weight: .bold, design: .rounded).monospacedDigit())
                            .lineLimit(1).fixedSize()
                        Text(c.timerLabel).font(.system(size: 10, weight: .semibold)).opacity(0.85)
                    }
                }
            }
            Text(c.sub).font(.system(size: 11.5)).opacity(0.92).lineLimit(2)
            if let p = c.progress {
                GeometryReader { g in
                    ZStack(alignment: .leading) {
                        Capsule().fill(.white.opacity(0.3))
                        Capsule().fill(.white).frame(width: max(4, g.size.width * min(max(p, 0), 1)))
                    }
                }
                .frame(height: 4).padding(.top, 7)
                if let pct { Text(pct).font(.system(size: 10, weight: .semibold).monospacedDigit()).opacity(0.85).frame(maxWidth: .infinity, alignment: .trailing) }
            }
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .foregroundStyle(.white)
        .background(LinearGradient(colors: [theme.accent, theme.accent2], startPoint: .topLeading, endPoint: .bottomTrailing))
        .clipShape(RoundedRectangle(cornerRadius: store.data.appearance.radius))
    }

    private func content(_ state: NowState, _ date: Date) -> (label: String, big: String, sub: String, timer: String?, timerLabel: String, progress: Double?) {
        let sec = T.secondsNow(date)
        func until(_ minute: Int) -> String { T.timer(minute * 60 - sec) }
        switch state {
        case let .before(next, minutes):
            return ("Before school", next.title, "School starts at \(T.clock(next.start))",
                    minutes <= 180 ? until(next.start) : nil, "until school", nil)
        case let .during(item, _, _, next):
            let where_ = item.detail ?? (item.kind == .lunch ? "Lunch" : "Now")
            var sub = "Ends at \(T.clock(item.end))"
            if let n = next { sub += " · Next: \(n.title)" }
            let total = Double(max(1, (item.end - item.start) * 60))
            return ("Now · \(where_)", item.title, sub, until(item.end), "left", Double(sec - item.start * 60) / total)
        case let .passing(next, _):
            return ("Passing time", next.title, "Starts at \(T.clock(next.start))", until(next.start), "to get there", nil)
        case let .freeTime(until_, _):
            return ("Free time", "Then \(until_.title)", "Starts at \(T.clock(until_.start))", until(until_.start), "free", nil)
        case let .event(e, _):
            return ("Now", e.title, "Ends at \(T.clock(e.end))", until(e.end), "left", nil)
        case .done:
            return ("School’s out", "Done for today", nextDayText(date), nil, "", nil)
        case .noSchool:
            return ("No school today", "Enjoy your day", nextDayText(date), nil, "", nil)
        }
    }

    private func nextDayText(_ date: Date) -> String {
        let engine = store.engine
        guard let d = engine.nextSchoolDay(after: date) else { return "No school days coming up" }
        let f = DateFormatter()
        f.dateFormat = "EEEE"
        let day = engine.school.rotationLength > 1 ? " · \(engine.dayLabel(d))" : ""
        return "Next school day: \(f.string(from: d))\(day)"
    }
}

struct ScheduleRow: View {
    let item: Item
    let minute: Int
    let theme: Theme
    let store: Store

    var body: some View {
        let past = item.end <= minute
        let now = item.start <= minute && minute < item.end
        HStack(spacing: 9) {
            Circle().fill(dotColor).frame(width: 7, height: 7)
            Text(T.short(item.start)).font(.system(size: 11.5).monospacedDigit()).foregroundStyle(theme.muted).frame(width: 34, alignment: .leading)
            Text(item.title).font(.system(size: 12.5, weight: now ? .bold : .regular)).lineLimit(1)
            Spacer(minLength: 4)
            if now {
                Text("now").font(.system(size: 10, weight: .bold)).padding(.horizontal, 6).padding(.vertical, 2)
                    .background(theme.accent).foregroundStyle(.white).clipShape(Capsule())
            } else if item.kind == .event {
                Image(systemName: "star.fill").font(.system(size: 9)).foregroundStyle(theme.muted)
            }
        }
        .padding(.vertical, 6)
        .opacity(past ? 0.45 : 1)
    }

    private var dotColor: Color {
        switch item.kind {
        case .classTime: return item.colorHex.map(Color.init(hex:)) ?? theme.muted
        case .lunch: return Color(hex: "#48B833")
        case .advisory: return Color(hex: "#D94E4E")
        case .event: return theme.accent2
        case .other: return theme.muted
        }
    }
}

// MARK: - Homework

struct HomeworkView: View {
    @EnvironmentObject var store: Store
    @State private var adding = false
    @State private var title = ""
    @State private var classKey = ""
    @State private var due = T.addDays(Date(), 1)
    @State private var when: HomeworkWhen = .atNight

    var body: some View {
        let th = store.theme
        VStack(alignment: .leading, spacing: 10) {
            if adding { form(th) } else {
                Button {
                    classKey = store.data.classes.first?.key ?? ""
                    due = store.nextClassDay(for: classKey) ?? T.addDays(Date(), 1)
                    adding = true
                } label: {
                    Label("Add homework", systemImage: "plus")
                        .font(.system(size: 12.5, weight: .semibold))
                        .frame(maxWidth: .infinity).padding(.vertical, 8)
                        .background(th.card).clipShape(RoundedRectangle(cornerRadius: 9))
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
            }
            SchoologyBar(theme: th)
            list(th)
        }
    }

    private func form(_ th: Theme) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            TextField("What’s the homework?", text: $title).textFieldStyle(.roundedBorder)
            Picker("Class", selection: $classKey) {
                ForEach(store.data.classes) { Text($0.name).tag($0.key) }
            }
            .onChange(of: classKey) { _, key in due = store.nextClassDay(for: key) ?? due }
            DatePicker("Due", selection: $due, displayedComponents: .date)
            Picker("", selection: $when) {
                ForEach(HomeworkWhen.allCases) { Text($0.label).tag($0) }
            }
            .pickerStyle(.segmented).labelsHidden()
            HStack {
                Spacer()
                Button("Cancel") { adding = false; title = "" }
                Button("Add") {
                    store.data.homework.append(Homework(classKey: classKey, title: title.trimmingCharacters(in: .whitespaces),
                                                        due: T.dayString(due), when: when))
                    title = ""
                    adding = false
                }
                .keyboardShortcut(.defaultAction)
                .disabled(title.trimmingCharacters(in: .whitespaces).isEmpty)
            }
        }
        .font(.system(size: 12))
        .padding(10).background(th.card).clipShape(RoundedRectangle(cornerRadius: 10))
    }

    private func list(_ th: Theme) -> some View {
        let today = T.dayString(store.now)
        let tomorrow = T.dayString(T.addDays(store.now, 1))
        let open = store.data.homework.filter { !$0.done }.sorted { ($0.due, $0.title) < ($1.due, $1.title) }
        let groups: [(String, [Homework])] = [
            ("Late", open.filter { $0.due < today }),
            ("Due today", open.filter { $0.due == today }),
            ("Due tomorrow", open.filter { $0.due == tomorrow }),
            ("Coming up", open.filter { $0.due > tomorrow }),
            ("Done", store.data.homework.filter(\.done).sorted { ($0.doneAt ?? "") > ($1.doneAt ?? "") }),
        ].filter { !$0.1.isEmpty }
        return ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                if groups.isEmpty {
                    Text("No homework. Nice!").font(.system(size: 12.5)).foregroundStyle(th.muted)
                        .frame(maxWidth: .infinity).padding(.vertical, 24)
                }
                ForEach(groups, id: \.0) { name, items in
                    VStack(alignment: .leading, spacing: 4) {
                        Text(name.uppercased()).font(.system(size: 10, weight: .bold)).foregroundStyle(name == "Late" ? .red : th.muted)
                        ForEach(items) { HomeworkRow(hw: $0, theme: th) }
                    }
                }
            }
        }
        .frame(maxHeight: 330)
    }
}

/// In the Homework tab: shows when Schoology last synced, with a button to sync now.
struct SchoologyBar: View {
    @EnvironmentObject var store: Store
    let theme: Theme
    @State private var busy = false

    var body: some View {
        if let link = store.data.schoologyURL, !link.isEmpty {
            HStack(spacing: 6) {
                Image(systemName: store.data.schoologyError == nil ? "checkmark.circle" : "exclamationmark.triangle")
                    .foregroundStyle(store.data.schoologyError == nil ? theme.muted : .orange)
                Text(status).lineLimit(1)
                Spacer(minLength: 4)
                Button(busy ? "Syncing…" : "Sync now") {
                    busy = true
                    Schoology.shared.sync { _ in busy = false }
                }
                .buttonStyle(.plain).foregroundStyle(theme.accent).disabled(busy)
            }
            .font(.system(size: 11)).foregroundStyle(theme.muted)
            .help(store.data.schoologyError ?? "Homework from your Schoology calendar syncs every 30 minutes. Check it off here when you’re done.")
        }
    }

    private var status: String {
        if store.data.schoologyError != nil { return "Schoology didn’t sync. Hover for help." }
        guard let s = store.data.schoologyLastSync, let d = ISO8601DateFormatter().date(from: s) else { return "Schoology: not synced yet" }
        let f = RelativeDateTimeFormatter()
        f.unitsStyle = .short
        return "Schoology synced \(f.localizedString(for: d, relativeTo: Date()))"
    }
}

struct HomeworkRow: View {
    @EnvironmentObject var store: Store
    let hw: Homework
    let theme: Theme
    @State private var hover = false

    var body: some View {
        let cls = store.classInfo(hw.classKey)
        HStack(alignment: .top, spacing: 9) {
            Button { store.toggle(hw) } label: {
                Image(systemName: hw.done ? "checkmark.circle.fill" : "circle")
                    .font(.system(size: 15)).foregroundStyle(hw.done ? theme.accent : theme.muted)
            }
            .buttonStyle(.plain)
            VStack(alignment: .leading, spacing: 2) {
                Text(hw.title).font(.system(size: 12.5, weight: .medium)).strikethrough(hw.done).lineLimit(2)
                HStack(spacing: 5) {
                    Circle().fill(cls.map { Color(hex: $0.colorHex) } ?? theme.muted).frame(width: 6, height: 6)
                    if hw.fromSchoology {
                        Image(systemName: "arrow.triangle.2.circlepath").font(.system(size: 9, weight: .bold)).foregroundStyle(theme.muted)
                            .help("From your Schoology calendar")
                    }
                    Text("\(cls?.name ?? store.className(hw.classKey)) · \(hw.kind == .test ? "Test" : hw.when.label) · \(T.nice(hw.due, relativeTo: store.now))\(hw.isPlanned && !hw.done ? " · \(T.duration(hw.estimate))" : "")")
                        .font(.system(size: 11)).foregroundStyle(theme.muted).lineLimit(1)
                }
            }
            Spacer(minLength: 0)
            Button { store.delete(hw) } label: { Image(systemName: "xmark").font(.system(size: 10, weight: .bold)) }
                .buttonStyle(.plain).foregroundStyle(theme.muted).opacity(hover ? 1 : 0).help("Delete")
        }
        .padding(9)
        .background(theme.card)
        .clipShape(RoundedRectangle(cornerRadius: 9))
        .onHover { hover = $0 }
        .contextMenu {
            Menu("How long will it take?") {
                ForEach([10, 15, 20, 30, 45, 60, 90, 120, 180, 240], id: \.self) { m in
                    Button((hw.estimate == m ? "✓ " : "") + T.duration(m)) { store.setMinutes(hw, m) }
                }
            }
            Menu("Class") {
                ForEach(store.data.classes) { c in
                    Button((store.baseKey(hw.classKey) == c.key ? "✓ " : "") + c.name) { store.setClass(hw, c.key) }
                }
            }
            if let link = hw.link, let url = URL(string: link) {
                Button("Open in Schoology") { NSWorkspace.shared.open(url) }
            }
            Button("Delete", role: .destructive) { store.delete(hw) }
        }
    }
}

// MARK: - Plan (the homework schedule)

struct PlanView: View {
    @EnvironmentObject var store: Store

    var body: some View {
        let th = store.theme
        let days = Planner.plan(store.data, engine: store.engine, now: store.now)
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                if days.isEmpty {
                    VStack(spacing: 6) {
                        Image(systemName: "sparkles").font(.system(size: 20)).foregroundStyle(th.accent)
                        Text("No homework to plan").font(.system(size: 13, weight: .semibold))
                        Text("Type what you got in the box below, like “bio worksheet due Friday, math test Thursday,” and I’ll make you a schedule.")
                            .font(.system(size: 11.5)).foregroundStyle(th.muted).multilineTextAlignment(.center)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    .frame(maxWidth: .infinity).padding(.vertical, 22).padding(.horizontal, 10)
                }
                ForEach(days) { d in PlanDayView(day: d, theme: th) }
            }
        }
        .frame(maxHeight: 330)
    }
}

struct PlanDayView: View {
    @EnvironmentObject var store: Store
    let day: PlanDay
    let theme: Theme

    var body: some View {
        let isToday = day.day == T.dayString(store.now)
        let name = isToday ? (store.engine.isSchoolDay(day.date) ? "Tonight" : "Today") : T.nice(day.day, relativeTo: store.now)
        VStack(alignment: .leading, spacing: 5) {
            HStack(spacing: 6) {
                Text(name.uppercased()).font(.system(size: 10, weight: .bold)).foregroundStyle(isToday ? theme.accent : theme.muted)
                Text("· \(T.duration(day.total))").font(.system(size: 10, weight: .semibold)).foregroundStyle(theme.muted)
                if day.busy {
                    Text("Busy").font(.system(size: 9.5, weight: .bold)).padding(.horizontal, 5).padding(.vertical, 1)
                        .background(Color.orange.opacity(0.18)).foregroundStyle(.orange).clipShape(Capsule())
                        .help("More than your usual homework time. Try starting some of it earlier.")
                }
                Spacer()
                if let s = day.startAt, day.left > 0 {
                    Text("start \(isToday ? "around " : "")\(T.clock(s))").font(.system(size: 10.5)).foregroundStyle(theme.muted)
                }
            }
            ForEach(day.entries) { PlanRow(entry: $0, theme: theme, isToday: isToday) }
        }
    }
}

struct PlanRow: View {
    @EnvironmentObject var store: Store
    let entry: PlanEntry
    let theme: Theme
    let isToday: Bool

    var body: some View {
        let hw = entry.hw
        let cls = store.classInfo(hw.classKey)
        HStack(alignment: .center, spacing: 9) {
            if isToday {
                Button { store.toggleSession(hw, minutes: entry.minutes) } label: {
                    Image(systemName: entry.checked ? "checkmark.circle.fill" : "circle")
                        .font(.system(size: 15)).foregroundStyle(entry.checked ? theme.accent : theme.muted)
                }
                .buttonStyle(.plain).help(entry.checked ? "Not done yet" : "Done with this")
            } else {
                Circle().fill(cls.map { Color(hex: $0.colorHex) } ?? theme.muted).frame(width: 7, height: 7).padding(.horizontal, 4)
            }
            VStack(alignment: .leading, spacing: 1) {
                Text(title).font(.system(size: 12.5, weight: .medium)).strikethrough(entry.checked).lineLimit(1)
                Text(detail(cls)).font(.system(size: 10.5)).foregroundStyle(late ? .orange : theme.muted).lineLimit(1)
            }
            Spacer(minLength: 4)
            Text(T.duration(entry.minutes)).font(.system(size: 11, weight: .semibold).monospacedDigit())
                .padding(.horizontal, 7).padding(.vertical, 3)
                .background(theme.bg.opacity(0.6)).clipShape(Capsule())
        }
        .padding(.horizontal, 9).padding(.vertical, 7)
        .background(theme.card)
        .clipShape(RoundedRectangle(cornerRadius: 9))
        .opacity(entry.checked ? 0.6 : 1)
    }

    private var title: String {
        let t = entry.hw.title
        if entry.hw.kind == .test, !t.lowercased().contains("study") { return "Study: \(t)" }
        return t
    }

    private var late: Bool { entry.hw.due < T.dayString(store.now) && !entry.checked }

    private func detail(_ cls: ClassInfo?) -> String {
        var parts = [cls?.name ?? store.className(entry.hw.classKey)]
        let due = T.nice(entry.hw.due, relativeTo: store.now)
        let d = ["Today", "Tomorrow", "Yesterday"].contains(due) ? due.lowercased() : due
        if late { parts.append("late, was due \(d)") }
        else { parts.append(entry.hw.kind == .test ? "test \(d)" : "due \(d)") }
        if entry.parts > 1 { parts.append("\(entry.part) of \(entry.parts)") }
        return parts.joined(separator: " · ")
    }
}

// MARK: - Quick homework bar

/// Type what you got ("bio worksheet due fri, math test thursday") and it adds it all and plans it.
struct QuickAddBar: View {
    @EnvironmentObject var store: Store
    var compact = false
    var onAdded: () -> Void
    @State private var text = ""
    @State private var working = false
    @State private var added: [Homework] = []
    @State private var message: String?
    @FocusState private var focused: Bool

    var body: some View {
        let th = store.theme
        VStack(alignment: .leading, spacing: 6) {
            if !added.isEmpty { result(th) }
            if let message { Text(message).font(.system(size: 11)).foregroundStyle(.orange).fixedSize(horizontal: false, vertical: true) }
            HStack(spacing: 7) {
                Image(systemName: "sparkles").font(.system(size: 12, weight: .semibold)).foregroundStyle(th.accent)
                TextField("", text: $text, prompt: Text("Got homework? Type it here…").foregroundStyle(th.muted))
                    .textFieldStyle(.plain).font(.system(size: 12.5))
                    .focused($focused)
                    .onSubmit(submit)
                    .disabled(working)
                if working {
                    ProgressView().controlSize(.small)
                } else {
                    Button(action: submit) { Image(systemName: "arrow.up.circle.fill").font(.system(size: 17)) }
                        .buttonStyle(.plain).foregroundStyle(text.trimmingCharacters(in: .whitespaces).isEmpty ? th.muted : th.accent)
                        .disabled(text.trimmingCharacters(in: .whitespaces).isEmpty)
                        .help("Add it (or press Return)")
                }
            }
            .padding(.horizontal, 9).padding(.vertical, 7)
            .background(th.card)
            .clipShape(RoundedRectangle(cornerRadius: 10))
            .overlay(RoundedRectangle(cornerRadius: 10).stroke(focused ? th.accent : th.line, lineWidth: focused ? 1.5 : 1))
            if !compact || focused || !text.isEmpty { classPicker(th) }
        }
        .onChange(of: store.focusQuickBar) { _, _ in focused = true }
        .onChange(of: focused) { _, f in store.quickTyping = f || !text.isEmpty }
        .onChange(of: text) { _, t in store.quickTyping = focused || !t.isEmpty }
    }

    private func classPicker(_ th: Theme) -> some View {
        let auto = store.engine.recentClass(store.now).map { $0.title }
        let name = store.quickClass.map(store.className) ?? auto ?? "pick a class"
        return HStack(spacing: 4) {
            Menu {
                Button("Automatic" + (auto.map { " (\($0))" } ?? "")) { store.quickClass = nil }
                Divider()
                ForEach(store.data.classes) { c in Button(c.name) { store.quickClass = c.key } }
            } label: {
                Text("Class: \(name)").font(.system(size: 10.5)).lineLimit(1)
            }
            .menuStyle(.borderlessButton).menuIndicator(.visible).fixedSize()
            .help("If you don’t type a class name (like “bio” or “math”), homework goes to this class. It picks the class you’re in or just left.")
            Spacer()
            Text(HomeworkAI.engineName).font(.system(size: 10)).foregroundStyle(th.muted).lineLimit(1).fixedSize()
                .help(HomeworkAI.aiAvailable ? "Uses the Apple Intelligence built into your Mac. Nothing leaves your Mac."
                      : "Reads your note on your Mac. On a Mac with Apple Intelligence turned on, it understands even more.")
        }
        .foregroundStyle(th.muted)
    }

    private func result(_ th: Theme) -> some View {
        VStack(alignment: .leading, spacing: 3) {
            HStack {
                Label("Added \(added.count) to your plan", systemImage: "checkmark.circle.fill")
                    .font(.system(size: 11.5, weight: .semibold)).foregroundStyle(th.accent)
                Spacer()
                Button("Undo") { store.remove(added); added = [] }.buttonStyle(.plain).font(.system(size: 11, weight: .semibold))
                Button { added = [] } label: { Image(systemName: "xmark").font(.system(size: 9, weight: .bold)) }.buttonStyle(.plain).foregroundStyle(th.muted)
            }
            ForEach(added) { h in
                Text("• \(h.title) · \(store.className(h.classKey)) · \(h.kind == .test ? "test" : "due") \(T.nice(h.due, relativeTo: store.now)) · \(T.duration(h.estimate))")
                    .font(.system(size: 10.5)).foregroundStyle(th.muted).lineLimit(1)
            }
        }
        .padding(8)
        .background(th.accent.opacity(0.1))
        .clipShape(RoundedRectangle(cornerRadius: 9))
    }

    private func submit() {
        let note = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !note.isEmpty, !working else { return }
        working = true
        message = nil
        Task { @MainActor in
            let res = await store.quickAdd(note, classKey: nil)
            working = false
            if res.isEmpty {
                if Rules.isNothing(note) { text = ""; message = nil; return }
                message = "I couldn’t find homework in that. Try something like “worksheet due Friday.”"
            } else {
                added = res
                text = ""
                store.quickClass = nil
                onAdded()
            }
        }
    }
}
