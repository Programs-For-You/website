// School Schedule for Mac. Copyright (c) 2026 Owen Wang (original School Schedule Manager) and Brady Krupa
// (macOS version, ported to macOS using Claude AI). Licensed under the GNU AGPL v3; see LICENSE.
import Foundation
#if canImport(FoundationModels)
import FoundationModels
#endif

/// One piece of homework read out of a quick note.
struct ParsedHomework: Equatable {
    var classKey: String
    var title: String
    var due: Date
    var kind: HomeworkKind
    var minutes: Int
    var minutesTyped = false     // the note said how long ("45 min")
}

/// Turns a quick note ("bio worksheet due fri, math test thursday") into homework.
/// Uses Apple Intelligence when the Mac has it, and a built-in reader otherwise.
enum HomeworkAI {
    struct Context {
        var classes: [ClassInfo]
        var defaultKey: String?
        var now: Date
        var nextClassDay: (String) -> Date?
        var nextSchoolDay: () -> Date?
    }

    static var aiAvailable: Bool {
        #if canImport(FoundationModels)
        if #available(macOS 26.0, *) { return AppleAI.isAvailable }
        #endif
        return false
    }

    static var engineName: String { aiAvailable ? "Apple Intelligence" : "Smart typing" }

    static func parse(_ text: String, _ ctx: Context) async -> [ParsedHomework] {
        let note = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !note.isEmpty else { return [] }
        if Rules.isNothing(note) { return [] }
        let ruled = Rules.parse(note, ctx)
        #if canImport(FoundationModels)
        // The built-in reader decides what the homework is, its class, and its due date (it never makes things up).
        // Apple Intelligence then adds a time estimate and a tidier title, when its answer lines up with the reader's.
        if !ruled.isEmpty, #available(macOS 26.0, *), AppleAI.isAvailable, ProcessInfo.processInfo.environment["SS_NO_AI"] == nil,
           let ai = try? await AppleAI.parse(note, ctx), ai.count == ruled.count {
            return zip(ruled, ai).map { r, a in
                var out = r
                if !Rules.vet([a], note: note).isEmpty, !Rules.vet([a], note: r.title).isEmpty { out.title = a.title }
                if !r.minutesTyped {
                    let range: ClosedRange<Int> = out.kind == .test ? 30...120 : out.kind == .project ? 45...240 : 10...90
                    out.minutes = Rules.round5(min(max(a.minutes, range.lowerBound), range.upperBound))
                }
                return out
            }
        }
        #endif
        return ruled
    }
}

// MARK: - Apple Intelligence

#if canImport(FoundationModels)
@available(macOS 26.0, *)
enum AppleAI {
    static let notSaid = "Not said"

    static var isAvailable: Bool {
        if case .available = SystemLanguageModel.default.availability { return true }
        return false
    }

    static func parse(_ note: String, _ ctx: HomeworkAI.Context) async throws -> [ParsedHomework] {
        var names: [String] = []
        for c in ctx.classes where !c.name.isEmpty && !names.contains(c.name) { names.append(c.name) }
        let item = DynamicGenerationSchema(name: "Homework", properties: [
            .init(name: "title", description: "Short title using only the student's own words from the note. Leave out the class name and the due date.",
                  schema: DynamicGenerationSchema(type: String.self)),
            .init(name: "className", description: "Which of the student's classes it is for",
                  schema: DynamicGenerationSchema(name: "ClassName", anyOf: names + [notSaid])),
            .init(name: "due", description: "When it is due, copied from the note, like 'friday', 'tomorrow', 'next class' or '3/14'. Empty if the note doesn't say.",
                  schema: DynamicGenerationSchema(type: String.self)),
            .init(name: "kind", schema: DynamicGenerationSchema(name: "Kind", anyOf: HomeworkKind.allCases.map(\.rawValue))),
            .init(name: "minutes", description: "About how many minutes a high school student needs for it",
                  schema: DynamicGenerationSchema(type: Int.self)),
        ])
        let root = DynamicGenerationSchema(name: "HomeworkNote", properties: [
            .init(name: "items", description: "One entry for each piece of homework in the note",
                  schema: DynamicGenerationSchema(arrayOf: item, minimumElements: 0, maximumElements: 8)),
        ])
        let schema = try GenerationSchema(root: root, dependencies: [])
        let f = DateFormatter()
        f.dateFormat = "EEEE, MMMM d"
        let session = LanguageModelSession(instructions: """
            A student typed a quick note about homework they just got. Turn it into a list with one entry per assignment, \
            reading, test, quiz, or project. Never add homework that isn't in the note. Today is \(f.string(from: ctx.now)). \
            The student's classes: \(names.joined(separator: ", ")). If the note doesn't say which class, use "\(notSaid)". \
            Tests and quizzes are kind "test". Essays, presentations, labs and long assignments are kind "project".
            """)
        let r = try await session.respond(to: note, schema: schema)
        let entries = (try? r.content.value([GeneratedContent].self, forProperty: "items")) ?? []
        return entries.compactMap { g -> ParsedHomework? in
            var rawTitle = (try? g.value(String.self, forProperty: "title")) ?? ""
            for c in ctx.classes where c.name.count >= 3 {   // "Math (3-in-2) 4.3 practice" → "4.3 practice"
                let without = rawTitle.replacingOccurrences(of: c.name, with: "", options: .caseInsensitive)
                if without != rawTitle, !Rules.tidy(without).isEmpty { rawTitle = without }
            }
            let title = Rules.cleanTitle(rawTitle, ctx)
            guard !title.isEmpty else { return nil }
            let cname = (try? g.value(String.self, forProperty: "className")) ?? notSaid
            // No class typed anywhere → use the class you just had (don't let the AI guess).
            let key = Rules.matchClass(in: note.lowercased(), ctx) == nil ? Rules.fallbackKey(ctx)
                : Rules.classKey(named: cname, ctx) ?? Rules.matchClass(in: rawTitle.lowercased(), ctx)?.key
                ?? Rules.matchClass(in: note.lowercased(), ctx, onlyIfOne: true)?.key ?? Rules.fallbackKey(ctx)
            var dueText = ((try? g.value(String.self, forProperty: "due")) ?? "").lowercased()
            if !note.lowercased().contains(dueText) { dueText = "" }      // only trust dates that are really in the note
            let due = Rules.findDue(in: dueText, key: key, ctx)?.date
                ?? Rules.findDue(in: rawTitle.lowercased(), key: key, ctx)?.date
                ?? Rules.defaultDue(key, ctx)
            var kind = HomeworkKind(rawValue: (try? g.value(String.self, forProperty: "kind")) ?? "") ?? Rules.kind(title.lowercased())
            if Rules.kind(title.lowercased()) == .test { kind = .test }
            var minutes = (try? g.value(Int.self, forProperty: "minutes")) ?? kind.defaultMinutes
            if let typed = Rules.typedMinutes(rawTitle.lowercased()) ?? (Rules.chunks(note, ctx).count == 1 ? Rules.typedMinutes(note.lowercased()) : nil) {
                minutes = typed
            }
            let range: ClosedRange<Int> = kind == .test ? 30...120 : kind == .project ? 45...240 : 10...90
            return ParsedHomework(classKey: key, title: title, due: due, kind: kind, minutes: Rules.round5(min(max(minutes, range.lowerBound), range.upperBound)))
        }
    }
}
#endif

// MARK: - Built-in reader (works on every Mac)

enum Rules {
    /// Words that mean the same subject, so "bio" finds a class named "Biology III".
    static let subjects: [[String]] = [
        ["math", "maths", "algebra", "alg", "geometry", "geo", "calc", "calculus", "precalc", "pre-calc", "stats", "statistics", "trig"],
        ["bio", "biology"], ["chem", "chemistry"], ["physics", "phys"], ["science", "sci"], ["anatomy"], ["earth science"],
        ["english", "ela", "lit", "literature", "writing"], ["humanities", "hum"],
        ["history", "hist", "apush", "social studies", "civics", "gov", "government", "econ", "economics"],
        ["spanish", "span"], ["french"], ["german"], ["latin"], ["chinese", "mandarin"], ["italian"], ["japanese"], ["asl"],
        ["robotics"], ["computer science", "cs", "coding", "programming", "apcsp"], ["art", "drawing", "ceramics"],
        ["music", "band", "chorus", "choir", "orchestra"], ["gym", "pe", "health"], ["speech", "public speaking", "debate"],
        ["psych", "psychology"], ["engineering"], ["business"], ["photo", "photography"],
    ]
    static let skipWords: Set<String> = ["honors", "intro", "advanced", "class", "period", "the", "and", "with", "mini", "level",
                                         "studies", "hall", "study", "block", "course", "for", "of", "ap", "cp"]

    // MARK: Whole note

    static func parse(_ note: String, _ ctx: HomeworkAI.Context) -> [ParsedHomework] {
        var lastKey: String?
        return chunks(note, ctx).compactMap { chunk in
            // "spanish workbook and vocab quiz" → the quiz is Spanish too.
            let found = item(chunk, ctx, inherit: lastKey)
            if let f = found, matchClass(in: chunk.lowercased(), ctx) != nil { lastKey = f.classKey }
            return found
        }
    }

    static let homeworkWords = #"\b(quiz|quizzes|tests?|exams?|worksheets?|essay|project|reading|read|problems?|questions?|lab|packet|homework|hw|workbook|notes|study|vocab|presentation|paper|assignment)\b"#

    /// Splits "bio worksheet, math test fri and read ch 5" into separate pieces.
    static func chunks(_ note: String, _ ctx: HomeworkAI.Context) -> [String] {
        var parts = split(note, #"[\n;•]+|,\s*|\.\s+(?=[A-Za-z])|\s+(?:and\s+)?also\s+|\s+plus\s+|\s+then\s+"#)
        // Split on "and" only when what follows names another class ("bio worksheet and math test").
        parts = parts.flatMap { p -> [String] in
            let pieces = split(p, #"\s+and\s+|\s*&\s*"#)
            guard pieces.count > 1 else { return [p] }
            var out = [pieces[0]]
            for piece in pieces.dropFirst() {
                let p = piece.lowercased()
                let newThing = matchClass(in: p, ctx) != nil || find(homeworkWords, in: p) != nil || findDue(in: p, key: "", ctx) != nil
                let leftWords = out[out.count - 1].split(separator: " ").count
                if newThing && leftWords >= 2 && p.split(separator: " ").count >= 2 { out.append(piece) } else { out[out.count - 1] += " and " + piece }
            }
            return out
        }
        return parts.map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }
    }

    static func isNothing(_ note: String) -> Bool {
        let t = note.lowercased().trimmingCharacters(in: .punctuationCharacters.union(.whitespacesAndNewlines))
        return ["no homework", "nothing", "none", "no hw", "n/a", "nope", "no", "nah", "nothing today", "no homework today"].contains(t)
    }

    /// Takes out filler like "um so", "we got", "mr k said".
    static func stripFillers(_ s: String) -> String {
        var t = s.trimmingCharacters(in: .whitespaces)
        for _ in 0..<4 {
            let before = t
            t = replace(t, #"^(?:um+|uh+|so|like|ok(?:ay)?|well|oh|also|and|then|plus)[\s,]+"#, "")
            t = replace(t, #"^(?:(?:i|we)\s+(?:have|got|need to do|need to|have to do|have to|gotta do|gotta)|there'?s|there is|there are|hw|homework|for homework)\s*:?\s+"#, "")
            t = replace(t, #"^(?:(?:mr|mrs|ms|miss|dr|mx)\.?\s+[a-z]+|the teacher|my teacher)\s+(?:said|says|assigned|gave us|wants)\s+(?:that\s+)?"#, "")
            if t == before { break }
        }
        return t
    }

    static func typedMinutes(_ s: String) -> Int? {
        if let m = find(#"\b(\d+(?:\.\d+)?)\s*(?:h|hr|hrs|hour|hours)\b"#, in: s), let v = Double(m.groups[1] ?? "") { return Int(v * 60) }
        if let m = find(#"\b(\d+)\s*(?:m|min|mins|minutes)\b"#, in: s), let v = Int(m.groups[1] ?? "") { return v }
        return nil
    }

    /// Cleans an AI title: no due date or time in it, no filler.
    static func cleanTitle(_ raw: String, _ ctx: HomeworkAI.Context) -> String {
        var t = stripFillers(raw.lowercased())
        if let d = findDue(in: t, key: "", ctx) { t.removeSubrange(d.range) }
        t = replace(t, #"\b\d+(?:\.\d+)?\s*(?:h|hr|hrs|hour|hours|m|min|mins|minutes)\b"#, "")
        let cleaned = tidy(t)
        // Keep the AI's capital letters where the words didn't change.
        return raw.lowercased().hasPrefix(cleaned.lowercased()) ? tidy(String(raw.prefix(cleaned.count))) : cleaned
    }

    /// Drops AI items whose title isn't really from the note, and repeats.
    static func vet(_ items: [ParsedHomework], note: String) -> [ParsedHomework] {
        let noteWords = Set(words(note))
        var seen = Set<String>()
        return items.filter { item in
            let w = words(item.title)
            guard !w.isEmpty else { return false }
            let hits = w.filter { word in noteWords.contains(word) || noteWords.contains { $0.hasPrefix(word) || word.hasPrefix($0) && $0.count >= 3 } }
            guard hits.count * 2 >= w.count else { return false }
            // Numbers (like "4.3" or "pg 45") must really be in the note.
            guard w.filter({ $0.contains(where: \.isNumber) }).allSatisfy(noteWords.contains) else { return false }
            return seen.insert(item.title.lowercased()).inserted
        }
    }

    private static func words(_ s: String) -> [String] {
        let stop: Set<String> = ["the", "and", "for", "due", "with", "from", "this", "that", "your", "you", "our", "a", "an", "of", "to", "on", "in"]
        return s.lowercased().split(whereSeparator: { !$0.isLetter && !$0.isNumber && $0 != "." })
            .map { $0.trimmingCharacters(in: CharacterSet(charactersIn: ".")) }
            .filter { ($0.count >= 3 || $0.contains(where: \.isNumber)) && !stop.contains($0) }
    }

    static func item(_ chunk: String, _ ctx: HomeworkAI.Context, inherit: String? = nil) -> ParsedHomework? {
        var text = stripFillers(chunk.lowercased())
        if isNothing(text) { return nil }
        let cls = matchClass(in: text, ctx)
        if let c = cls {   // "for math we got the 4.3 practice" → "the 4.3 practice"
            let t = replace(text, #"^(?:for|in)\s+"# + NSRegularExpression.escapedPattern(for: c.phrase) + #"(?:'s)?[\s,]+"#, "")
            if t != text { text = stripFillers(t) }
        }
        let key = cls?.key ?? inherit ?? fallbackKey(ctx)
        let kind = kind(text)
        var minutes = typedMinutes(text)
        let typed = minutes != nil
        if minutes != nil { text = replace(text, #"\b\d+(?:\.\d+)?\s*(?:h|hr|hrs|hour|hours|m|min|mins|minutes)\b"#, "") }
        var due: Date?
        if let d = findDue(in: text, key: key, ctx) {
            due = d.date
            text.removeSubrange(d.range)
        }
        if minutes == nil, let m = find(#"(?:pages?|pgs?|pp\.?|#|problems?|questions?|qs?)\s*(\d+)\s*(?:-|–|to)\s*(\d+)"#, in: text),
           let a = Int(m.groups[1] ?? ""), let b = Int(m.groups[2] ?? ""), b > a {
            minutes = min(max((b - a + 1) * 2, 10), 90)
        }
        // Take the class name out of the title when there's enough left to make sense ("bio worksheet" → "Worksheet").
        var title = text
        // Only when the class is at the start or end, so "study for robotics quiz" stays readable.
        if let c = cls {
            let esc = NSRegularExpression.escapedPattern(for: c.phrase)
            let without = replace(replace(text.trimmingCharacters(in: .whitespaces), #"^"# + esc + #"(?:'s)?\s+"#, ""), #"\s+(?:for|in)?\s*"# + esc + #"\s*$"#, "")
            if tidy(without).split(separator: " ").count >= 2 { title = without }
        }
        title = tidy(title)
        guard !title.isEmpty else { return nil }
        let est = minutes ?? kind.defaultMinutes
        return ParsedHomework(classKey: key, title: title, due: due ?? defaultDue(key, ctx), kind: kind,
                              minutes: round5(min(max(est, 5), 240)), minutesTyped: typed)
    }

    // MARK: Pieces

    static func kind(_ s: String) -> HomeworkKind {
        if find(#"\b(tests?|quiz|quizzes|exams?|midterms?|finals?|assessment|unit test)\b"#, in: s) != nil { return .test }
        if find(#"\b(project|essay|paper|presentation|lab report|poster|slideshow|slides|research|speech|labs?|write-?up)\b"#, in: s) != nil { return .project }
        if find(#"\b(problems?|questions?|worksheet|#\s*\d)"#, in: s) != nil { return .assignment }
        if find(#"^\s*read\b|\breading\b|\bchapters?\b|\bch\.?\s*\d|\bpages?\b|\bpgs?\b"#, in: s) != nil { return .reading }
        return .assignment
    }

    /// Finds the class a piece of text is about: its name, a subject word ("bio"), or "period 3".
    static func matchClass(in s: String, _ ctx: HomeworkAI.Context, onlyIfOne: Bool = false) -> (key: String, phrase: String)? {
        var best: [(key: String, phrase: String)] = []
        for c in ctx.classes {
            for phrase in phrases(for: c) where find(#"(?<![a-z0-9])"# + NSRegularExpression.escapedPattern(for: phrase) + #"(?![a-z0-9])"#, in: s) != nil {
                if best.isEmpty || phrase.count > best[0].phrase.count { best = [(c.key, phrase)] }
                else if phrase.count == best[0].phrase.count, !best.contains(where: { $0.key == c.key }) { best.append((c.key, phrase)) }
            }
        }
        if onlyIfOne {
            let keys = Set(ctx.classes.filter { c in phrases(for: c).contains { find(#"(?<![a-z0-9])"# + NSRegularExpression.escapedPattern(for: $0) + #"(?![a-z0-9])"#, in: s) != nil } }.map(\.key))
            if keys.count != 1 { return nil }
        }
        guard !best.isEmpty else { return nil }
        if best.count == 1 { return best[0] }
        // Two classes with the same name: pick the one that meets next.
        return best.min { (ctx.nextClassDay($0.key) ?? .distantFuture) < (ctx.nextClassDay($1.key) ?? .distantFuture) }
    }

    static func phrases(for c: ClassInfo) -> [String] {
        let name = c.name.lowercased().trimmingCharacters(in: .whitespaces)
        var out: [String] = []
        if name.count >= 2 { out.append(name) }
        let words = name.split(whereSeparator: { !$0.isLetter && $0 != "-" }).map { $0.trimmingCharacters(in: CharacterSet(charactersIn: "-")) }
        out += words.filter { $0.count >= 4 && !skipWords.contains($0) }
        for group in subjects where group.contains(where: { g in words.contains(g) || (g.contains(" ") && name.contains(g)) }) { out += group }
        let digits = c.key.filter(\.isNumber)
        if !digits.isEmpty, name.hasPrefix("period") || c.key.hasPrefix("P") || Int(c.key) != nil {
            out += ["period \(digits)", "p\(digits)", "per \(digits)"]
        }
        var seen = Set<String>()
        return out.filter { seen.insert($0).inserted }
    }

    static func classKey(named name: String, _ ctx: HomeworkAI.Context) -> String? {
        let matches = ctx.classes.filter { $0.name.caseInsensitiveCompare(name) == .orderedSame }
        if matches.count <= 1 { return matches.first?.key }
        return matches.min { (ctx.nextClassDay($0.key) ?? .distantFuture) < (ctx.nextClassDay($1.key) ?? .distantFuture) }?.key
    }

    static func fallbackKey(_ ctx: HomeworkAI.Context) -> String { ctx.defaultKey ?? ctx.classes.first?.key ?? "" }

    static func defaultDue(_ key: String, _ ctx: HomeworkAI.Context) -> Date {
        ctx.nextClassDay(key) ?? ctx.nextSchoolDay() ?? T.addDays(T.cal.startOfDay(for: ctx.now), 1)
    }

    /// Finds a due date in text: "tomorrow", "fri", "next friday", "next class", "in 3 days", "3/14", "march 14", "the 14th".
    static func findDue(in s: String, key: String, _ ctx: HomeworkAI.Context) -> (date: Date, range: Range<String.Index>)? {
        let today = T.cal.startOfDay(for: ctx.now)
        let lead = #"(?:\b(?:due|for|by|on|before)\s+)?(?:the\s+)?"#
        if let m = find(lead + #"\b(today|tonight|tomorrow|tmrw|tmr|tmw|tom)\b"#, in: s) {
            switch m.groups[1] {
            case "today": return (today, m.range)
            case "tonight": return (defaultDue(key, ctx), m.range)
            default: return (T.addDays(today, 1), m.range)
            }
        }
        if let m = find(lead + #"\bnext\s+(?:class|time|block|period)\b"#, in: s) { return (defaultDue(key, ctx), m.range) }
        let days = ["sunday": 1, "monday": 2, "mon": 2, "tuesday": 3, "tues": 3, "tue": 3, "wednesday": 4, "weds": 4, "wed": 4,
                    "thursday": 5, "thurs": 5, "thur": 5, "thu": 5, "friday": 6, "fri": 6, "saturday": 7]
        if let m = find(lead + #"(?:\b(next|this)\s+)?\b(monday|tuesday|wednesday|thursday|friday|saturday|sunday|mon|tues|tue|weds|wed|thurs|thur|thu|fri)\b"#, in: s),
           let wd = days[m.groups[2] ?? ""] {
            var d = T.addDays(today, 1)
            while T.cal.component(.weekday, from: d) != wd { d = T.addDays(d, 1) }
            if m.groups[1] == "next" {
                // "next friday" said early in the week means the Friday after this one.
                var sunday = T.addDays(today, 1)
                while T.cal.component(.weekday, from: sunday) != 1 { sunday = T.addDays(sunday, 1) }
                if d < sunday { d = T.addDays(d, 7) }
            }
            return (d, m.range)
        }
        if let m = find(lead + #"\bend\s+of\s+(?:the\s+)?week\b"#, in: s) {
            var d = today
            if T.cal.component(.weekday, from: d) >= 6 || T.cal.component(.weekday, from: d) == 1 { d = T.addDays(d, 1) }
            while T.cal.component(.weekday, from: d) != 6 { d = T.addDays(d, 1) }
            return (d, m.range)
        }
        if let m = find(#"(?:\bdue\s+)?\bin\s+(\d+|a|one|two|three|four|five|six|seven)\s+(days?|weeks?)\b"#, in: s) {
            let words = ["a": 1, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7]
            let n = Int(m.groups[1] ?? "") ?? words[m.groups[1] ?? ""] ?? 1
            return (T.addDays(today, (m.groups[2] ?? "").hasPrefix("week") ? n * 7 : n), m.range)
        }
        if let m = find(lead + #"\bnext\s+week\b"#, in: s) { return (T.addDays(today, 7), m.range) }
        if let m = find(lead + #"\b(\d{1,2})/(\d{1,2})(?:/(\d{2,4}))?\b"#, in: s), let mo = Int(m.groups[1] ?? ""), let dd = Int(m.groups[2] ?? ""),
           let d = dateFor(month: mo, day: dd, year: m.groups[3].flatMap { Int($0) }, today) {
            return (d, m.range)
        }
        let months = ["jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6, "jul": 7, "aug": 8, "sep": 9, "oct": 10, "nov": 11, "dec": 12]
        if let m = find(lead + #"\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+(\d{1,2})(?:st|nd|rd|th)?\b"#, in: s),
           let mo = months[m.groups[1] ?? ""], let dd = Int(m.groups[2] ?? ""), let d = dateFor(month: mo, day: dd, year: nil, today) {
            return (d, m.range)
        }
        if let m = find(lead + #"\b(\d{1,2})(?:st|nd|rd|th)\b(?!\s*(?:period|block|hour|grade|edition|ed\b|place))"#, in: s), let dd = Int(m.groups[1] ?? ""), (1...31).contains(dd) {
            var c = T.cal.dateComponents([.year, .month], from: today)
            c.day = dd
            if var d = T.cal.date(from: c) {
                if d < today { d = T.cal.date(byAdding: .month, value: 1, to: d) ?? d }
                return (d, m.range)
            }
        }
        return nil
    }

    private static func dateFor(month: Int, day: Int, year: Int?, _ today: Date) -> Date? {
        guard (1...12).contains(month), (1...31).contains(day) else { return nil }
        var y = year.map { $0 < 100 ? 2000 + $0 : $0 } ?? T.cal.component(.year, from: today)
        guard var d = T.cal.date(from: DateComponents(year: y, month: month, day: day)) else { return nil }
        if year == nil, d < T.addDays(today, -30) { y += 1; d = T.cal.date(from: DateComponents(year: y, month: month, day: day)) ?? d }
        return d
    }

    // MARK: Text helpers

    /// Cleans up a title: extra spaces, leftover "due"/"for", and a capital first letter.
    static func tidy(_ s: String) -> String {
        var t = s.replacingOccurrences(of: #"\s+"#, with: " ", options: .regularExpression)
        t = t.trimmingCharacters(in: CharacterSet(charactersIn: " ,.;:-–—!()"))
        for _ in 0..<3 {
            t = replace(t, #"^(?:due|for|by|on|in|and|to|a|an|the)\s+|\s+(?:due|for|by|on|in|and|to|is|it's)$"#, "")
            t = t.trimmingCharacters(in: CharacterSet(charactersIn: " ,.;:-–—!()"))
        }
        if let f = t.first { t = f.uppercased() + t.dropFirst() }
        return String(t.prefix(80))
    }

    static func round5(_ n: Int) -> Int { max(5, Int((Double(n) / 5).rounded()) * 5) }

    static func find(_ pattern: String, in s: String) -> (range: Range<String.Index>, groups: [String?])? {
        guard let re = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]) else { return nil }
        let ns = s as NSString
        guard let m = re.firstMatch(in: s, range: NSRange(location: 0, length: ns.length)), let r = Range(m.range, in: s) else { return nil }
        let groups = (0..<m.numberOfRanges).map { i -> String? in
            let g = m.range(at: i)
            return g.location == NSNotFound ? nil : ns.substring(with: g).lowercased()
        }
        return (r, groups)
    }

    static func replace(_ s: String, _ pattern: String, _ with: String) -> String {
        s.replacingOccurrences(of: pattern, with: with, options: [.regularExpression, .caseInsensitive])
    }

    static func split(_ s: String, _ pattern: String) -> [String] {
        guard let re = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]) else { return [s] }
        let ns = s as NSString
        var out: [String] = []
        var last = 0
        for m in re.matches(in: s, range: NSRange(location: 0, length: ns.length)) {
            out.append(ns.substring(with: NSRange(location: last, length: m.range.location - last)))
            last = m.range.location + m.range.length
        }
        out.append(ns.substring(from: last))
        return out
    }
}
