// School Schedule for Mac. Copyright (c) 2026 Owen Wang (original School Schedule Manager) and Brady Krupa
// (macOS version, ported to macOS using Claude AI). Licensed under the GNU AGPL v3; see LICENSE.
import AppKit

/// Class icons (Apple's SF Symbols), like the Lucide icons in the Windows app.
enum Icons {
    /// The icons you can pick from, with a word people would search for.
    static let choices: [(String, String)] = [
        ("book", "Reading"), ("book.closed", "Book"), ("text.book.closed", "Textbook"), ("character.book.closed", "Language"),
        ("books.vertical", "Library"), ("bookmark", "Bookmark"), ("pencil", "Writing"), ("pencil.and.outline", "Draft"),
        ("function", "Math"), ("x.squareroot", "Algebra"), ("sum", "Calculus"), ("plus.forwardslash.minus", "Arithmetic"),
        ("chart.bar", "Statistics"), ("chart.line.uptrend.xyaxis", "Graphs"), ("ruler", "Geometry"), ("number", "Numbers"),
        ("flask", "Chemistry"), ("atom", "Physics"), ("leaf", "Biology"), ("testtube.2", "Lab"), ("allergens", "Microbes"),
        ("globe.americas", "Geography"), ("globe", "World"), ("building.columns", "History"), ("scroll", "Ancient history"),
        ("map", "Maps"), ("newspaper", "Current events"), ("person.3", "Social studies"), ("bubble.left.and.bubble.right", "Spanish & languages"),
        ("music.note", "Music"), ("music.mic", "Choir"), ("guitars", "Band"), ("paintpalette", "Art"), ("paintbrush", "Painting"),
        ("camera", "Photography"), ("film", "Film"), ("theatermasks", "Theater"), ("megaphone", "Public speaking"),
        ("laptopcomputer", "Computers"), ("chevron.left.forwardslash.chevron.right", "Coding"), ("cpu", "Engineering"),
        ("gearshape.2", "Robotics"), ("wrench.and.screwdriver", "Tech ed"), ("hammer", "Shop"), ("airplane", "Flight"),
        ("sportscourt", "Gym"), ("figure.run", "Running"), ("heart", "Health"), ("cross.case", "Medicine"), ("brain.head.profile", "Psychology"),
        ("dollarsign.circle", "Economics"), ("briefcase", "Business"), ("fork.knife", "Cooking & lunch"), ("cup.and.saucer", "Break"),
        ("person.2", "Advisory"), ("studentdesk", "Study hall"), ("graduationcap", "Seminar"), ("lightbulb", "Ideas"),
        ("star", "Favorite"), ("flag", "Flag"), ("pawprint", "Animals"), ("sun.max", "Outdoors"), ("gamecontroller", "Games"),
    ]

    /// Picks an icon from the class name ("Biology III" → leaf).
    static func guess(_ name: String) -> String {
        let n = name.lowercased()
        let rules: [([String], String)] = [
            (["lunch"], "fork.knife"), (["advisory"], "person.2"), (["study hall", "study"], "studentdesk"),
            (["math", "algebra", "calc", "geometry", "trig", "precalc"], "function"), (["stat"], "chart.bar"),
            (["bio", "life sci", "anatomy"], "leaf"), (["chem"], "flask"), (["physics"], "atom"), (["science", "lab"], "testtube.2"),
            (["humanit", "english", "lit", "writing", "ela"], "book"), (["history", "civics", "gov"], "building.columns"),
            (["geograph", "world"], "globe.americas"), (["econ"], "dollarsign.circle"), (["business"], "briefcase"),
            (["spanish", "french", "german", "latin", "chinese", "mandarin", "italian", "japanese", "language", "asl"], "bubble.left.and.bubble.right"),
            (["robot"], "gearshape.2"), (["engineer"], "cpu"), (["computer", "coding", "programming", "cs "], "laptopcomputer"),
            (["flight", "aviation"], "airplane"), (["speak", "speech", "debate"], "megaphone"), (["theater", "drama"], "theatermasks"),
            (["music", "band", "chorus", "choir", "orchestra"], "music.note"), (["art", "draw", "paint", "ceramic"], "paintpalette"),
            (["photo"], "camera"), (["film", "video"], "film"), (["gym", "pe", "physical ed", "sport"], "sportscourt"),
            (["health"], "heart"), (["psych"], "brain.head.profile"), (["free"], "cup.and.saucer"),
        ]
        for (words, icon) in rules where words.contains(where: { n.contains($0) }) { return icon }
        return "book.closed"
    }

    /// SF Symbol names that exist on this Mac (a few are newer than macOS 14).
    static func exists(_ name: String) -> Bool { NSImage(systemSymbolName: name, accessibilityDescription: nil) != nil }

    static func safe(_ name: String) -> String { exists(name) ? name : "book.closed" }
}
