// School Schedule for Mac. Copyright (c) 2026 Owen Wang (original School Schedule Manager) and Brady Krupa
// (macOS version, ported to macOS using Claude AI). Licensed under the GNU AGPL v3; see LICENSE.
import SwiftUI

// MARK: - Binding helpers

func timeBinding(_ minutes: Binding<Int>) -> Binding<Date> {
    Binding(
        get: { T.cal.date(bySettingHour: minutes.wrappedValue / 60 % 24, minute: minutes.wrappedValue % 60, second: 0, of: Date()) ?? Date() },
        set: { let c = T.cal.dateComponents([.hour, .minute], from: $0); minutes.wrappedValue = (c.hour ?? 0) * 60 + (c.minute ?? 0) }
    )
}

func dayBinding(_ s: Binding<String>) -> Binding<Date> {
    Binding(get: { T.date(s.wrappedValue) ?? Date() }, set: { s.wrappedValue = T.dayString($0) })
}

extension Store {
    var normalPeriods: Binding<[Period]> {
        Binding(get: { self.data.school.schedules["normal"] ?? [] },
                set: { self.data.school.schedules["normal"] = $0; self.normalizePlans() })
    }
}

// MARK: - Settings window

struct SettingsView: View {
    @EnvironmentObject var store: Store

    var body: some View {
        TabView {
            SchoolTab().tabItem { Label("School", systemImage: "building.columns") }
            ClassesTab().tabItem { Label("Classes", systemImage: "books.vertical") }
            RemindersTab().tabItem { Label("Reminders", systemImage: "bell") }
            SchoologyTab().tabItem { Label("Schoology", systemImage: "arrow.triangle.2.circlepath") }
            EventsTab().tabItem { Label("Events", systemImage: "calendar") }
            AppearanceTab().tabItem { Label("Look", systemImage: "paintpalette") }
            GeneralTab().tabItem { Label("General", systemImage: "gearshape") }
        }
        .padding(16)
        .frame(minWidth: 640, minHeight: 480)
    }
}

struct Section_<Content: View>: View {
    let title: String
    var note: String? = nil
    @ViewBuilder var content: Content
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title).font(.headline)
            if let note { Text(note).font(.callout).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true) }
            content
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.bottom, 18)
    }
}

// MARK: School

struct SchoolTab: View {
    @EnvironmentObject var store: Store
    @State private var todayDay = 1

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                if store.data.school.isWHS {
                    Section_(title: "WHS schedule", note: "You’re using the built-in WHS bell schedule for the 2026–27 school year, with Day 1–4, advisory, short days, and days off already filled in.") {
                        AdvisoryPicker()
                    }
                    Section_(title: "Yearly info code", note: "A short code with the school year’s first and last day, days off, short days, and advisory day, the same code as the Windows app. Paste a new one each school year, or copy yours to share with friends.") {
                        YearCodeEditor()
                    }
                    Section_(title: "Your lunch", note: "Which lunch you have on each day.") {
                        LunchPicker()
                    }
                } else {
                    Section_(title: "School name") {
                        TextField("School name", text: $store.data.school.name).frame(maxWidth: 300)
                    }
                    Section_(title: "Bell schedule", note: "Each period’s start and end time. Gaps between periods count as passing time.") {
                        PeriodsEditor(periods: store.normalPeriods)
                    }
                    Section_(title: "Rotation", note: "If your classes change from day to day (like Day 1–4 or A/B days), set how many days are in the rotation. Use 1 if every day is the same.") {
                        Stepper("Days in rotation: \(store.data.school.rotationLength)", value: Binding(
                            get: { store.data.school.rotationLength },
                            set: { store.data.school.rotationLength = $0; store.normalizePlans() }), in: 1...10)
                            .frame(maxWidth: 260)
                    }
                    if store.data.school.rotationLength > 1 {
                        Section_(title: "Which class meets when") { PlanGrid() }
                    }
                    Section_(title: "School year", note: "Optional. Outside these dates, the app shows “No school.”") {
                        YearEditor()
                    }
                }
                if store.data.school.rotationLength > 1 {
                    Section_(title: "Fix the day number", note: "Snow day or special schedule threw it off? Tell the app what day it is today and it will count from here.") {
                        HStack {
                            Picker("Today is", selection: $todayDay) {
                                ForEach(1...store.data.school.rotationLength, id: \.self) { Text("Day \($0)").tag($0) }
                            }
                            .frame(maxWidth: 200)
                            Button("Set") { store.data.school.anchor = DayAnchor(date: T.dayString(Date()), day: todayDay) }
                            if store.data.school.anchor != nil {
                                Button("Undo") { store.data.school.anchor = nil }
                            }
                        }
                    }
                }
                Section_(title: "Days off", note: "Holidays and breaks. Weekends are already skipped.") {
                    DaysOffEditor()
                }
                Section_(title: "Start over") {
                    Button(store.data.school.isWHS ? "My school is different…" : "Set up my school again…") { store.openSetup() }
                }
            }
            .padding(.trailing, 8)
        }
        .onAppear { todayDay = store.engine.rotationDay(Date()) ?? 1 }
    }
}

struct LunchPicker: View {
    @EnvironmentObject var store: Store
    let names = ["1st Lunch", "2nd Lunch", "3rd Lunch", "4th Lunch", "5th Lunch"]

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            ForEach(0..<store.data.school.rotationLength, id: \.self) { d in
                Picker("Day \(d + 1)", selection: Binding(
                    get: { store.data.school.lunchWaves?.wavePerDay[safe: d] ?? 1 },
                    set: { store.data.school.lunchWaves?.wavePerDay[d] = $0 })) {
                    ForEach(1...5, id: \.self) { Text(names[$0 - 1]).tag($0) }
                }
                .frame(maxWidth: 260)
            }
        }
    }
}

extension Array {
    subscript(safe i: Int) -> Element? { indices.contains(i) ? self[i] : nil }
}

struct PeriodsEditor: View {
    @Binding var periods: [Period]

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            ForEach($periods) { $p in
                HStack(spacing: 8) {
                    TextField("Name", text: $p.name).frame(width: 140)
                    Picker("", selection: $p.kind) {
                        ForEach(PeriodKind.allCases) { Text($0.label).tag($0) }
                    }
                    .labelsHidden().frame(width: 100)
                    DatePicker("", selection: timeBinding($p.start), displayedComponents: .hourAndMinute).labelsHidden()
                    Text("to").foregroundStyle(.secondary)
                    DatePicker("", selection: timeBinding($p.end), displayedComponents: .hourAndMinute).labelsHidden()
                    Button { periods.removeAll { $0.id == p.id } } label: { Image(systemName: "minus.circle") }
                        .buttonStyle(.borderless).help("Remove")
                }
            }
            Button {
                let last = periods.map(\.end).max() ?? T.m(8, 0)
                periods.append(Period(name: "Period \(periods.filter { $0.kind == .classTime }.count + 1)", start: last + 5, end: last + 55))
            } label: { Label("Add period", systemImage: "plus") }
            .buttonStyle(.borderless)
        }
    }
}

struct PlanGrid: View {
    @EnvironmentObject var store: Store

    var body: some View {
        let s = store.data.school
        let names = (s.schedules["normal"] ?? []).filter { $0.kind == .classTime }.map(\.name)
        ScrollView(.horizontal) {
            Grid(alignment: .leading, horizontalSpacing: 8, verticalSpacing: 6) {
                GridRow {
                    Text("")
                    ForEach(names.indices, id: \.self) { Text(names[$0]).font(.caption).foregroundStyle(.secondary) }
                }
                ForEach(0..<s.plans.count, id: \.self) { d in
                    GridRow {
                        Text("Day \(d + 1)").font(.callout.weight(.medium))
                        ForEach(0..<s.plans[d].slots.count, id: \.self) { i in
                            Picker("", selection: Binding(
                                get: { store.data.school.plans[safe: d]?.slots[safe: i] ?? "" },
                                set: { store.data.school.plans[d].slots[i] = $0 })) {
                                Text("Free").tag("")
                                ForEach(store.data.classes) { Text($0.name).tag($0.key) }
                            }
                            .labelsHidden().frame(width: 120)
                        }
                    }
                }
            }
            .padding(.bottom, 6)
        }
    }
}

struct YearEditor: View {
    @EnvironmentObject var store: Store

    var body: some View {
        let on = Binding(get: { store.data.school.yearStart != nil },
                         set: { on in
                             if on {
                                 let y = T.cal.component(.year, from: Date())
                                 let m = T.cal.component(.month, from: Date())
                                 let startYear = m >= 7 ? y : y - 1
                                 store.data.school.yearStart = "\(startYear)-08-25"
                                 store.data.school.yearEnd = "\(startYear + 1)-06-10"
                             } else {
                                 store.data.school.yearStart = nil
                                 store.data.school.yearEnd = nil
                             }
                         })
        VStack(alignment: .leading, spacing: 6) {
            Toggle("Set school year dates", isOn: on)
            if store.data.school.yearStart != nil {
                HStack {
                    DatePicker("First day", selection: dayBinding(Binding(get: { store.data.school.yearStart ?? "" }, set: { store.data.school.yearStart = $0 })), displayedComponents: .date)
                    DatePicker("Last day", selection: dayBinding(Binding(get: { store.data.school.yearEnd ?? "" }, set: { store.data.school.yearEnd = $0 })), displayedComponents: .date)
                }
                .frame(maxWidth: 460)
            }
        }
    }
}

struct DaysOffEditor: View {
    @EnvironmentObject var store: Store

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            ForEach($store.data.school.daysOff) { $r in
                HStack(spacing: 8) {
                    DatePicker("", selection: dayBinding($r.start), displayedComponents: .date).labelsHidden()
                    Text("to").foregroundStyle(.secondary)
                    DatePicker("", selection: dayBinding($r.end), displayedComponents: .date).labelsHidden()
                    TextField("Name (optional)", text: $r.name).frame(width: 160)
                    Button { store.data.school.daysOff.removeAll { $0.id == r.id } } label: { Image(systemName: "minus.circle") }
                        .buttonStyle(.borderless)
                }
            }
            Button {
                let s = T.dayString(Date())
                store.data.school.daysOff.append(DayRange(start: s, end: s))
            } label: { Label("Add day off", systemImage: "plus") }
            .buttonStyle(.borderless)
        }
    }
}

// MARK: Classes

struct ClassesTab: View {
    @EnvironmentObject var store: Store

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                Section_(title: "Your classes", note: store.data.school.isWHS
                         ? "Name each of your 8 periods. Have a mini class that only takes half a block? Open “Mini classes” under that period."
                         : "Name your classes and pick a color for each.") {
                    ClassNamesEditor(showMinis: store.data.school.isWHS || store.data.school.rotationLength > 1)
                }
            }
            .padding(.trailing, 8)
        }
    }
}

struct ClassNamesEditor: View {
    @EnvironmentObject var store: Store
    var showMinis = false

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            ForEach($store.data.classes) { $c in
                VStack(alignment: .leading, spacing: 4) {
                    HStack(spacing: 8) {
                        IconPicker(icon: $c.icon, name: c.name, color: Color(hex: c.colorHex))
                        ColorPicker("", selection: Binding(get: { Color(hex: c.colorHex) }, set: { c.colorHex = $0.hexString }), supportsOpacity: false)
                            .labelsHidden()
                        Text(store.data.school.isWHS ? "Period \(c.key)" : "").font(.callout).foregroundStyle(.secondary)
                            .frame(width: store.data.school.isWHS ? 64 : 0, alignment: .leading)
                        TextField("Class name", text: $c.name).frame(maxWidth: 260)
                        if !store.data.school.isWHS {
                            Button { store.data.classes.removeAll { $0.id == c.id }; store.normalizePlans() } label: { Image(systemName: "minus.circle") }
                                .buttonStyle(.borderless).help("Remove class")
                        }
                    }
                    if showMinis { MiniEditor(cls: $c) }
                }
            }
            if !store.data.school.isWHS {
                Button {
                    let n = (store.data.classes.compactMap { Int($0.key.dropFirst()) }.max() ?? 0) + 1
                    store.data.classes.append(ClassInfo(key: "P\(n)", name: "Class \(n)", colorHex: Templates.palette[(n - 1) % Templates.palette.count]))
                } label: { Label("Add class", systemImage: "plus") }
                .buttonStyle(.borderless)
            }
        }
    }
}

struct MiniEditor: View {
    @EnvironmentObject var store: Store
    @Binding var cls: ClassInfo

    var body: some View {
        let days = store.data.school.plans.indices.filter { store.data.school.plans[$0].slots.contains(cls.key) }.map { $0 + 1 }
        if !days.isEmpty {
            DisclosureGroup("Mini classes") {
                VStack(alignment: .leading, spacing: 6) {
                    Text("Leave blank to use \(cls.name) for the whole block.").font(.caption).foregroundStyle(.secondary)
                    ForEach(days, id: \.self) { d in
                        HStack(spacing: 8) {
                            Text("Day \(d)").frame(width: 44, alignment: .leading)
                            TextField("First half", text: mini(d, 0)).frame(width: 170)
                            TextField("Second half", text: mini(d, 1)).frame(width: 170)
                        }
                    }
                }
                .padding(.top, 4)
            }
            .font(.callout)
            .padding(.leading, 40)
        }
    }

    private func mini(_ day: Int, _ half: Int) -> Binding<String> {
        Binding(
            get: { cls.minis.first { $0.day == day && $0.half == half }?.name ?? "" },
            set: { name in
                cls.minis.removeAll { $0.day == day && $0.half == half }
                if !name.isEmpty { cls.minis.append(MiniClass(day: day, half: half, name: name)) }
            })
    }
}

// MARK: Reminders

struct RemindersTab: View {
    @EnvironmentObject var store: Store

    var body: some View {
        let hours = Array(0...23)
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                Section_(title: "After class", note: "When a class ends, a notification asks if you got homework. Click Add Homework, type it (like “worksheet due Friday”), and it goes into your plan.") {
                    Toggle("Ask what homework I got when a class ends", isOn: Binding(
                        get: { store.data.asksAfterClass }, set: { store.data.askAfterClass = $0 }))
                }
                Section_(title: "Homework plan", note: "The Plan tab spreads your homework over the nights before it’s due. Tests get study time on the nights right before.") {
                    Picker("Homework time on a school night", selection: Binding(
                        get: { store.data.nightlyCap }, set: { store.data.nightlyMinutes = $0 })) {
                        ForEach([45, 60, 90, 120, 150, 180, 240], id: \.self) { Text(T.duration($0)).tag($0) }
                    }
                    .frame(maxWidth: 330)
                }
                Section_(title: "Homework reminders", note: "Get a Mac notification before homework is due.") {
                    Toggle("Remind me about homework", isOn: $store.data.reminders.enabled)
                }
                if store.data.reminders.enabled {
                    Section_(title: "When") {
                        Picker("", selection: $store.data.reminders.smart) {
                            Text("Smart: “at night” homework the evening before, “in class” homework that morning").tag(true)
                            Text("Choose my own").tag(false)
                        }
                        .pickerStyle(.radioGroup).labelsHidden()
                        if !store.data.reminders.smart {
                            Toggle("The evening before it’s due", isOn: $store.data.reminders.eveningBefore)
                            Toggle("The morning it’s due", isOn: $store.data.reminders.morningOf)
                        }
                        HStack(spacing: 18) {
                            Picker("Evening reminder at", selection: $store.data.reminders.eveningHour) {
                                ForEach(hours, id: \.self) { Text(T.clock($0 * 60)).tag($0) }
                            }
                            .frame(maxWidth: 260)
                            Picker("Morning reminder at", selection: $store.data.reminders.morningHour) {
                                ForEach(hours, id: \.self) { Text(T.clock($0 * 60)).tag($0) }
                            }
                            .frame(maxWidth: 260)
                        }
                    }
                    Section_(title: "Test it", note: "If nothing shows up, open System Settings → Notifications → School Schedule and turn on Allow Notifications.") {
                        Button("Send a test notification") { Reminders.shared.sendTest() }
                    }
                }
            }
            .padding(.trailing, 8)
        }
    }
}

// MARK: Schoology

struct SchoologyTab: View {
    @EnvironmentObject var store: Store
    @State private var link = ""
    @State private var message: String?
    @State private var busy = false
    @State private var confirmUnlink = false

    private var linked: Bool { !(store.data.schoologyURL ?? "").isEmpty }
    private var count: Int { store.data.homework.filter { $0.fromSchoology && !$0.done }.count }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                Section_(title: "Your Schoology calendar", note: "Link your Schoology calendar and your homework shows up by itself in the Homework and Plan tabs. Check things off as you finish them. It syncs every 30 minutes.") {
                    if linked {
                        Label("Linked. \(count) unfinished assignment\(count == 1 ? "" : "s") from Schoology.", systemImage: "checkmark.circle.fill")
                            .foregroundStyle(.green)
                        if let e = store.data.schoologyError { Text(e).font(.callout).foregroundStyle(.red).fixedSize(horizontal: false, vertical: true) }
                        HStack {
                            Button(busy ? "Syncing…" : "Sync now") { sync() }.disabled(busy)
                            Button("Unlink Schoology…", role: .destructive) { confirmUnlink = true }
                                .confirmationDialog("Unlink your Schoology calendar?", isPresented: $confirmUnlink) {
                                    Button("Unlink", role: .destructive) { Schoology.shared.unlink(); message = nil }
                                } message: { Text("Schoology homework you haven’t checked off is removed. Homework you typed yourself stays.") }
                        }
                    } else {
                        TextField("Paste your Schoology calendar link (webcal://…)", text: $link)
                            .textFieldStyle(.roundedBorder)
                            .onSubmit { connect() }
                        HStack {
                            Button(busy ? "Linking…" : "Link Schoology") { connect() }
                                .keyboardShortcut(.defaultAction)
                                .disabled(busy || link.trimmingCharacters(in: .whitespaces).isEmpty)
                            Link("How do I get my link?", destination: URL(string: "https://programsforyou.com/download#schoology")!)
                        }
                    }
                    if let message { Text(message).font(.callout).foregroundStyle(message.hasPrefix("Linked") ? .green : .red).fixedSize(horizontal: false, vertical: true) }
                }
                Section_(title: "How to get your link", note: nil) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("1. Sign in to Schoology in your web browser.")
                        Text("2. Click Calendar at the top of the page.")
                        Text("3. Click Export (top right of the calendar).")
                        Text("4. Copy the link it shows. It starts with webcal://")
                        Text("5. Paste it above and click Link Schoology.")
                    }
                    .font(.callout)
                }
                Section_(title: "Good to know", note: "Your homework comes in with the class it matches by name; right-click one in the Homework tab to change its class or open it in Schoology. Deleting a Schoology assignment here only hides it in this app. Your link works like a password, so don’t share it. It’s saved on your Mac and only used to download your calendar from Schoology.") { EmptyView() }
            }
            .padding(.trailing, 8)
        }
    }

    private func connect() {
        let raw = link.trimmingCharacters(in: .whitespacesAndNewlines)
        guard Schoology.feedURL(raw) != nil else { message = "That doesn’t look like a link. Copy the whole link from Schoology and paste it again."; return }
        store.data.schoologyURL = raw
        store.data.schoologyHidden = nil
        busy = true
        message = nil
        Schoology.shared.sync { error in
            busy = false
            if let error {
                message = error
                store.data.schoologyURL = nil
                store.data.schoologyError = nil
            } else {
                link = ""
                message = "Linked! Your Schoology homework is in the Homework tab."
            }
        }
    }

    private func sync() {
        busy = true
        Schoology.shared.sync { error in
            busy = false
            message = error == nil ? "Linked and up to date." : nil
        }
    }
}

// MARK: Events

struct EventsTab: View {
    @EnvironmentObject var store: Store
    let days: [(Int, String)] = [(2, "M"), (3, "T"), (4, "W"), (5, "T"), (6, "F"), (7, "S"), (1, "S")]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                Section_(title: "After-school events", note: "Practices, clubs, games, jobs… on chosen weekdays or one date. After school, the app counts down your free time until they start.") {
                    ForEach($store.data.events) { $ev in
                        VStack(alignment: .leading, spacing: 6) {
                            HStack(spacing: 8) {
                                TextField("Name", text: $ev.name).frame(width: 170)
                                DatePicker("", selection: timeBinding($ev.start), displayedComponents: .hourAndMinute).labelsHidden()
                                Text("to").foregroundStyle(.secondary)
                                DatePicker("", selection: timeBinding($ev.end), displayedComponents: .hourAndMinute).labelsHidden()
                                Spacer()
                                Button { store.data.events.removeAll { $0.id == ev.id } } label: { Image(systemName: "trash") }
                                    .buttonStyle(.borderless)
                            }
                            HStack(spacing: 4) {
                                Picker("", selection: Binding(get: { ev.date != nil }, set: { one in ev.date = one ? T.dayString(Date()) : nil })) {
                                    Text("Repeats").tag(false); Text("One date").tag(true)
                                }
                                .pickerStyle(.segmented).labelsHidden().frame(width: 160).padding(.trailing, 8)
                                if ev.date != nil {
                                    DatePicker("", selection: dayBinding(Binding(get: { ev.date ?? T.dayString(Date()) }, set: { ev.date = $0 })), displayedComponents: .date)
                                        .labelsHidden()
                                } else {
                                    ForEach(days, id: \.0) { wd, letter in
                                        let on = ev.weekdays.contains(wd)
                                        Button(letter) {
                                            if on { ev.weekdays.removeAll { $0 == wd } } else { ev.weekdays.append(wd) }
                                        }
                                        .buttonStyle(.bordered)
                                        .tint(on ? .accentColor : .gray)
                                        .controlSize(.small)
                                    }
                                    Toggle("School days only", isOn: $ev.schoolDaysOnly).padding(.leading, 12)
                                }
                            }
                        }
                        .padding(10)
                        .background(Color.secondary.opacity(0.08))
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                    }
                    Button {
                        store.data.events.append(AfterSchoolEvent(name: "Practice", start: T.m(15, 30), end: T.m(17, 0), weekdays: [2, 3, 4, 5, 6]))
                    } label: { Label("Add event", systemImage: "plus") }
                    .buttonStyle(.borderless)
                }
            }
            .padding(.trailing, 8)
        }
    }
}

// MARK: Appearance

struct AppearanceTab: View {
    @EnvironmentObject var store: Store

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                Section_(title: "Theme") {
                    LazyVGrid(columns: Array(repeating: GridItem(.fixed(150), spacing: 12), count: 3), alignment: .leading, spacing: 12) {
                        ForEach(Theme.all + [Theme.resolve(Appearance(themeID: "custom", custom: store.data.appearance.custom))]) { t in
                            let selected = store.data.appearance.themeID == t.id
                            Button { store.data.appearance.themeID = t.id } label: {
                                VStack(alignment: .leading, spacing: 6) {
                                    RoundedRectangle(cornerRadius: 6)
                                        .fill(LinearGradient(colors: [t.accent, t.accent2], startPoint: .leading, endPoint: .trailing))
                                        .frame(height: 18)
                                    Text(t.name).font(.system(size: 12, weight: .semibold)).foregroundStyle(t.text)
                                }
                                .padding(10)
                                .frame(width: 150, alignment: .leading)
                                .background(t.bg)
                                .clipShape(RoundedRectangle(cornerRadius: 10))
                                .overlay(RoundedRectangle(cornerRadius: 10).stroke(selected ? Color.accentColor : Color.secondary.opacity(0.3), lineWidth: selected ? 2.5 : 1))
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
                if store.data.appearance.themeID == "custom" {
                    Section_(title: "Your colors", note: "Like Edit Style in the Windows app.") {
                        CustomColorsEditor()
                    }
                }
                Section_(title: "Accent color") {
                    Toggle("Use my own accent color", isOn: Binding(
                        get: { store.data.appearance.customAccent != nil },
                        set: { store.data.appearance.customAccent = $0 ? "#E5603B" : nil }))
                    if let hex = store.data.appearance.customAccent {
                        ColorPicker("Accent", selection: Binding(get: { Color(hex: hex) }, set: { store.data.appearance.customAccent = $0.hexString }),
                                    supportsOpacity: false)
                            .frame(maxWidth: 200)
                    }
                }
                Section_(title: "Highlights and text") {
                    Toggle("Use each class’s color for the overlay bar and timeline", isOn: Binding(
                        get: { store.data.appearance.usesClassColor }, set: { store.data.appearance.classColorAccent = $0 }))
                    Toggle("Blend colors along the timeline", isOn: Binding(
                        get: { store.data.appearance.gradientOn }, set: { store.data.appearance.timelineGradient = $0 }))
                    Toggle("24-hour time (14:30)", isOn: Binding(
                        get: { store.data.appearance.use24h ?? false }, set: { store.data.appearance.use24h = $0 }))
                    Toggle("Sharp corners", isOn: Binding(
                        get: { store.data.appearance.sharpCorners ?? false }, set: { store.data.appearance.sharpCorners = $0 }))
                    Toggle("Code-style font", isOn: Binding(
                        get: { store.data.appearance.monoFont ?? false }, set: { store.data.appearance.monoFont = $0 }))
                }
                Section_(title: "On screen", note: "Keep your schedule showing on top of your other windows. The overlay bar is the one from the Windows app: hover over it for a second to open your timeline, plan, and homework.") {
                    Picker("", selection: Binding(
                        get: { store.data.keepOnScreen == true ? (store.data.barStyle ? 2 : 1) : 0 },
                        set: { v in
                            if v == 0 { store.data.keepOnScreen = false } else { store.data.onScreenStyle = v == 2 ? "bar" : "card"; store.data.keepOnScreen = true }
                        })) {
                        Text("Off").tag(0); Text("Floating card").tag(1); Text("Overlay bar").tag(2)
                    }
                    .pickerStyle(.segmented).labelsHidden().frame(maxWidth: 360)
                    if store.data.keepOnScreen == true && !store.data.barStyle {
                        Toggle("Small size (just the timer and the homework box)", isOn: Binding(
                            get: { store.data.compactOnScreen ?? false }, set: { store.data.compactOnScreen = $0 }))
                        Text("Drag the card by its top to move it.").font(.callout).foregroundStyle(.secondary)
                    }
                    if store.data.keepOnScreen == true && store.data.barStyle {
                        Picker("Corner", selection: Binding(get: { store.data.corner }, set: { store.data.overlayCorner = $0 })) {
                            Text("Bottom left").tag("bottomLeft"); Text("Bottom right").tag("bottomRight")
                            Text("Top left").tag("topLeft"); Text("Top right").tag("topRight")
                        }
                        .frame(maxWidth: 260)
                        HStack {
                            Text("See-through")
                            Slider(value: Binding(get: { store.data.opacity }, set: { store.data.overlayOpacity = $0 }), in: 0.35...1)
                                .frame(maxWidth: 220)
                            Text("\(Int((store.data.opacity * 100).rounded()))%").monospacedDigit().foregroundStyle(.secondary)
                        }
                        HStack {
                            Text("Size")
                            Slider(value: Binding(get: { store.data.scale }, set: { store.data.overlayScale = $0 }), in: 0.8...1.5)
                                .frame(maxWidth: 220)
                            Text("\(Int((store.data.scale * 100).rounded()))%").monospacedDigit().foregroundStyle(.secondary)
                        }
                        Toggle("Let clicks pass through the bar until I hover on it", isOn: Binding(
                            get: { store.data.passThrough }, set: { store.data.clickThrough = $0 }))
                    }
                }
                Section_(title: "Menu bar") {
                    Toggle("Show the countdown next to the clock icon", isOn: $store.data.appearance.showCountdownInMenuBar)
                    Toggle("Count down with seconds, like a timer (23:41)", isOn: Binding(
                        get: { store.data.appearance.showSeconds ?? false }, set: { store.data.appearance.showSeconds = $0 }))
                        .disabled(!store.data.appearance.showCountdownInMenuBar)
                }
            }
            .padding(.trailing, 8)
        }
    }
}

// MARK: General

struct GeneralTab: View {
    @EnvironmentObject var store: Store
    @State private var loginOn = LoginItem.isOn
    @State private var loginError: String?
    @State private var confirmReset = false
    @State private var fileMessage: String?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                Section_(title: "Startup") {
                    Toggle("Open School Schedule when I log in", isOn: Binding(get: { loginOn }, set: { on in
                        loginError = LoginItem.set(on)
                        loginOn = LoginItem.isOn
                    }))
                    if let loginError { Text(loginError).font(.callout).foregroundStyle(.red) }
                }
                Section_(title: "Help") {
                    Link("Instructions on programsforyou.com", destination: URL(string: "https://programsforyou.com/school-schedule#how-to-use")!)
                    Link("Report a bug or send feedback", destination: License.feedbackURL)
                }
                Section_(title: "Settings file", note: "Everything is saved in one file (like the Windows app’s raw config). Edit it carefully, save it, then click Reload.") {
                    HStack {
                        Button("Show in Finder") { NSWorkspace.shared.activateFileViewerSelecting([store.dataFileURL]) }
                        Button("Open in TextEdit") { NSWorkspace.shared.open([store.dataFileURL], withApplicationAt: URL(fileURLWithPath: "/System/Applications/TextEdit.app"), configuration: .init()) }
                        Button("Reload") { fileMessage = store.reloadFromDisk() ?? "Reloaded." }
                    }
                    if let fileMessage { Text(fileMessage).font(.callout).foregroundStyle(fileMessage == "Reloaded." ? .green : .red).fixedSize(horizontal: false, vertical: true) }
                }
                Section_(title: "About") {
                    AboutBox()
                }
                Section_(title: "Reset", note: "Erases your classes, homework, events, and settings, then starts setup again.") {
                    Button("Reset everything…", role: .destructive) { confirmReset = true }
                        .confirmationDialog("Erase everything in School Schedule?", isPresented: $confirmReset) {
                            Button("Erase Everything", role: .destructive) {
                                store.data = AppData()
                                store.openSetup()
                            }
                        }
                }
                PointlessButton()
            }
            .padding(.trailing, 8)
        }
    }
}


// MARK: - From the Windows app: advisory day, yearly code, icons

struct AdvisoryPicker: View {
    @EnvironmentObject var store: Store
    let days = [(2, "Monday"), (3, "Tuesday"), (4, "Wednesday"), (5, "Thursday"), (6, "Friday")]
    var body: some View {
        HStack(spacing: 12) {
            Toggle("Advisory on", isOn: $store.data.advisoryEnabled)
            Picker("", selection: Binding(get: { store.data.school.advisoryWeekday ?? 5 }, set: { store.data.school.advisoryWeekday = $0 })) {
                ForEach(days, id: \.0) { Text($0.1 + "s").tag($0.0) }
            }
            .labelsHidden().frame(width: 150).disabled(!store.data.advisoryEnabled)
        }
    }
}

struct YearCodeEditor: View {
    @EnvironmentObject var store: Store
    @State private var code = ""
    @State private var message: String?
    @State private var ok = false

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                TextField("Paste a code like Year:2026;Adv:3;Limit:…", text: $code).textFieldStyle(.roundedBorder)
                Button("Apply") { apply() }.disabled(code.trimmingCharacters(in: .whitespaces).isEmpty)
            }
            HStack {
                Button("Copy this year’s code") {
                    guard let c = YearCode.encode(store.data.school) else { message = "Set the school year dates first."; ok = false; return }
                    NSPasteboard.general.clearContents()
                    NSPasteboard.general.setString(c, forType: .string)
                    message = "Copied: \(c.prefix(42))…"; ok = true
                }
                .buttonStyle(.link)
            }
            if let message { Text(message).font(.callout).foregroundStyle(ok ? .green : .red).fixedSize(horizontal: false, vertical: true) }
        }
    }

    private func apply() {
        guard let info = YearCode.decode(code) else {
            message = "That code doesn’t look right. It should start with Year: and have parts split by semicolons."; ok = false; return
        }
        var school = store.data.school
        YearCode.apply(info, to: &school)
        store.data.school = school
        let f = DateFormatter(); f.dateFormat = "MMM d, yyyy"
        let range = [info.start, info.end].compactMap { $0.flatMap(T.date).map(f.string) }.joined(separator: " – ")
        message = "Done: \(info.year)–\(info.year + 1) school year (\(range)), \(info.daysOff.count) days off, \(info.shortDays.count) short days."
        ok = true
        code = ""
    }
}

struct IconPicker: View {
    @Binding var icon: String?
    let name: String
    let color: Color
    @State private var open = false

    var body: some View {
        Button { open = true } label: {
            Circle().fill(color).frame(width: 26, height: 26)
                .overlay(Image(systemName: Icons.safe(icon ?? Icons.guess(name))).font(.system(size: 12, weight: .semibold)).foregroundStyle(.white))
        }
        .buttonStyle(.plain).help("Pick an icon")
        .popover(isPresented: $open, arrowEdge: .bottom) {
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text("Icon for \(name)").font(.headline)
                    Spacer()
                    Button("Automatic") { icon = nil; open = false }.buttonStyle(.link)
                }
                ScrollView {
                    LazyVGrid(columns: Array(repeating: GridItem(.fixed(38), spacing: 6), count: 8), spacing: 6) {
                        ForEach(Icons.choices.filter { Icons.exists($0.0) }, id: \.0) { sym, label in
                            Button { icon = sym; open = false } label: {
                                Image(systemName: sym).font(.system(size: 15)).frame(width: 36, height: 36)
                                    .background(icon == sym ? color.opacity(0.3) : Color.secondary.opacity(0.1))
                                    .clipShape(RoundedRectangle(cornerRadius: 8))
                            }
                            .buttonStyle(.plain).help(label)
                        }
                    }
                }
                .frame(height: 260)
            }
            .padding(14).frame(width: 360)
        }
    }
}

struct CustomColorsEditor: View {
    @EnvironmentObject var store: Store
    var body: some View {
        let fields: [(String, WritableKeyPath<CustomColors, String>)] = [
            ("Background", \.bg), ("Cards and buttons", \.card), ("Text", \.text), ("Muted text", \.muted), ("Accent", \.accent),
        ]
        VStack(alignment: .leading, spacing: 6) {
            ForEach(fields, id: \.0) { label, path in
                ColorPicker(label, selection: Binding(
                    get: { Color(hex: (store.data.appearance.custom ?? CustomColors())[keyPath: path]) },
                    set: { var c = store.data.appearance.custom ?? CustomColors(); c[keyPath: path] = $0.hexString; store.data.appearance.custom = c }),
                    supportsOpacity: false)
                    .frame(maxWidth: 260, alignment: .leading)
            }
            Button("Reset to default colors") { store.data.appearance.custom = CustomColors() }.buttonStyle(.link)
        }
    }
}

struct AboutBox: View {
    @EnvironmentObject var store: Store
    var body: some View {
        let v = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "dev"
        let os = ProcessInfo.processInfo.operatingSystemVersion
        VStack(alignment: .leading, spacing: 6) {
            Text("School Schedule \(v) for Mac").font(.body.weight(.semibold))
            Text("By Owen Wang (original Windows app) and Brady Krupa (macOS version, ported to macOS using Claude AI).")
                .font(.callout).fixedSize(horizontal: false, vertical: true)
            Text("macOS \(os.majorVersion).\(os.minorVersion).\(os.patchVersion) · \(HomeworkAI.engineName) · Settings: \(store.dataFileURL.path)")
                .font(.caption).foregroundStyle(.secondary).textSelection(.enabled).fixedSize(horizontal: false, vertical: true)
            UpdateSettings().padding(.vertical, 4)
            HStack(spacing: 14) {
                Button("License (GNU AGPL v3)…") { store.openLicense() }
                Link("Source code", destination: License.sourceURL)
                Link("Original app on GitHub", destination: License.originalURL)
            }
        }
    }
}

/// From the Windows app's settings list.
struct PointlessButton: View {
    @State private var hover = false
    @State private var clicked = false
    var body: some View {
        Button(hover ? "This is a pointless button." : "This is a button.") { clicked = true }
            .buttonStyle(.link).font(.caption)
            .onHover { hover = $0 }
            .alert("I guessed you clicked it, huh?", isPresented: $clicked) { Button("Close") {} } message: {
                Text("Well, technically, it did something...")
            }
    }
}