// School Schedule for Mac. Copyright (c) 2026 Owen Wang (original School Schedule Manager) and Brady Krupa
// (macOS version, ported to macOS using Claude AI). Licensed under the GNU AGPL v3; see LICENSE.
import SwiftUI

/// Today's classes as a timeline: an icon for each class, its times, and a line that blends
/// from one class color to the next (the Windows app's timeline, in the modern style).
struct TimelineList: View {
    @EnvironmentObject var store: Store
    let items: [Item]
    let minute: Int
    let theme: Theme

    var body: some View {
        VStack(spacing: 0) {
            ForEach(Array(items.enumerated()), id: \.element.id) { i, item in
                TimelineRow(item: item, prev: i > 0 ? items[i - 1] : nil, next: i + 1 < items.count ? items[i + 1] : nil,
                            minute: minute, theme: theme)
            }
        }
    }
}

extension Store {
    func color(for item: Item, theme: Theme) -> Color {
        switch item.kind {
        case .classTime: return item.colorHex.map(Color.init(hex:)) ?? theme.muted
        case .lunch: return Color(hex: "#48B833")
        case .advisory: return Color(hex: "#D94E4E")
        case .event: return theme.accent2
        case .other: return theme.muted
        }
    }

    func icon(for item: Item) -> String {
        switch item.kind {
        case .classTime: return Icons.safe(item.classKey.flatMap { classInfo($0)?.symbol } ?? Icons.guess(item.title))
        case .lunch: return "fork.knife"
        case .advisory: return "person.2"
        case .event: return "star"
        case .other: return "clock"
        }
    }
}

struct TimelineRow: View {
    @EnvironmentObject var store: Store
    let item: Item
    let prev: Item?
    let next: Item?
    let minute: Int
    let theme: Theme

    var body: some View {
        let past = item.end <= minute
        let now = item.start <= minute && minute < item.end
        let c = store.color(for: item, theme: theme)
        let gradientOn = store.data.appearance.gradientOn
        HStack(spacing: 10) {
            ZStack {
                VStack(spacing: 0) {   // the line: blends from the class before, through this one, to the next
                    Rectangle().fill(prev.map { ColorMix.gradient(ColorMix.lerp(store.color(for: $0, theme: theme), c, 0.5), c, on: gradientOn) }
                                     ?? LinearGradient(colors: [.clear], startPoint: .top, endPoint: .bottom))
                    Rectangle().fill(next.map { ColorMix.gradient(c, ColorMix.lerp(c, store.color(for: $0, theme: theme), 0.5), on: gradientOn) }
                                     ?? LinearGradient(colors: [.clear], startPoint: .top, endPoint: .bottom))
                }
                .frame(width: 2)
                Circle().fill(c).frame(width: 24, height: 24)
                    .overlay(Image(systemName: store.icon(for: item)).font(.system(size: 11, weight: .semibold)).foregroundStyle(.white))
                    .overlay(Circle().stroke(theme.card, lineWidth: now ? 0 : 0))
                    .shadow(color: now ? c.opacity(0.6) : .clear, radius: 4)
            }
            .frame(width: 26)
            VStack(alignment: .leading, spacing: 1) {
                Text(item.title).font(.system(size: 12.5, weight: now ? .bold : .medium)).lineLimit(1)
                Text("\(T.clock(item.start)) – \(T.clock(item.end))").font(.system(size: 10.5).monospacedDigit()).foregroundStyle(theme.muted)
            }
            Spacer(minLength: 4)
            if now {
                Text("now").font(.system(size: 10, weight: .bold)).padding(.horizontal, 6).padding(.vertical, 2)
                    .background(theme.accent).foregroundStyle(.white).clipShape(Capsule())
            }
        }
        .frame(height: 40)
        .opacity(past && !now ? 0.5 : 1)
    }
}
