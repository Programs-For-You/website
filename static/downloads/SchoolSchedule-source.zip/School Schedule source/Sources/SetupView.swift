// School Schedule for Mac. Copyright (c) 2026 Owen Wang (original School Schedule Manager) and Brady Krupa
// (macOS version, ported to macOS using Claude AI). Licensed under the GNU AGPL v3; see LICENSE.
import SwiftUI

/// The step-by-step setup the first time the app opens.
struct SetupView: View {
    @EnvironmentObject var store: Store
    var onDone: () -> Void

    enum Path { case whs, custom }
    @State private var path: Path?
    @State private var step = 0
    @State private var todayDay = 1

    init(onDone: @escaping () -> Void, path: Path? = nil, step: Int = 0) {
        self.onDone = onDone
        _path = State(initialValue: path)
        _step = State(initialValue: step)
    }

    private var steps: Int { path == .custom ? 4 : 3 }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            VStack(alignment: .leading, spacing: 0) {
                if step == 0 { welcome } else if path == .whs { whsStep } else { customStep }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
            if step > 0 {
                HStack {
                    Button("Back") { step -= 1 }
                    Spacer()
                    Text("Step \(step) of \(steps)").font(.caption).foregroundStyle(.secondary)
                    Spacer()
                    if step < steps {
                        Button("Next") { next() }.keyboardShortcut(.defaultAction)
                    } else {
                        Button("Start using School Schedule") { finish() }.keyboardShortcut(.defaultAction)
                    }
                }
                .padding(.top, 12)
            }
        }
        .padding(28)
        .frame(width: 680, height: 560)
    }

    // MARK: Steps

    private var welcome: some View {
        VStack(alignment: .leading, spacing: 18) {
            Image(systemName: "clock.fill").font(.system(size: 40)).foregroundStyle(.tint)
            Text("Welcome to School Schedule").font(.system(size: 26, weight: .bold))
            Text("Always know what period it is, right from the top of your screen. First, which school do you go to?")
                .font(.title3).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            HStack(spacing: 14) {
                choice("WHS", "Use the built-in WHS bell schedule, Day 1–4 rotation, and calendar.", "checkmark.seal") { choose(.whs) }
                choice("My school is different", "Type in your own bell times and classes. Works for any school.", "pencil.and.list.clipboard") { choose(.custom) }
            }
            .padding(.top, 8)
        }
    }

    private func choice(_ title: String, _ sub: String, _ icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 8) {
                Image(systemName: icon).font(.system(size: 22)).foregroundStyle(.tint)
                Text(title).font(.headline)
                Text(sub).font(.callout).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
            .padding(18)
            .frame(maxWidth: .infinity, minHeight: 150, alignment: .topLeading)
            .background(Color.secondary.opacity(0.1))
            .clipShape(RoundedRectangle(cornerRadius: 14))
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    @ViewBuilder private var whsStep: some View {
        switch step {
        case 1:
            header("Your classes", "Type the name of the class you have each period. You can change these anytime in Settings.")
            ScrollView {
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                    ForEach($store.data.classes) { $c in
                        HStack {
                            Text("Period \(c.key)").foregroundStyle(.secondary).frame(width: 64, alignment: .leading)
                            TextField("Class name", text: $c.name)
                        }
                    }
                }
                Text("Have a mini class that only takes half a block? Add it later in Settings → Classes.")
                    .font(.callout).foregroundStyle(.secondary).padding(.top, 14)
            }
        case 2:
            header("Lunch and advisory", "Which lunch do you have on each day?")
            LunchPicker()
            Toggle("I have advisory on Thursdays", isOn: $store.data.advisoryEnabled).padding(.top, 16)
        default:
            done
        }
    }

    @ViewBuilder private var customStep: some View {
        switch step {
        case 1:
            header("Your bell schedule", "Add each period with its start and end time. Mark lunch as “Lunch.”")
            TextField("School name", text: $store.data.school.name).frame(maxWidth: 300).padding(.bottom, 10)
            ScrollView { PeriodsEditor(periods: store.normalPeriods) }
        case 2:
            header("Your classes", "Name your classes. If your classes change from day to day, set how many days are in the rotation and pick what meets when.")
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    Stepper("Days in rotation: \(store.data.school.rotationLength)", value: Binding(
                        get: { store.data.school.rotationLength },
                        set: { store.data.school.rotationLength = $0; store.normalizePlans() }), in: 1...10)
                        .frame(maxWidth: 260)
                    ClassNamesEditor()
                    if store.data.school.rotationLength > 1 {
                        Text("Which class meets when").font(.headline).padding(.top, 6)
                        PlanGrid()
                    }
                }
            }
        case 3:
            header("Almost done", store.data.school.rotationLength > 1 ? "What day of the rotation is today? The app counts forward from here." : "Optional: add your school year so the app knows when summer starts.")
            if store.data.school.rotationLength > 1 {
                Picker("Today is", selection: $todayDay) {
                    ForEach(1...store.data.school.rotationLength, id: \.self) { Text("Day \($0)").tag($0) }
                }
                .frame(maxWidth: 220).padding(.bottom, 16)
            }
            YearEditor()
            Text("You can add holidays and days off anytime in Settings → School.").font(.callout).foregroundStyle(.secondary).padding(.top, 14)
        default:
            done
        }
    }

    private var done: some View {
        VStack(alignment: .leading, spacing: 14) {
            Image(systemName: "checkmark.circle.fill").font(.system(size: 40)).foregroundStyle(.green)
            Text("You’re all set!").font(.system(size: 26, weight: .bold))
            Text("Look for the clock at the top-right of your screen.").font(.title3)
            VStack(alignment: .leading, spacing: 8) {
                Label("Click it to see today’s schedule and your homework.", systemImage: "cursorarrow.click")
                Label("Right-click it for settings.", systemImage: "contextualmenu.and.cursorarrow")
                Label("Next, we’ll ask to send you homework reminders. Click Allow.", systemImage: "bell")
            }
            .font(.callout).foregroundStyle(.secondary).padding(.top, 6)
        }
    }

    private func header(_ title: String, _ sub: String) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(.system(size: 22, weight: .bold))
            Text(sub).font(.callout).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
        }
        .padding(.bottom, 16)
    }

    // MARK: Actions

    private func choose(_ p: Path) {
        if p == .whs, !store.data.school.isWHS {
            store.data.school = Templates.whs()
            store.data.classes = Templates.whsClasses()
        } else if p == .custom, store.data.school.isWHS {
            store.data.school = Templates.custom()
            store.data.classes = Templates.customClasses()
        }
        path = p
        step = 1
    }

    private func next() {
        if path == .custom && step == 1 {
            // Make sure there's a class for every class period.
            let count = store.data.school.classPeriodCount
            var classes = store.data.classes
            while classes.count < count {
                let n = classes.count + 1
                classes.append(ClassInfo(key: "P\(n)", name: "Class \(n)", colorHex: Templates.palette[(n - 1) % Templates.palette.count]))
            }
            store.data.classes = classes
            if store.data.school.rotationLength == 1 {
                store.data.school.plans = [DayPlan(slots: Array(classes.prefix(count).map(\.key)))]
            }
            store.normalizePlans()
        }
        step += 1
    }

    private func finish() {
        if path == .custom, store.data.school.rotationLength > 1 {
            store.data.school.anchor = DayAnchor(date: T.dayString(Date()), day: todayDay)
        }
        store.data.setupDone = true
        onDone()
    }
}
