// School Schedule for Mac. Copyright (c) 2026 Owen Wang (original School Schedule Manager) and Brady Krupa
// (macOS version, ported to macOS using Claude AI). Licensed under the GNU AGPL v3; see LICENSE.
import Foundation

/// One block of homework time on one day of the plan.
struct PlanEntry: Identifiable, Equatable {
    var id: String { "\(hw.id.uuidString)-\(day)" }
    var hw: Homework
    var day: String
    var minutes: Int
    var part: Int        // 1-based; part 2 of 3 when big work is spread out
    var parts: Int
    var checked: Bool    // already worked on today
}

struct PlanDay: Identifiable, Equatable {
    var id: String { day }
    var day: String
    var date: Date
    var entries: [PlanEntry]
    var startAt: Int?    // suggested start time (minutes after midnight); nil = any time
    var cap: Int
    var total: Int { entries.reduce(0) { $0 + $1.minutes } }
    var left: Int { entries.filter { !$0.checked }.reduce(0) { $0 + $1.minutes } }
    var busy: Bool { total > cap }
}

/// Makes a homework schedule: small things go on the first night with room,
/// tests get study time on the nights right before, and projects are spread out.
enum Planner {
    static func plan(_ data: AppData, engine: Engine, now: Date, days horizon: Int = 7) -> [PlanDay] {
        let today = T.cal.startOfDay(for: now)
        let todayKey = T.dayString(today)
        let nowMin = T.minutesNow(now)
        let firstDay = nowMin >= 22 * 60 ? T.addDays(today, 1) : today   // too late tonight → start tomorrow
        let span = 30
        var dayList: [Date] = (0..<span).map { T.addDays(firstDay, $0) }
        if firstDay != today { dayList.insert(today, at: 0) }
        var load: [String: Int] = [:]
        var entries: [String: [PlanEntry]] = [:]
        func cap(_ d: Date) -> Int { engine.isSchoolDay(d) ? data.nightlyCap : data.nightlyCap * 3 / 2 }
        func add(_ hw: Homework, _ d: Date, _ minutes: Int, _ part: Int, _ parts: Int, checked: Bool = false) {
            let k = T.dayString(d)
            entries[k, default: []].append(PlanEntry(hw: hw, day: k, minutes: minutes, part: part, parts: parts, checked: checked))
            load[k, default: 0] += minutes
        }

        let tasks = data.homework.filter { $0.isPlanned && (!$0.done || $0.workLog?[todayKey] != nil) }
            .sorted { ($0.due, -$0.remaining, $0.title) < ($1.due, -$1.remaining, $1.title) }
        for hw in tasks {
            let workedToday = hw.workLog?[todayKey]
            if let w = workedToday { add(hw, today, w, 1, 1, checked: true) }
            let remaining = hw.done ? 0 : hw.remaining
            guard remaining > 0, let due = T.date(hw.due) else { continue }
            let start = workedToday != nil ? T.addDays(today, 1) : firstDay
            // Work happens on the days before it's due (at night). Already due → do it first thing.
            var window = dayList.filter { $0 >= start && $0 < due }
            if window.isEmpty { window = [start] }
            let big = hw.kind == .test || hw.kind == .project || remaining > 60
            if big {
                let n = min(window.count, max(1, Int((Double(remaining) / 30).rounded(.up))))
                let chosen: [Date]
                if hw.kind == .test || n == 1 {
                    chosen = Array(window.suffix(n))            // study on the nights right before the test
                } else {
                    chosen = (0..<n).map { i in                 // spread projects out, finishing the night before
                        window[Int((Double(i) * Double(window.count - 1) / Double(max(n - 1, 1))).rounded())]
                    }
                }
                let each = Rules.round5(remaining / n)
                var leftover = remaining
                let already = workedToday != nil ? 1 : 0
                let parts = n + already
                for (i, d) in chosen.enumerated() {
                    let m = i == chosen.count - 1 ? max(5, leftover) : min(each, leftover)
                    leftover -= m
                    add(hw, d, m, i + 1 + already, parts)
                }
            } else {
                let pick = window.first { load[T.dayString($0), default: 0] + remaining <= cap($0) }
                    ?? window.min { load[T.dayString($0), default: 0] < load[T.dayString($1), default: 0] }!
                add(hw, pick, remaining, 1, 1)
            }
        }

        return dayList.prefix(horizon + (firstDay != today ? 1 : 0)).compactMap { d in
            let k = T.dayString(d)
            guard var list = entries[k], !list.isEmpty else { return nil }
            list.sort { ($0.checked ? 1 : 0, $0.hw.due, $0.hw.title) < ($1.checked ? 1 : 0, $1.hw.due, $1.hw.title) }
            return PlanDay(day: k, date: d, entries: list, startAt: startTime(d, engine: engine, now: now), cap: cap(d))
        }
    }

    /// Half an hour after school and practice end, rounded to the next quarter hour.
    static func startTime(_ d: Date, engine: Engine, now: Date) -> Int? {
        guard let end = engine.busyUntil(d) else { return nil }
        var start = (end + 30 + 14) / 15 * 15
        if T.cal.isDate(d, inSameDayAs: now) {
            let m = T.minutesNow(now)
            if m > start { start = (m + 4) / 5 * 5 }
        }
        return start
    }
}
