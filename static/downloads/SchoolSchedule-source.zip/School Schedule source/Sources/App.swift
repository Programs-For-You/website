// School Schedule for Mac. Copyright (c) 2026 Owen Wang (original School Schedule Manager) and Brady Krupa
// (macOS version, ported to macOS using Claude AI). Licensed under the GNU AGPL v3; see LICENSE.
import AppKit
import ServiceManagement
import SwiftUI

@main
enum Main {
    static func main() {
        let app = NSApplication.shared
        let delegate = AppDelegate()
        app.delegate = delegate
        app.setActivationPolicy(.accessory) // lives in the menu bar, no Dock icon
        app.run()
    }
}

final class AppDelegate: NSObject, NSApplicationDelegate {
    let store = Store()
    private var status: StatusController!
    private var settingsWindow: NSWindow?
    private var setupWindow: NSWindow?

    func applicationDidFinishLaunching(_ note: Notification) {
        // Test: SS_DAY_TEST=2026-11-19,2026-11-20 prints what kind of day each date is, then quits.
        if let days = ProcessInfo.processInfo.environment["SS_DAY_TEST"] {
            let e = store.engine
            for s in days.split(separator: ",") {
                if let d = T.date(String(s)) {
                    print(s, e.dayType(d).rawValue, "Day", e.rotationDay(d).map(String.init) ?? "-")
                    if ProcessInfo.processInfo.environment["SS_DAY_ITEMS"] != nil {
                        for it in e.items(for: d) { print("   ", T.short(it.start), "-", T.short(it.end), it.title) }
                    }
                }
            }
            NSApp.terminate(nil)
            return
        }
        // Only one copy at a time.
        if let id = Bundle.main.bundleIdentifier,
           NSRunningApplication.runningApplications(withBundleIdentifier: id).count > 1 {
            NSRunningApplication.runningApplications(withBundleIdentifier: id)
                .first { $0 != NSRunningApplication.current }?.activate()
            NSApp.terminate(nil)
            return
        }
        if let dir = ProcessInfo.processInfo.environment["SS_SNAPSHOT_DIR"] {
            Snapshot.run(store, dir: dir)
            NSApp.terminate(nil)
            return
        }
        store.openSettings = { [weak self] in self?.showSettings() }
        store.openSetup = { [weak self] in self?.showSetup() }
        status = StatusController(store: store)
        Reminders.shared.setUp(store: store) { [weak self] key in self?.status.showQuickAdd(classKey: key) }
        store.onChange.append { [weak self] in
            guard let self else { return }
            self.status.refresh()
            self.status.applyPinned()
            Reminders.shared.reschedule(self.store.data, store: self.store)
        }
        store.openLicense = { [weak self] in self?.showLicense(firstRun: false) }
        // First launch (and after updating from 1.1): the person accepts the license first.
        if store.data.licenseAccepted == nil { showLicense(firstRun: true) } else { continueStartup() }
    }

    private func continueStartup() {
        MainActor.assumeIsolated {
            Updater.shared.start(appID: "school-schedule")
            // Updates install by themselves, but never while you're typing homework or have a window open.
            Updater.shared.busy = { [weak self] in
                guard let self else { return false }
                return self.store.quickTyping || self.settingsWindow?.isVisible == true
                    || self.setupWindow?.isVisible == true || self.licenseWindow?.isVisible == true
            }
        }
        Schoology.shared.start(store: store)
        if store.data.setupDone {
            Reminders.shared.reschedule(store.data, store: store)
            status.applyPinned()
        } else {
            showSetup()
        }
    }

    private var licenseWindow: NSWindow?

    func showLicense(firstRun: Bool) {
        licenseWindow?.close()
        let w = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 620, height: 560),
                         styleMask: firstRun ? [.titled] : [.titled, .closable, .resizable], backing: .buffered, defer: false)
        w.title = firstRun ? "Welcome to School Schedule" : "School Schedule License"
        w.isReleasedWhenClosed = false
        w.contentView = NSHostingView(rootView: LicenseView(firstRun: firstRun, accept: { [weak self] in
            guard let self else { return }
            self.store.data.licenseAccepted = License.id
            self.licenseWindow?.close()
            self.licenseWindow = nil
            self.continueStartup()
        }, quit: { NSApp.terminate(nil) }, close: { [weak self] in self?.licenseWindow?.close() }))
        w.center()
        licenseWindow = w
        NSApp.activate(ignoringOtherApps: true)
        w.makeKeyAndOrderFront(nil)
    }

    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool {
        status?.showPopover()
        return false
    }

    func showSettings() {
        status.closePopover()
        if settingsWindow == nil {
            let w = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 760, height: 600),
                             styleMask: [.titled, .closable, .miniaturizable, .resizable], backing: .buffered, defer: false)
            w.title = "School Schedule Settings"
            w.isReleasedWhenClosed = false
            w.contentView = NSHostingView(rootView: SettingsView().environmentObject(store))
            w.setContentSize(NSSize(width: 760, height: 600))
            w.minSize = NSSize(width: 640, height: 480)
            w.center()
            settingsWindow = w
        }
        NSApp.activate(ignoringOtherApps: true)
        settingsWindow?.makeKeyAndOrderFront(nil)
    }

    func showSetup() {
        status?.closePopover()
        settingsWindow?.close()
        let w = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 680, height: 560),
                         styleMask: [.titled, .closable], backing: .buffered, defer: false)
        w.title = "Welcome to School Schedule"
        w.isReleasedWhenClosed = false
        w.contentView = NSHostingView(rootView: SetupView(onDone: { [weak self] in
            self?.setupWindow?.close()
            self?.setupWindow = nil
            Reminders.shared.requestPermission()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { self?.status.showPopover() }
        }).environmentObject(store))
        w.center()
        setupWindow = w
        NSApp.activate(ignoringOtherApps: true)
        w.makeKeyAndOrderFront(nil)
    }
}

/// A floating panel that can take typing (for the quick homework bar).
final class PinPanel: NSPanel {
    override var canBecomeKey: Bool { true }
}

/// The button at the top of the screen, its drop-down panel, its right-click menu,
/// and the floating window that stays on screen.
final class StatusController: NSObject {
    private var napBlock: NSObjectProtocol?
    private let store: Store
    private let item = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
    private let popover = NSPopover()
    private var panel: PinPanel?
    private lazy var overlay = OverlayController(store: store)
    private var timer: Timer?
    private var lastMinute = -1
    private var asked = Set<String>()

    init(store: Store) {
        self.store = store
        super.init()
        if let button = item.button {
            let img = NSImage(systemSymbolName: "clock", accessibilityDescription: "School Schedule")
            img?.isTemplate = true
            button.image = img
            button.imagePosition = .imageLeading
            button.font = NSFont.monospacedDigitSystemFont(ofSize: 13, weight: .medium)
            button.target = self
            button.action = #selector(clicked(_:))
            button.sendAction(on: [.leftMouseUp, .rightMouseUp])
            button.toolTip = "School Schedule: click for today, right-click for more"
        }
        popover.behavior = .transient
        popover.animates = true
        let host = NSHostingController(rootView: PopoverView().environmentObject(store))
        host.sizingOptions = [.preferredContentSize]
        popover.contentViewController = host
        store.togglePinned = { [weak self] in self?.togglePinned() }
        store.toggleCompact = { [weak self] in
            guard let self else { return }
            self.store.data.compactOnScreen = !(self.store.data.compactOnScreen ?? false)
        }
        refresh()
        let t = Timer(timeInterval: 1, repeats: true) { [weak self] _ in self?.tick() }
        t.tolerance = 0.1
        RunLoop.main.add(t, forMode: .common)
        timer = t
        // macOS slows down timers in apps it thinks are idle ("App Nap"), which made the countdown fall
        // behind and show a class that had already ended. A clock app needs to stay on time.
        napBlock = ProcessInfo.processInfo.beginActivity(options: [.userInitiatedAllowingIdleSystemSleep, .latencyCritical],
                                                         reason: "Keeping the class countdown on time")
        NSWorkspace.shared.notificationCenter.addObserver(forName: NSWorkspace.didWakeNotification, object: nil, queue: .main) { [weak self] _ in
            self?.lastMinute = -1      // the Mac just woke up: catch up right away
            self?.tick()
        }
        // Don't ask about classes that ended before the app opened.
        let now = Date()
        for c in store.engine.classesEnding(now) where c.end <= T.minutesNow(now) { asked.insert(askTag(c, now)) }
    }

    /// Every second: update the countdown; every minute: refresh the schedule and check if a class just ended.
    private func tick() {
        let d = Date()
        let m = T.minutesNow(d)
        if m != lastMinute {
            lastMinute = m
            store.now = d
            checkClassEnded(d)
        }
        refresh()
    }

    func refresh() {
        guard let button = item.button else { return }
        let a = store.data.appearance
        let title = a.showCountdownInMenuBar ? store.engine.menuTitle(Date(), seconds: a.showSeconds ?? false) : nil
        let text = title.map { " " + $0 } ?? ""
        if button.title != text { button.title = text }
        let look = NSAppearance(named: store.theme.dark ? .darkAqua : .aqua)
        if popover.appearance?.name != look?.name { popover.appearance = look }
        if let panel, panel.appearance?.name != look?.name { panel.appearance = look }
    }

    // MARK: After class: "Got homework?"

    private func askTag(_ item: Item, _ d: Date) -> String { "\(T.dayString(d))-\(item.end)-\(item.classKey ?? "")" }

    private func checkClassEnded(_ d: Date) {
        guard store.data.setupDone, store.data.asksAfterClass else { return }
        let m = T.minutesNow(d)
        for c in store.engine.classesEnding(d) where c.end <= m && m - c.end < 5 {
            let tag = askTag(c, d)
            guard !asked.contains(tag), let key = c.classKey else { continue }
            asked.insert(tag)
            Reminders.shared.askAboutHomework(className: c.title, classKey: store.baseKey(key))
        }
    }

    /// Opens the panel with the cursor in the homework box (from the notification or the menu).
    func showQuickAdd(classKey: String?) {
        if let classKey { store.quickClass = classKey }
        if let panel, panel.isVisible {
            if store.data.compactOnScreen == true { store.data.compactOnScreen = false }
            panel.makeKeyAndOrderFront(nil)
        } else {
            showPopover()
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) { self.store.focusQuickBar += 1 }
    }

    // MARK: Click and menu

    @objc private func clicked(_ sender: NSStatusBarButton) {
        let e = NSApp.currentEvent
        if e?.type == .rightMouseUp || e?.modifierFlags.contains(.control) == true { showMenu() } else { togglePopover() }
    }

    func togglePopover() { popover.isShown ? closePopover() : showPopover() }

    func showPopover() {
        guard let button = item.button else { return }
        store.now = Date()
        NSApp.activate(ignoringOtherApps: true)
        popover.show(relativeTo: button.bounds, of: button, preferredEdge: .minY)
        popover.contentViewController?.view.window?.makeKey()
    }

    func closePopover() { if popover.isShown { popover.performClose(nil) } }

    private func showMenu() {
        closePopover()
        let menu = NSMenu()
        func add(_ title: String, _ sel: Selector, on: Bool? = nil, key: String = "") {
            let i = NSMenuItem(title: title, action: sel, keyEquivalent: key)
            i.target = self
            if let on { i.state = on ? .on : .off }
            menu.addItem(i)
        }
        add("Add Homework…", #selector(menuQuickAdd))
        let onScreen = NSMenuItem(title: "On Screen", action: nil, keyEquivalent: "")
        let sub = NSMenu()
        let pinned = store.data.keepOnScreen == true
        for (title, tag) in [("Off", 0), ("Floating Card", 1), ("Overlay Bar (bottom corner)", 2)] {
            let i = NSMenuItem(title: title, action: #selector(menuOnScreen(_:)), keyEquivalent: "")
            i.target = self
            i.tag = tag
            i.state = (tag == 0 && !pinned) || (pinned && tag == (store.data.barStyle ? 2 : 1)) ? .on : .off
            sub.addItem(i)
        }
        onScreen.submenu = sub
        menu.addItem(onScreen)
        menu.addItem(.separator())
        add("Show Countdown in Menu Bar", #selector(toggleCountdown), on: store.data.appearance.showCountdownInMenuBar)
        if store.data.appearance.showCountdownInMenuBar {
            add("Show Seconds", #selector(toggleSeconds), on: store.data.appearance.showSeconds ?? false)
        }
        if store.data.school.advisoryWeekday != nil { add("Advisory Days", #selector(toggleAdvisory), on: store.data.advisoryEnabled) }
        let today = Date()
        if store.engine.isSchoolDay(today) {
            let type = store.engine.dayType(today)
            if store.data.school.schedules["short"] != nil { add("Short Day Today", #selector(toggleShortToday), on: type == .short) }
            if store.data.school.schedules["advisory"] != nil { add("Advisory Day Today", #selector(toggleAdvisoryToday), on: type == .advisory) }
        }
        menu.addItem(.separator())
        add("Settings…", #selector(openSettings), key: ",")
        add(MainActor.assumeIsolated { Updater.shared.menuTitle }, #selector(checkUpdates))
        add("Help & Instructions", #selector(openHelp))
        menu.addItem(.separator())
        menu.addItem(NSMenuItem(title: "Quit School Schedule", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q"))
        item.menu = menu
        item.button?.performClick(nil)
        item.menu = nil
    }

    @objc private func menuQuickAdd() { showQuickAdd(classKey: nil) }
    @objc private func menuPin() { togglePinned() }
    @objc private func menuOnScreen(_ sender: NSMenuItem) {
        if sender.tag == 0 { store.data.keepOnScreen = false; return }
        store.data.onScreenStyle = sender.tag == 2 ? "bar" : "card"
        store.data.keepOnScreen = true
    }
    @objc private func toggleCountdown() { store.data.appearance.showCountdownInMenuBar.toggle() }
    @objc private func toggleSeconds() { store.data.appearance.showSeconds = !(store.data.appearance.showSeconds ?? false) }
    @objc private func toggleAdvisory() { store.data.advisoryEnabled.toggle() }
    @objc private func toggleShortToday() { store.toggleToday(.short) }
    @objc private func toggleAdvisoryToday() { store.toggleToday(.advisory) }
    @objc private func openSettings() { store.openSettings() }
    @objc private func checkUpdates() { MainActor.assumeIsolated { Updater.shared.checkNow() } }
    @objc private func openHelp() { NSWorkspace.shared.open(URL(string: "https://programsforyou.com/school-schedule#how-to-use")!) }

    // MARK: Keep on screen

    func togglePinned() {
        store.data.keepOnScreen = !(store.data.keepOnScreen ?? false)
        applyPinned()
    }

    /// Shows or hides the floating card or the overlay bar to match the settings.
    func applyPinned() {
        let on = store.data.keepOnScreen == true && store.data.setupDone && store.data.licenseAccepted != nil
        let card = on && !store.data.barStyle
        if card, panel?.isVisible != true {
            closePopover()
            showPanel()
        } else if !card, let p = panel, p.isVisible {
            p.orderOut(nil)
        }
        if on && store.data.barStyle { overlay.apply(true) } else if overlay.isOn { overlay.apply(false) }
    }

    private func showPanel() {
        if panel == nil {
            let p = PinPanel(contentRect: NSRect(x: 0, y: 0, width: 320, height: 300),
                             styleMask: [.borderless, .nonactivatingPanel], backing: .buffered, defer: false)
            p.level = .floating
            p.isOpaque = false
            p.backgroundColor = .clear
            p.hasShadow = true
            p.hidesOnDeactivate = false          // stays put when you click other apps
            p.isMovableByWindowBackground = true
            p.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary]
            let host = NSHostingController(rootView: PopoverView(pinned: true).environmentObject(store))
            host.sizingOptions = [.preferredContentSize]
            p.contentViewController = host
            // Keep the top edge still when the window grows or shrinks, and remember where it was dragged.
            NotificationCenter.default.addObserver(forName: NSWindow.didResizeNotification, object: p, queue: .main) { [weak self] _ in
                self?.keepTopRight()
            }
            NotificationCenter.default.addObserver(forName: NSWindow.didMoveNotification, object: p, queue: .main) { [weak self] _ in
                guard let self, let p = self.panel, !self.placing else { return }
                UserDefaults.standard.set([p.frame.maxX, p.frame.maxY], forKey: "pinTopRight")
            }
            panel = p
        }
        panel?.appearance = NSAppearance(named: store.theme.dark ? .darkAqua : .aqua)
        keepTopRight()
        panel?.orderFrontRegardless()
    }

    private var placing = false

    private func keepTopRight() {
        guard let p = panel, let screen = NSScreen.main else { return }
        let vf = screen.visibleFrame
        var top = NSPoint(x: vf.maxX - 16, y: vf.maxY - 10)
        if let saved = UserDefaults.standard.array(forKey: "pinTopRight") as? [Double], saved.count == 2 {
            let pt = NSPoint(x: saved[0], y: saved[1])
            if NSScreen.screens.contains(where: { $0.frame.insetBy(dx: -2, dy: -2).contains(NSPoint(x: pt.x - 40, y: pt.y - 20)) }) { top = pt }
        }
        placing = true
        p.setFrameOrigin(NSPoint(x: top.x - p.frame.width, y: top.y - p.frame.height))
        placing = false
    }
}

enum LoginItem {
    static var isOn: Bool { SMAppService.mainApp.status == .enabled }
    static func set(_ on: Bool) -> String? {
        do {
            if on { try SMAppService.mainApp.register() } else { try SMAppService.mainApp.unregister() }
            return nil
        } catch {
            return "macOS didn’t allow that. Move the app into your Applications folder and try again."
        }
    }
}
