// School Schedule for Mac. Copyright (c) 2026 Owen Wang (original School Schedule Manager) and Brady Krupa
// (macOS version, ported to macOS using Claude AI). Licensed under the GNU AGPL v3; see LICENSE.
// Updates for the programsforyou.com apps. The app checks programsforyou.com/updates.json now and then. When
// there's a new version it downloads it quietly, checks it, and installs it by itself the next time the person
// steps away from the computer (or when they quit the app). Nobody has to download and reinstall anything.
// If automatic updates are turned off in Settings, the app asks first instead.
import AppKit
import CryptoKit
import Security
import SwiftUI
import UserNotifications

struct UpdateError: LocalizedError {
    let message: String
    init(_ m: String) { message = m }
    var errorDescription: String? { message }
}

@MainActor
final class Updater: ObservableObject {
    static let shared = Updater()

    enum State: Equatable { case idle, checking, upToDate, available, ready, downloading(Double), installing, failed(String), whatsNew }

    struct Release: Equatable, Sendable {
        var version: String
        var url: URL
        var sha256: String?
        var notes: String
        var fixed = ""
        var added = ""
    }

    @Published var state = State.idle
    @Published var latest: Release?
    /// Install updates by themselves (the default). Off = ask first.
    @Published var autoUpdate: Bool {
        didSet { UserDefaults.standard.set(autoUpdate, forKey: "pfyAutoUpdate") }
    }

    /// Each app says when it's in the middle of something (typing, a window open), so it isn't restarted then.
    var busy: () -> Bool = { false }
    var afterUpdateNote: String?
    private(set) var appID = ""
    private var staged: (release: Release, app: URL)?   // downloaded, checked, and waiting to be installed
    private var window: NSWindow?
    private var timer: Timer?
    private var quietTimer: Timer?
    private var quitWatch: NSObjectProtocol?
    private var swapping = false
    private var lastCheck = Date.distantPast
    private var progressWatch: NSKeyValueObservation?

    static let downloadPage = URL(string: "https://programsforyou.com/download.html")!
    nonisolated static var env: [String: String] { ProcessInfo.processInfo.environment }
    static var feedURL: URL { URL(string: env["PFY_UPDATE_FEED"] ?? "https://programsforyou.com/updates.json")! }
    // Timings (the PFY_UPDATE_* settings are only for testing).
    static var firstCheck: Double { Double(env["PFY_UPDATE_FIRST"] ?? "") ?? 20 }
    static var checkEvery: Double { Double(env["PFY_UPDATE_EVERY"] ?? "") ?? 4 * 3600 }
    static var awayFor: Double { Double(env["PFY_UPDATE_IDLE"] ?? "") ?? 120 }
    static var logging: Bool { env["PFY_UPDATE_LOG"] != nil }

    init() {
        autoUpdate = UserDefaults.standard.object(forKey: "pfyAutoUpdate") as? Bool ?? true
    }

    var appName: String { Bundle.main.object(forInfoDictionaryKey: "CFBundleName") as? String ?? "This app" }
    var current: String { Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "0" }
    /// What this version fixed and added, written into the app when it's built (from the update notes in config.js).
    var currentFixed: String { Bundle.main.object(forInfoDictionaryKey: "PFYFixed") as? String ?? "" }
    var currentAdded: String { Bundle.main.object(forInfoDictionaryKey: "PFYAdded") as? String ?? "" }
    var updateAvailable: Bool { latest.map { Self.isNewer($0.version, than: current) } ?? false }
    var menuTitle: String {
        if let s = staged { return "Restart to Update (Version \(s.release.version))" }
        return updateAvailable ? "Update to Version \(latest!.version)…" : "Check for Updates…"
    }
    var isBusy: Bool {
        if case .downloading = state { return true }
        return state == .installing
    }

    private func log(_ s: String) { if Self.logging { print("updater: " + s) } }

    /// Call once when the app starts.
    func start(appID: String, afterUpdateNote: String? = nil) {
        self.appID = appID
        self.afterUpdateNote = afterUpdateNote
        guard timer == nil else { return }
        if Self.env["PFY_UPDATE_TEST"] != nil { Task { await selfTest() }; return }
        tellIfJustUpdated()
        offerMoveIfNeeded()
        // Timers pause while the Mac sleeps, so also check after it wakes up.
        NSWorkspace.shared.notificationCenter.addObserver(forName: NSWorkspace.didWakeNotification, object: nil, queue: .main) { _ in
            MainActor.assumeIsolated {
                let u = Updater.shared
                if Date().timeIntervalSince(u.lastCheck) > 3600 { Task { await u.autoCheck() } }
            }
        }
        Task { [weak self] in
            try? await Task.sleep(for: .seconds(Self.firstCheck))
            await self?.autoCheck()
        }
        let t = Timer(timeInterval: Self.checkEvery, repeats: true) { [weak self] _ in Task { @MainActor in await self?.autoCheck() } }
        RunLoop.main.add(t, forMode: .common)
        timer = t
    }

    private func autoCheck() async {
        lastCheck = Date()
        guard !isBusy, state != .checking, staged == nil, let r = try? await fetch() else { return }
        latest = r
        guard Self.isNewer(r.version, than: current) else { log("up to date (\(current))"); return }
        log("version \(r.version) is out")
        if autoUpdate, installProblem == nil {
            // Download and check it quietly, then install it at a quiet moment.
            switch await prepare(r) {
            case .success(let app):
                staged = (r, app)
                if state == .available || state == .idle { state = .ready }
                log("downloaded and checked \(r.version); waiting for a quiet moment")
                waitForQuietMoment()
                return
            case .failure(let e):
                log("automatic download failed: \(e.message)")
            }
        }
        // Automatic updates are off (or couldn't run): ask, at most once a day for the same version.
        state = .available
        let key = "pfyUpdateShown-\(r.version)"
        guard Date().timeIntervalSince1970 - UserDefaults.standard.double(forKey: key) > 20 * 3600 else { return }
        UserDefaults.standard.set(Date().timeIntervalSince1970, forKey: key)
        showWindow()
    }

    /// The "Check for Updates" button and menu item.
    func checkNow() {
        if staged != nil { state = .ready; showWindow(); return }
        showWindow()
        guard !isBusy, state != .checking else { return }
        state = .checking
        Task {
            do {
                let r = try await fetch()
                latest = r
                state = Self.isNewer(r.version, than: current) ? .available : .upToDate
            } catch {
                state = .failed("Couldn’t check for updates. Check your internet connection and try again.")
            }
        }
    }

    private func fetch() async throws -> Release {
        var req = URLRequest(url: Self.feedURL, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 20)
        req.setValue("no-cache", forHTTPHeaderField: "Cache-Control")
        let (data, resp) = try await URLSession.shared.data(for: req)
        if let h = resp as? HTTPURLResponse, h.statusCode != 200 { throw UpdateError("The update server answered \(h.statusCode).") }
        guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let a = (json["apps"] as? [String: Any])?[appID] as? [String: Any],
              let v = a["version"] as? String, let u = (a["url"] as? String).flatMap(URL.init(string:)) else {
            throw UpdateError("There’s no update information for this app.")
        }
        return Release(version: v, url: u, sha256: a["sha256"] as? String, notes: a["notes"] as? String ?? "",
                       fixed: a["fixed"] as? String ?? "", added: a["added"] as? String ?? "")
    }

    /// "1.10" is newer than "1.9".
    static func isNewer(_ a: String, than b: String) -> Bool {
        let x = a.split(separator: ".").map { Int($0) ?? 0 }, y = b.split(separator: ".").map { Int($0) ?? 0 }
        for i in 0..<max(x.count, y.count) {
            let p = i < x.count ? x[i] : 0, q = i < y.count ? y[i] : 0
            if p != q { return p > q }
        }
        return false
    }

    /// Why the app can't replace itself where it is (nil = it can).
    var installProblem: String? {
        let path = Bundle.main.bundlePath
        if path.contains("/AppTranslocation/") || path.hasPrefix("/Volumes/") {
            return "First drag \(appName) into your Applications folder in Finder and open it from there. Then it can update itself."
        }
        let fm = FileManager.default
        if !fm.isWritableFile(atPath: (path as NSString).deletingLastPathComponent) || !fm.isWritableFile(atPath: path) {
            return "Your Mac doesn’t let \(appName) replace itself in this folder. Download the new version from programsforyou.com instead."
        }
        return nil
    }

    // MARK: Moving out of Downloads

    /// A copy opened straight from Downloads (or a disk image) can't replace itself, so it would never update.
    /// Offer to move it into the Applications folder (once per launch).
    private func offerMoveIfNeeded() {
        let path = Bundle.main.bundlePath
        let stuck = path.contains("/AppTranslocation/") || path.hasPrefix("/Volumes/") || path.hasPrefix(NSHomeDirectory() + "/Downloads/")
        guard stuck, Bundle.main.bundleIdentifier != nil else { return }
        let alert = NSAlert()
        alert.messageText = "Move \(appName) to your Applications folder?"
        alert.informativeText = "\(appName) is running from your Downloads folder, so it can’t update itself. In Applications it gets new versions and fixes automatically. Your settings stay the same."
        alert.addButton(withTitle: "Move to Applications")
        alert.addButton(withTitle: "Not Now")
        NSApp.activate(ignoringOtherApps: true)
        guard alert.runModal() == .alertFirstButtonReturn else { return }
        if let problem = moveToApplications() {
            let a = NSAlert()
            a.messageText = "Couldn’t move \(appName)"
            a.informativeText = problem
            a.runModal()
        }
    }

    /// Copies this app into /Applications (keeping whichever copy is newer), then reopens it from there.
    private func moveToApplications() -> String? {
        let fm = FileManager.default
        let dest = "/Applications/\(appName).app"
        var useExisting = false
        if fm.fileExists(atPath: dest) {
            let theirs = NSDictionary(contentsOfFile: dest + "/Contents/Info.plist")?["CFBundleShortVersionString"] as? String ?? "0"
            let theirID = NSDictionary(contentsOfFile: dest + "/Contents/Info.plist")?["CFBundleIdentifier"] as? String
            if theirID == Bundle.main.bundleIdentifier, !Self.isNewer(current, than: theirs) {
                useExisting = true                       // Applications already has this version or newer
            } else if (try? fm.trashItem(at: URL(fileURLWithPath: dest), resultingItemURL: nil)) == nil {
                return "Your Mac didn’t let \(appName) replace the copy in Applications. Drag it there yourself in Finder."
            }
        }
        if !useExisting {
            guard Self.run("/usr/bin/ditto", [Bundle.main.bundlePath, dest]) else {
                return "Your Mac didn’t let \(appName) copy itself into Applications. Drag it there yourself in Finder."
            }
        }
        // Reopen from Applications once this copy has quit (only one copy runs at a time).
        let script = """
        pid="$1"; app="$2"
        i=0; while kill -0 "$pid" 2>/dev/null && [ $i -lt 300 ]; do sleep 0.1; i=$((i+1)); done
        xattr -dr com.apple.quarantine "$app" 2>/dev/null
        open "$app"
        """
        let p = Process()
        p.executableURL = URL(fileURLWithPath: "/bin/sh")
        p.arguments = ["-c", script, "pfy-move", "\(getpid())", dest]
        p.environment = Self.env.filter { !$0.key.hasPrefix("PFY_UPDATE") }
        do { try p.run() } catch { return "Couldn’t reopen \(appName) from Applications. Open it from there yourself." }
        swapping = true
        NSApp.terminate(nil)
        return nil
    }

    // MARK: Automatic installs

    /// Downloads and checks a version in the background (no windows).
    private func prepare(_ r: Release) async -> Result<URL, UpdateError> {
        let zip: URL
        do {
            let (tmp, resp) = try await URLSession.shared.download(from: r.url)
            if let h = resp as? HTTPURLResponse, h.statusCode != 200 { return .failure(UpdateError("The download didn’t work.")) }
            zip = FileManager.default.temporaryDirectory.appendingPathComponent("pfy-update-\(UUID().uuidString).zip")
            try FileManager.default.moveItem(at: tmp, to: zip)
        } catch {
            return .failure(UpdateError("The download didn’t finish."))
        }
        let id = Bundle.main.bundleIdentifier ?? "", target = Bundle.main.bundleURL
        return await Task.detached { Updater.unpack(zip: zip, release: r, bundleID: id, target: target) }.value
    }

    /// Installs once the person has been away for a couple of minutes and the app isn't busy,
    /// or when they quit the app, whichever comes first.
    private func waitForQuietMoment() {
        quietTimer?.invalidate()
        let t = Timer(timeInterval: Self.awayFor < 10 ? 1 : 20, repeats: true) { [weak self] _ in
            MainActor.assumeIsolated { self?.installIfQuiet() }
        }
        RunLoop.main.add(t, forMode: .common)
        quietTimer = t
        if quitWatch == nil {
            quitWatch = NotificationCenter.default.addObserver(forName: NSApplication.willTerminateNotification, object: nil, queue: nil) { _ in
                MainActor.assumeIsolated { Updater.shared.installOnQuit() }
            }
        }
    }

    private func installIfQuiet() {
        guard let s = staged, !swapping else { return }
        let away = CGEventSource.secondsSinceLastEventType(.combinedSessionState, eventType: CGEventType(rawValue: ~0)!)
        guard away >= Self.awayFor, !busy(), window?.isVisible != true else { return }
        log("installing \(s.release.version) now (away for \(Int(away))s)")
        UserDefaults.standard.set(current, forKey: "pfyUpdatedFrom")
        swap(in: s.app, relaunch: Self.env["PFY_UPDATE_NO_RELAUNCH"] == nil)
    }

    private func installOnQuit() {
        guard let s = staged, !swapping else { return }
        log("installing \(s.release.version) as the app quits")
        UserDefaults.standard.set(current, forKey: "pfyUpdatedFrom")
        swap(in: s.app, relaunch: false, quitting: true)
    }

    /// After an update, a small "What's new" card says what this version fixed and added. If this build has no notes,
    /// a quick notification says it updated instead (only if notifications are allowed).
    private func tellIfJustUpdated() {
        guard let from = UserDefaults.standard.string(forKey: "pfyUpdatedFrom") else { return }
        UserDefaults.standard.removeObject(forKey: "pfyUpdatedFrom")
        guard from != current, Bundle.main.bundleIdentifier != nil else { return }
        log("updated from \(from) to \(current)")
        if !currentFixed.isEmpty || !currentAdded.isEmpty {
            Task { @MainActor in
                try? await Task.sleep(for: .seconds(Double(Self.env["PFY_UPDATE_NOTE_DELAY"] ?? "") ?? 3))
                self.showWhatsNew()
            }
            return
        }
        let name = appName, version = current
        UNUserNotificationCenter.current().getNotificationSettings { settings in
            guard settings.authorizationStatus == .authorized || settings.authorizationStatus == .provisional else { return }
            let c = UNMutableNotificationContent()
            c.title = "\(name) updated"
            c.body = "You now have version \(version). Everything you set up is still here."
            UNUserNotificationCenter.current().add(UNNotificationRequest(identifier: "pfy-updated", content: c, trigger: nil))
        }
    }

    /// The "What's new in this version" card (also opened from Settings).
    func showWhatsNew() {
        guard !isBusy else { return }
        state = .whatsNew
        showWindow()
    }

    // MARK: Installing (the Update Now button)

    func install(relaunch: Bool = env["PFY_UPDATE_NO_RELAUNCH"] == nil) {
        if let s = staged { swap(in: s.app, relaunch: relaunch); return }
        guard let r = latest, !isBusy else { return }
        if let p = installProblem { state = .failed(p); return }
        state = .downloading(0)
        let task = URLSession.shared.downloadTask(with: r.url) { [weak self] tmp, resp, err in
            // This runs in the background, and macOS deletes `tmp` when it returns, so keep a copy first.
            var result: Result<URL, UpdateError>
            let ok = (resp as? HTTPURLResponse).map { $0.statusCode == 200 } ?? true
            if let tmp, err == nil, ok {
                let keep = FileManager.default.temporaryDirectory.appendingPathComponent("pfy-update-\(UUID().uuidString).zip")
                do { try FileManager.default.moveItem(at: tmp, to: keep); result = .success(keep) }
                catch { result = .failure(UpdateError("Couldn’t save the download.")) }
            } else {
                result = .failure(UpdateError("The download didn’t finish. Check your internet connection and try again."))
            }
            DispatchQueue.main.async { MainActor.assumeIsolated { self?.downloaded(result, r, relaunch: relaunch) } }
        }
        progressWatch = task.progress.observe(\.fractionCompleted) { [weak self] p, _ in
            let f = p.fractionCompleted
            DispatchQueue.main.async {
                MainActor.assumeIsolated {
                    if case .downloading = self?.state { self?.state = .downloading(f) }
                }
            }
        }
        task.resume()
    }

    private func downloaded(_ result: Result<URL, UpdateError>, _ r: Release, relaunch: Bool) {
        progressWatch = nil
        switch result {
        case .failure(let e):
            state = .failed(e.message)
        case .success(let zip):
            state = .installing
            let id = Bundle.main.bundleIdentifier ?? "", target = Bundle.main.bundleURL
            Task.detached {
                let ready = Updater.unpack(zip: zip, release: r, bundleID: id, target: target)
                await MainActor.run {
                    switch ready {
                    case .failure(let e): Updater.shared.state = .failed(e.message)
                    case .success(let app): Updater.shared.swap(in: app, relaunch: relaunch)
                    }
                }
            }
        }
    }

    /// Checks the download and unzips it next to the app (same disk, so the swap is instant).
    nonisolated static func unpack(zip: URL, release r: Release, bundleID: String, target: URL) -> Result<URL, UpdateError> {
        let fm = FileManager.default
        defer { try? fm.removeItem(at: zip) }
        let damaged = UpdateError("The download was damaged. Please try again.")
        if let want = r.sha256?.lowercased(), !want.isEmpty {
            guard let data = try? Data(contentsOf: zip) else { return .failure(damaged) }
            let got = SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
            guard got == want else { return .failure(damaged) }
        }
        guard let work = try? fm.url(for: .itemReplacementDirectory, in: .userDomainMask, appropriateFor: target, create: true) else {
            return .failure(UpdateError("Couldn’t make room for the new version."))
        }
        guard run("/usr/bin/ditto", ["-x", "-k", zip.path, work.path]) else { return .failure(damaged) }
        guard let app = (try? fm.contentsOfDirectory(at: work, includingPropertiesForKeys: nil))?.first(where: { $0.pathExtension == "app" }),
              let info = NSDictionary(contentsOf: app.appendingPathComponent("Contents/Info.plist")),
              info["CFBundleIdentifier"] as? String == bundleID,
              info["CFBundleShortVersionString"] as? String == r.version else {
            return .failure(UpdateError("The download wasn’t the right app. Please try again later."))
        }
        guard run("/usr/bin/codesign", ["--verify", "--deep", "--strict", app.path]) else { return .failure(damaged) }
        guard signedByUs(app), sameSigner(app) else {
            return .failure(UpdateError("The download wasn’t signed by Programs For You, so it wasn’t installed."))
        }
        return .success(app)
    }

    /// The Programs For You signing certificate (its SHA-1, also in apps/signing-certificate.txt). EVERY update must be
    /// signed with it, however this copy was signed, so an unsigned ("ad-hoc") build can never install itself as an update.
    /// (Version 1.3.7 was published unsigned by mistake; this makes sure that can't reach anyone again.)
    nonisolated static let certificate = "7f6b9697ff46dc434ab1bcfb4c89732506f96653"

    nonisolated static func signedByUs(_ app: URL) -> Bool {
        let id = Bundle.main.bundleIdentifier ?? ""
        var req: SecRequirement?
        guard !id.isEmpty, SecRequirementCreateWithString("identifier \"\(id)\" and certificate root = H\"\(certificate)\"" as CFString, [], &req) == errSecSuccess,
              let req else { return false }
        var code: SecStaticCode?
        guard SecStaticCodeCreateWithPath(app as CFURL, [], &code) == errSecSuccess, let code else { return false }
        return SecStaticCodeCheckValidity(code, SecCSFlags(rawValue: kSecCSCheckAllArchitectures), req) == errSecSuccess
    }

    /// The new version must be signed with the same certificate as this one (if this one has a certificate).
    nonisolated static func sameSigner(_ app: URL) -> Bool {
        var me: SecCode?, mine: SecStaticCode?, req: SecRequirement?, text: CFString?
        guard SecCodeCopySelf([], &me) == errSecSuccess, let me,
              SecCodeCopyStaticCode(me, [], &mine) == errSecSuccess, let mine,
              SecCodeCopyDesignatedRequirement(mine, [], &req) == errSecSuccess, let req else { return true }
        SecRequirementCopyString(req, [], &text)
        guard let t = text as String?, t.contains("certificate") else { return true }   // ad-hoc builds can't check this
        var other: SecStaticCode?
        guard SecStaticCodeCreateWithPath(app as CFURL, [], &other) == errSecSuccess, let other else { return false }
        return SecStaticCodeCheckValidity(other, SecCSFlags(rawValue: kSecCSCheckAllArchitectures), req) == errSecSuccess
    }

    nonisolated static func run(_ tool: String, _ args: [String]) -> Bool {
        let p = Process()
        p.executableURL = URL(fileURLWithPath: tool)
        p.arguments = args
        p.standardOutput = FileHandle.nullDevice
        p.standardError = FileHandle.nullDevice
        do { try p.run() } catch { return false }
        p.waitUntilExit()
        return p.terminationStatus == 0
    }

    /// A tiny helper waits for the app to quit, puts the new version in its place, and opens it again.
    private func swap(in newApp: URL, relaunch: Bool, quitting: Bool = false) {
        guard !swapping else { return }
        swapping = true
        let script = """
        pid="$1"; old="$2"; new="$3"; relaunch="$4"
        exec >>"${TMPDIR:-/tmp}/programsforyou-update.log" 2>&1
        echo "$(date): updating $old"
        i=0; while kill -0 "$pid" 2>/dev/null && [ $i -lt 300 ]; do sleep 0.1; i=$((i+1)); done
        backup="$old.updating-$$"
        if mv "$old" "$backup"; then
          if mv "$new" "$old"; then rm -rf "$backup"; else mv "$backup" "$old"; fi
        fi
        xattr -dr com.apple.quarantine "$old" 2>/dev/null
        rm -rf "$(dirname "$new")"
        if [ "$relaunch" = 1 ]; then sleep 0.5; open "$old" && echo "reopened"; fi
        """
        let p = Process()
        p.executableURL = URL(fileURLWithPath: "/bin/sh")
        p.arguments = ["-c", script, "pfy-update", "\(getpid())", Bundle.main.bundlePath, newApp.path, relaunch ? "1" : "0"]
        // The reopened app gets the same settings as a normal launch (test-only switches are left out).
        p.environment = Self.env.filter { !$0.key.hasPrefix("PFY_UPDATE") }
        do { try p.run() } catch {
            swapping = false
            state = .failed("Couldn’t install the update. Download it from programsforyou.com instead.")
            return
        }
        staged = nil
        if !quitting { NSApp.terminate(nil) }
    }

    /// PFY_UPDATE_TEST=1: check and install right away without any windows (for testing).
    private func selfTest() async {
        print("update test: \(appName) \(current), feed \(Self.feedURL.absoluteString)")
        do {
            let r = try await fetch()
            latest = r
            print("update test: newest is \(r.version), newer: \(updateAvailable)")
            guard updateAvailable else { NSApp.terminate(nil); return }
            install()
            while isBusy { try? await Task.sleep(for: .milliseconds(100)) }
            if case .failed(let m) = state { print("update test: FAILED: \(m)"); NSApp.terminate(nil) }
        } catch {
            print("update test: check failed: \(error.localizedDescription)")
            NSApp.terminate(nil)
        }
    }

    // MARK: The update window

    func showWindow() {
        if window == nil {
            let w = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 460, height: 170), styleMask: [.titled, .closable], backing: .buffered, defer: false)
            w.title = "\(appName) Update"
            w.isReleasedWhenClosed = false
            let host = NSHostingController(rootView: UpdateView(close: { [weak self] in self?.closeWindow() }))
            host.sizingOptions = [.preferredContentSize]
            w.contentViewController = host
            w.center()
            window = w
        }
        NSApp.activate(ignoringOtherApps: true)
        window?.makeKeyAndOrderFront(nil)
    }

    private func closeWindow() {
        window?.close()
        if !isBusy, state != .available, state != .ready { state = .idle }
    }

    /// A line for Settings: what version this is and what the updater is doing.
    var statusLine: String {
        if let s = staged { return "Version \(current). Version \(s.release.version) is downloaded and installs by itself when you step away." }
        if updateAvailable { return "Version \(current). Version \(latest!.version) is available." }
        return autoUpdate ? "Version \(current). New versions install by themselves." : "Version \(current). You’ll be asked before updating."
    }
}

/// The updates part of each app's Settings.
struct UpdateSettings: View {
    @ObservedObject var u = Updater.shared
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Toggle("Install updates automatically", isOn: $u.autoUpdate)
            HStack(spacing: 10) {
                Text(u.statusLine).font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                Spacer(minLength: 8)
                if !u.currentFixed.isEmpty || !u.currentAdded.isEmpty { Button("What’s New") { u.showWhatsNew() } }
                Button("Check for Updates…") { u.checkNow() }
            }
        }
    }
}

struct UpdateView: View {
    @ObservedObject var u = Updater.shared
    var close: () -> Void

    var body: some View {
        HStack(alignment: .top, spacing: 16) {
            Image(nsImage: NSApp.applicationIconImage).resizable().frame(width: 64, height: 64)
            VStack(alignment: .leading, spacing: 9) { content }
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        .padding(20)
        .frame(width: 460, alignment: .leading)
    }

    @ViewBuilder private var content: some View {
        let version = u.latest?.version ?? ""
        switch u.state {
        case .idle, .checking:
            Text("Checking for updates…").font(.headline)
            ProgressView().controlSize(.small)
        case .upToDate:
            Text("You’re up to date!").font(.headline)
            Text("\(u.appName) \(u.current) is the newest version." + (u.autoUpdate ? " New versions install by themselves." : ""))
                .foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            buttons { Button("OK", action: close).keyboardShortcut(.defaultAction) }
        case .ready:
            Text("\(u.appName) \(version) is ready").font(.headline)
            Text("It’s already downloaded and installs by itself the next time you step away from your computer. Or install it now: it takes a few seconds and keeps all your settings.")
                .foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            notes
            buttons {
                Button("Later", action: close)
                Button("Install Now") { u.install() }.keyboardShortcut(.defaultAction)
            }
        case .available:
            Text("\(u.appName) \(version) is ready").font(.headline)
            Text("You have version \(u.current). Updating takes a few seconds, keeps all your settings, and reopens the app by itself.")
                .foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            notes
            buttons {
                Button("Later", action: close)
                Button("Update Now") { u.install() }.keyboardShortcut(.defaultAction)
            }
        case .downloading(let f):
            Text("Downloading \(u.appName) \(version)…").font(.headline)
            ProgressView(value: f)
        case .installing:
            Text("Installing…").font(.headline)
            Text("\(u.appName) will close and reopen in a moment.").foregroundStyle(.secondary)
            ProgressView().controlSize(.small)
        case .whatsNew:
            Text("What’s new in \(u.appName) \(u.current)").font(.headline)
            Text("Your app updated itself. Everything you set up is still here.")
                .foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            changes(fixed: u.currentFixed, added: u.currentAdded)
            buttons { Button("OK", action: close).keyboardShortcut(.defaultAction) }
        case .failed(let m):
            Text("Couldn’t update").font(.headline)
            Text(m).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            buttons {
                Button("Open the Downloads Page") { NSWorkspace.shared.open(Updater.downloadPage); close() }
                Button("Close", action: close).keyboardShortcut(.defaultAction)
            }
        }
    }

    @ViewBuilder private var notes: some View {
        if let l = u.latest, !l.fixed.isEmpty || !l.added.isEmpty {
            changes(fixed: l.fixed, added: l.added)
        } else if let n = u.latest?.notes, !n.isEmpty {
            Text("What’s new").font(.subheadline.weight(.semibold)).padding(.top, 2)
            Text(n).font(.callout).fixedSize(horizontal: false, vertical: true)
        }
        if let note = u.afterUpdateNote {
            Text(note).font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
        }
    }

    /// "Fixed" and "Added", each a short line (left out when there's nothing).
    @ViewBuilder private func changes(fixed: String, added: String) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            if !fixed.isEmpty { change("Fixed", fixed, "wrench.and.screwdriver.fill", .orange) }
            if !added.isEmpty { change("Added", added, "sparkles", .accentColor) }
        }
        .padding(.top, 2)
    }

    private func change(_ title: String, _ text: String, _ symbol: String, _ tint: Color) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 8) {
            Label(title, systemImage: symbol).labelStyle(.titleAndIcon).font(.caption.weight(.bold)).foregroundStyle(tint)
                .frame(width: 70, alignment: .leading)
            Text(text).font(.callout).fixedSize(horizontal: false, vertical: true)
        }
    }

    private func buttons<B: View>(@ViewBuilder _ b: () -> B) -> some View {
        HStack { Spacer(); b() }.padding(.top, 4)
    }
}
