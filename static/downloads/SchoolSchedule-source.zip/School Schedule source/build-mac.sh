#!/bin/bash
# School Schedule for Mac. Copyright (c) 2026 Owen Wang and Brady Krupa. Licensed under the GNU AGPL v3; see LICENSE.
# Builds School Schedule.app from this folder. Needs the Xcode Command Line Tools (run: xcode-select --install).
# NOTE: builds from this script are signed "ad-hoc" (no certificate). They run fine on your own Mac, but they can
# NOT be published as a Programs For You update: every copy of the app only installs updates signed with the
# Programs For You certificate. Official updates are made with apps/release.sh on the Mac that has that certificate.
set -euo pipefail
cd "$(dirname "$0")"
SDK="${SDK:-$(xcrun --show-sdk-path)}"   # or run: SDK=/path/to/MacOSX.sdk ./build-mac.sh
APP="build/School Schedule.app"
rm -rf "$APP"; mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
for arch in arm64 x86_64; do
  swiftc -O -swift-version 5 -parse-as-library -sdk "$SDK" -target "$arch-apple-macos14.0" Sources/*.swift \
    -o "build/SchoolSchedule-$arch" -Xlinker -weak_framework -Xlinker FoundationModels
done
lipo -create build/SchoolSchedule-arm64 build/SchoolSchedule-x86_64 -output "$APP/Contents/MacOS/SchoolSchedule"
rm -f build/SchoolSchedule-arm64 build/SchoolSchedule-x86_64
cp LICENSE "$APP/Contents/Resources/LICENSE"
[ -f AppIcon.icns ] && cp AppIcon.icns "$APP/Contents/Resources/AppIcon.icns"
cat > "$APP/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleExecutable</key><string>SchoolSchedule</string>
  <key>CFBundleIdentifier</key><string>com.programsforyou.schoolschedule</string>
  <key>CFBundleName</key><string>School Schedule</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleShortVersionString</key><string>1.3.8</string>
  <key>CFBundleVersion</key><string>1.3.8</string>
  <key>CFBundleIconFile</key><string>AppIcon</string>
  <key>LSMinimumSystemVersion</key><string>14.0</string>
  <key>LSUIElement</key><true/>
  <key>NSPrincipalClass</key><string>NSApplication</string>
</dict></plist>
PLIST
codesign --force --sign - "$APP"
echo "Built $APP"
